package authentication.controller;

import authentication.model.Profile;
import authentication.model.User;
import controller.Controller;
import database.MyLogger;
import model.Date;
import model.DateTime;

import java.util.Collections;
import java.util.LinkedList;
import java.util.Timer;
import java.util.TimerTask;

public class AuthenticationController extends Controller {


    public boolean isDuplicateUser(String  username, String  email, long  phoneNumber , long clientId){
        boolean isDuplicateUser= false;
        for (User user: context.userDataBaseSet.all()) {
            if (user.getUsername().equals(username)   ||    user.getProfile().getEmail().equals(email)    ||    user.getProfile().getPhoneNumber()==phoneNumber){
                isDuplicateUser= true;
                break;
            }
        }
        MyLogger myLogger = new MyLogger(
                "src/authentication/controller/AuthenticationController.java" ,
                "isDuplicateUser" ,
                clientId
        );
        return isDuplicateUser;
    }



























    public boolean userFound(String  username, String  password , long clientId){
        User myUser= null;
        for (User user: context.userDataBaseSet.all()) {
            if (user.getUsername().equals(username)){
                if (user.getPassword().equals(password)){
                    myUser= user;
                    break;
                }
            }
        }
        boolean b;
        b= myUser != null;
        MyLogger myLogger = new MyLogger(
                "src/authentication/controller/AuthenticationController.java" ,
                "userFound" ,
                clientId
        );
        return b;
    }
























    public void changePassword ( User user , String password1 , String password2 , long clientId ){
        User ownerUser= this.context.userDataBaseSet.get(user.getId());
        //تغییر رمز عبور و ذخیره رمز عبور جدید در فایل و آپدیت فایل قبلی
        // تابع آپدیت باید در DataBaseSet باشد
        if (password1.equals(password2)) {
            ownerUser.setPassword(password1);
            context.userDataBaseSet.update(ownerUser);
        }
        MyLogger myLogger = new MyLogger(
                "src/authentication/controller/AuthenticationController.java" ,
                "changePassword" ,
                clientId
        );
    }





















    private synchronized long createNewId ( long clientId ) {
        long n = 1;
        LinkedList<Long> idList=new LinkedList<>();
        for (User user : context.userDataBaseSet.all()) { idList.add(user.getId()); }
        if (idList.size()>0){n= Collections.max(idList)+1;}
        MyLogger myLogger = new MyLogger(
                "src/authentication/controller/AuthenticationController.java" ,
                "createNewId" ,
                clientId
        );
        return n;
    }























    public long register (String firstName,
                          String lastName,
                          String email,
                          String phoneNumber,
                          String biography,
                          String year,
                          String month,
                          String day,
                          String username,
                          String password,
                          long clientId)
    {
        //اگه اطلاعات تکراری باشه باید اکسپشن تعریف کنیم
        Profile profile= new Profile ( firstName , lastName , email );
        profile.setPhoneNumber(Long.parseLong ( phoneNumber ) );
        profile.setBiography ( biography );
        profile.setDateOfBirth ( new Date(Integer.parseInt( year ) ,Integer.parseInt( month ),Integer.parseInt ( day )));
        User user= new User ( username , password , profile);
        user.setId(createNewId(clientId));
        context.userDataBaseSet.add(user);
        MyLogger myLogger= new MyLogger(
                "src/authentication/controller/AuthenticationController.java" ,
                "register",
                clientId
        );
        Timer timer =new Timer();
        TimerTask task = new TimerTask() {
            @Override
            public void run()
            {
                User newUser= context.userDataBaseSet.get(user.getId());
                //change your variable values as required in this function as this will be invoked every 5 minutes
                newUser.getProfile().setLastSeenDate(DateTime.now());
                context.userDataBaseSet.update(newUser);
            }
        };
        timer.schedule(task ,  1000);

        return user.getId();
    }




















    public long login(String username, String password , long clientId){
        User user= null;
        boolean userFound=false;
        for (User my_user: context.userDataBaseSet.all()) {
            if (my_user.getUsername().equals( username )){
                if (my_user.getPassword().equals( password )){
                    userFound=true;
                    user=my_user;
                    break;
                }
            }
        }
        if (userFound){
            long currentUserId= user.getId();

            Timer timer =new Timer();
            TimerTask task = new TimerTask() {
                @Override
                public void run()
                {

                    User newUser= context.userDataBaseSet.get(currentUserId);
                    //change your variable values as required in this function as this will be invoked every 5 minutes
                    newUser.getProfile().setLastSeenDate(DateTime.now());
                    context.userDataBaseSet.update(newUser);
                }
            };
            timer.schedule(task ,  1000);
        }
        if (!userFound){}
        MyLogger myLogger = new MyLogger(
                "src/authentication/controller/AuthenticationController.java" ,
                "login" ,
                clientId
        );
        return user.getId();
    }








}
