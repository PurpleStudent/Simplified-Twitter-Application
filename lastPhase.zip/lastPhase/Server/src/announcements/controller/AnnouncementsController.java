package announcements.controller;

import authentication.model.User;
import controller.Controller;
import database.MyLogger;
import message.model.SystemMessage;
import request.model.Request;

import java.util.Collections;
import java.util.LinkedList;

public class AnnouncementsController extends Controller {





    public Request getFirstRequest( long clientId) {
        Request request= null;
        if (getMyRequests(clientId).size() > 0) {
            long requestId= Collections.max(getMyRequests(clientId));
            request= context.requestDataBaseSet.get(requestId);
            request.setRequester(context.userDataBaseSet.get(request.getRequesterId()));
            request.setRequested(context.userDataBaseSet.get(request.getRequestedId()));
        }
        MyLogger myLogger = new MyLogger(
                "src/announcements/controller/AnnouncementsController.java" ,
                "getFirstRequest" ,
                clientId
        );
        return request;
    }























    public SystemMessage getFirstSystemMessages ( long clientId ){
        SystemMessage systemMessage= null;
        if (mySystemMessages(clientId).size()>0){
            long systemMessageId= Collections.max(mySystemMessages(clientId));
            systemMessage= context.systemMessageDataBaseSet.get(systemMessageId);
            systemMessage.setRecipient(context.userDataBaseSet.get(systemMessage.getRecipientId()));
        }
        MyLogger myLogger = new MyLogger(
                "src/announcements/controller/AnnouncementsController.java" ,
                "getFirstSystemMessages" ,
                clientId
        );
        return systemMessage;
        //Updater.deleteFromSystemMessages(Cli.user,systemMessage);
        //Cli.user.getSystemMessages().remove(systemMessage);
    }






























    private LinkedList<Long> mySystemMessages ( long clientId){
        LinkedList<Long> mySystemMessages= new LinkedList<>();
        for (SystemMessage systemMessage: context.systemMessageDataBaseSet.all()) {
            if (systemMessage.getRecipientId()== clientId){
                mySystemMessages.add(systemMessage.getId());
            }
        }
        MyLogger myLogger = new MyLogger(
                "src/announcements/controller/AnnouncementsController.java" ,
                "mySystemMessages" ,
                clientId
        );
        return mySystemMessages;
    }






















    private LinkedList<Long>  getMyRequests(  long clientId){
        LinkedList<Long> myRequests= new LinkedList<>();
        for (Request request: context.requestDataBaseSet.all()) {
            if (request.getRequestedId()== clientId){
                request.setRequester(context.userDataBaseSet.get(request.getRequesterId()));
                request.setRequested(context.userDataBaseSet.get(request.getRequestedId()));
                myRequests.add(request.getId());
            }
        }
        MyLogger myLogger = new MyLogger(
                "src/announcements/controller/AnnouncementsController.java" ,
                "getMyRequests" ,
                clientId
        );
        return myRequests;
    }
}
