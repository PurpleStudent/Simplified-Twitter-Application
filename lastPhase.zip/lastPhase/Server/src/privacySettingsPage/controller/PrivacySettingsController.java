package privacySettingsPage.controller;

import authentication.model.User;
import controller.Controller;
import database.MyLogger;

public class PrivacySettingsController extends Controller {


    public void makeAccountPublic( long clientId){
        User newUser= context.userDataBaseSet.get(clientId);
        newUser.getProfile().setPrivateAccount(false);
        context.userDataBaseSet.update(newUser);
        MyLogger myLogger= new MyLogger(
                "src/privacySettingsPage/controller/PrivacySettingsController.java",
                "makeAccountPublic",
                clientId
        );
    }

















    public void makeAccountPrivate( long clientId){
        User newUser= context.userDataBaseSet.get(clientId);
        newUser.getProfile().setPrivateAccount(true);
        context.userDataBaseSet.update(newUser);
        MyLogger myLogger= new MyLogger(
                "src/privacySettingsPage/controller/PrivacySettingsController.java",
                "makeAccountPrivate",
                clientId
        );
    }

























    public void lastSeenOnline(String string ,  long clientId){
        User newUser= context.userDataBaseSet.get(clientId);
        newUser.getProfile().setShowLastSeenDate(string);
        context.userDataBaseSet.update(newUser);
        MyLogger myLogger = new MyLogger(
                "src/privacySettingsPage/controller/PrivacySettingsController.java",
                "lastSeenOnline" ,
                clientId
        );
    }

























    public void activeInactive(String string ,  long clientId){
        if (string.equals("active")){
            User newUser= context.userDataBaseSet.get(clientId);
            newUser.getProfile().setActive(true);
            context.userDataBaseSet.update(newUser);
        }
        if (string.equals("inactive")){
            User newUser= context.userDataBaseSet.get(clientId);
            newUser.getProfile().setActive(false);
            context.userDataBaseSet.update(newUser);
        }
        MyLogger myLogger = new MyLogger(
                "src/privacySettingsPage/controller/PrivacySettingsController.java",
                "activeInactive",
                clientId
        );
    }























    public void showDateOfBirth(String string ,  long clientId){
        User newUser= context.userDataBaseSet.get(clientId);
        newUser.getProfile().setShowDateOfBirth(string);
        context.userDataBaseSet.update(newUser);
        MyLogger myLogger = new MyLogger(
                "src/privacySettingsPage/controller/PrivacySettingsController.java",
                "showDateOfBirth" ,
                clientId
        );
    }


























    public void showEmail(String string ,  long clientId){
        User newUser= context.userDataBaseSet.get(clientId);
        newUser.getProfile().setShowEmail(string);
        context.userDataBaseSet.update(newUser);
        MyLogger myLogger = new MyLogger(
                "src/privacySettingsPage/controller/PrivacySettingsController.java",
                "showEmail",
                clientId
        );
    }































    public void showPhoneNumber(String string ,  long clientId){
        User newUser= context.userDataBaseSet.get(clientId);
        newUser.getProfile().setShowPhoneNumber(string);
        context.userDataBaseSet.update(newUser);
        MyLogger myLogger = new MyLogger(
                "src/privacySettingsPage/controller/PrivacySettingsController.java",
                "showPhoneNumber" ,
                clientId
        );
    }
















}
