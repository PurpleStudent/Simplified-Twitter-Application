package editProfilePage.controller;

import authentication.model.User;
import controller.Controller;
import database.MyLogger;
import model.Date;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.*;

public class EditProfileController extends Controller {


    public void copy ( BufferedImage image , long userId  , long clientId ) {
        try {
            String path = new File("").getAbsolutePath();
            String photoPath = path + "\\" + "resources\\Users Photos\\" + userId+".jpg";
            File photoFile= new File(photoPath);
            photoFile.getParentFile().mkdirs();
            if (!photoFile.exists()) {
                photoFile.createNewFile();
            }
            ImageIO.write(image, "jpg", photoFile );
            MyLogger myLogger= new MyLogger(
                    "src/editProfilePage/controller/EditProfileController.java" ,
                    "copy" ,
                    clientId
            );
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }





























    private boolean  isDuplicateUsername (String  username , long clientId){
        boolean isDuplicateUser= false;
        for (User user: context.userDataBaseSet.all()) {
            if (user.getUsername().equals(username)){
                isDuplicateUser= true;
                break;
            }
        }
        MyLogger myLogger = new MyLogger(
                "src/editProfilePage/controller/EditProfileController.java" ,
                "isDuplicateUsername" ,
                clientId
        );
        return isDuplicateUser;
    }






















    private boolean isDuplicateEmail(String  email  ,  long  clientId){
        boolean isDuplicateUser= false;
        for (User user: context.userDataBaseSet.all()) {
            if (user.getProfile().getEmail().equals(email)){
                isDuplicateUser= true;
                break;
            }
        }
        MyLogger myLogger = new MyLogger(
                "src/editProfilePage/controller/EditProfileController.java"  ,
                "isDuplicateEmail"  ,
                clientId
        );
        return isDuplicateUser;
    }
























    private boolean isDuplicatePhoneNumber(long  phoneNumber, long clientId){
        boolean isDuplicateUser= false;
        for (User user: context.userDataBaseSet.all()) {
            if (user.getProfile().getPhoneNumber()==phoneNumber){
                isDuplicateUser= true;
                break;
            }
        }
        MyLogger myLogger = new MyLogger(
                "src/editProfilePage/controller/EditProfileController.java" ,
                "isDuplicatePhoneNumber" ,
                clientId
        );
        return isDuplicateUser;
    }

























    public void changeFirstName(String newString  , long clientId){
        User newUser= context.userDataBaseSet.get(clientId);
        newUser.getProfile().setFirstName(newString);
        context.userDataBaseSet.update(newUser);
        MyLogger myLogger= new MyLogger(
                "src/editProfilePage/controller/EditProfileController.java" ,
                "changeFirstName",
                clientId
        );
    }






















    public void changeLastName(String newString  , long clientId){
        User newUser= context.userDataBaseSet.get(clientId);
        newUser.getProfile().setLastName(newString);
        context.userDataBaseSet.update(newUser);
        MyLogger myLogger= new MyLogger(
                "src/editProfilePage/controller/EditProfileController.java" ,
                "changeLastName",
                clientId
        );
    }





















    public void changeUsername(String newString  , long clientId){
        if (!isDuplicateUsername(newString ,clientId)) {
            User newUser = context.userDataBaseSet.get(clientId);
            newUser.setUsername(newString);
            context.userDataBaseSet.update(newUser);
            MyLogger myLogger = new MyLogger(
                    "src/editProfilePage/controller/EditProfileController.java" ,
                    "changeUsername",
                    clientId
            );
        }
    }




















    public void changeDateOfBirth(Date date  , long clientId){
        User newUser= context.userDataBaseSet.get(clientId);
        newUser.getProfile().setDateOfBirth(date);
        context.userDataBaseSet.update(newUser);
        MyLogger myLogger= new MyLogger(
                "src/editProfilePage/controller/EditProfileController.java" ,
                "changeDateOfBirth",
                clientId
        );
    }
























    public void changeEmail(String newString  , long clientId){
        if (!isDuplicateEmail(newString ,clientId)) {
            User newUser = context.userDataBaseSet.get(clientId);
            newUser.getProfile().setEmail(newString);
            context.userDataBaseSet.update(newUser);
            MyLogger myLogger = new MyLogger(
                    "src/editProfilePage/controller/EditProfileController.java" ,
                    "changeEmail",
                    clientId
            );
        }
    }























    public void changePhoneNumber(String newString  , long clientId){
        if (!isDuplicatePhoneNumber(Long.parseLong(newString) ,clientId)) {
            User newUser = context.userDataBaseSet.get(clientId);
            newUser.getProfile().setPhoneNumber(Long.parseLong(newString));
            context.userDataBaseSet.update(newUser);
            MyLogger myLogger = new MyLogger(
                    "src/editProfilePage/controller/EditProfileController.java" ,
                    "changePhoneNumber",
                    clientId
            );
        }
    }























    public void changeBiography(String newString  , long clientId){
        User newUser= context.userDataBaseSet.get(clientId);
        newUser.getProfile().setBiography(newString);
        context.userDataBaseSet.update(newUser);
        MyLogger myLogger= new MyLogger(
                "src/editProfilePage/controller/EditProfileController.java"  ,
                "changeBiography",
                clientId
        );
    }























    public void changePassword(String newString  , long clientId){
        User newUser= context.userDataBaseSet.get(clientId);
        newUser.setPassword(newString);
        context.userDataBaseSet.update(newUser);
        MyLogger myLogger= new MyLogger(
                "src/editProfilePage/controller/EditProfileController.java" ,
                "changePassword",
                clientId
        );
    }
}
