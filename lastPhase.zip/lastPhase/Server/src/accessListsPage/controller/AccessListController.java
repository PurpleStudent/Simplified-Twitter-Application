package accessListsPage.controller;

import authentication.model.User;
import category.model.Category;
import controller.Controller;
import database.MyLogger;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Collections;
import java.util.LinkedList;

public class AccessListController extends Controller {



    public User getUserWithId (long id , long clientId){
        User user= null;
        for ( User myUser : context.userDataBaseSet.all() ) {
            if ( myUser.getId() == id ) {user = myUser;}
        }
        MyLogger myLogger= new MyLogger(
                "src/accessListsPage/controller/AccessListController.java",
                "getUserWithId",
                clientId
        );
        return user;
    }





















    public BufferedImage getProfileImage( long userId , long clientId ){
        try {
            String path = new File("").getAbsolutePath();
            String photoPath = path + "\\" + "resources\\Users Photos\\" + userId+".jpg";
            MyLogger myLogger= new MyLogger(
                    "src/accessListsPage/controller/AccessListController.java",
                    "getProfileImage",
                    clientId
            );
            return ImageIO.read(new File(photoPath));
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }



















    public Category firstCategory ( long clientId) {
        Category category= null;
        if (myCategories(clientId).size()>0) {
            long firstId = Collections.max(myCategories(clientId));
            category = context.categoryDataBaseSet.get(firstId);
            category.setUser(context.userDataBaseSet.get(category.getUserId()));
        }
        MyLogger myLogger= new MyLogger(
                "src/accessListsPage/controller/AccessListController.java",
                "firstCategory",
                clientId
        );
        return category;
    }




















    private LinkedList<Long> myCategories ( long clientId){
        LinkedList<Long> myCategories= new LinkedList<>();
        for (Category category: context.categoryDataBaseSet.all()) {
            if (category.getUserId()== clientId ){
                myCategories.add(category.getId());
            }
        }
        MyLogger myLogger= new MyLogger(
                "src/accessListsPage/controller/AccessListController.java",
                "myCategories",
                clientId
        );
        return myCategories;
    }























    public void  createNewCategory (String name  , long clientId){
        if (getCategoryWithName( name , clientId )==null){
            Category category= new Category( name , clientId );
            category.setId(createCategoryNewId(clientId));
            category.setUser(context.userDataBaseSet.get( clientId ));
            context.categoryDataBaseSet.add(category);
            MyLogger myLogger= new MyLogger(
                    "src/accessListsPage/controller/AccessListController.java",
                    "createNewCategory",
                    clientId
            );
        }
        else {
            System.out.println("The entered name is duplicate. Enter another name:");
        }
    }

















    private Category getCategoryWithName(  String categoryName  , long clientId ){
        Category myCategory= null;
        for (Category category: context.categoryDataBaseSet.all()) {
            if (category.getUserId()==clientId){
                if (category.getCategoryName().equals(categoryName)){
                    myCategory= category;
                }
            }
        }
        MyLogger myLogger = new MyLogger(
                "src/accessListsPage/controller/AccessListController.java" ,
                "getCategoryWithName" ,
                clientId
        );
        return myCategory;
    }


















    private synchronized long createCategoryNewId ( long clientId ) {
        long n = 1;
        LinkedList<Long> idList=new LinkedList<>();
        for (Category category : context.categoryDataBaseSet.all()) { idList.add(category.getId()); }
        if (idList.size()>0){n= Collections.max(idList)+1;}
        MyLogger myLogger= new MyLogger(
                "src/accessListsPage/controller/AccessListController.java" ,
                "createCategoryNewId" ,
                clientId
        );
        return n;
    }




















    public User getFollower ( long clientId){
        LinkedList<Long> list= new LinkedList<>();
        for (long id: context.userDataBaseSet.getFollowersId(context.userDataBaseSet.get (clientId) )) {
            User user= context.userDataBaseSet.get(id);
            if (user.getProfile().isActive()){list.add(id);}
        }
        User myUser= null;
        if (list.size()>0) {
            long userId = Collections.min(list);
            myUser= context.userDataBaseSet.get(userId);
        }
        MyLogger myLogger = new MyLogger(
                "src/accessListsPage/controller/AccessListController.java" ,
                "getFollower" ,
                clientId
        );
        return myUser ;
    }
























    private User  nextMemberOfFollowers ( long currentUserId , long clientId){
        LinkedList<Long> list= new LinkedList<>();
        for (long id: context.userDataBaseSet.getFollowersId(context.userDataBaseSet.get (clientId))) {
            User user= context.userDataBaseSet.get(id);
            if (user.getProfile().isActive()){list.add(id);}
        }
        LinkedList<Long> nextId= new LinkedList<>();
        for (long id: list) {
            if (id>currentUserId){
                nextId.add(id);
            }
        }
        User user;
        if (nextId.size()==0){
            user= context.userDataBaseSet.get(currentUserId);
        }
        else {
            long next_Id= Collections.min(nextId);
            user= context.userDataBaseSet.get(next_Id);
        }
        MyLogger myLogger = new MyLogger(
                "src/accessListsPage/controller/AccessListController.java" ,
                "nextMemberOfFollowers" ,
                clientId
        );
        return user;
    }















    private User previousMemberOfFollowers ( long currentUserId  , long clientId ){
        LinkedList<Long> list= new LinkedList<>();
        for (long id: context.userDataBaseSet.getFollowersId(context.userDataBaseSet.get(clientId))) {
            User user= context.userDataBaseSet.get(id);
            if (user.getProfile().isActive()){list.add(id);}
        }
        LinkedList<Long> previousId= new LinkedList<>();
        for (long id : list) {
            if (id<currentUserId){
                previousId.add(id);
            }
        }
        User user;
        if (previousId.size()==0){
            user= context.userDataBaseSet.get(currentUserId);
        }
        else {
            long previous_Id= Collections.max(previousId);
            user= context.userDataBaseSet.get(previous_Id);
        }
        MyLogger myLogger = new MyLogger(
                "src/accessListsPage/controller/AccessListController.java" ,
                "previousMemberOfFollowers" ,
                clientId
        );
        return user;
    }























    public User getFollowing ( long clientId){
        LinkedList<Long> list= new LinkedList<>();
        for (long id: context.userDataBaseSet.getFollowingsId(context.userDataBaseSet.get(clientId))) {
            User user= context.userDataBaseSet.get(id);
            if (user.getProfile().isActive()){list.add(id);}
        }
        User myUser= null;
        if (list.size()>0) {
            long userId = Collections.min(list);
            myUser= context.userDataBaseSet.get(userId);
        }
        MyLogger myLogger = new MyLogger(
                "src/accessListsPage/controller/AccessListController.java" ,
                "getFollowing" ,
                clientId
        );
        return myUser;
    }






















    private User nextMemberOfFollowings(long currentUserId  , long clientId){
        LinkedList<Long> list= new LinkedList<>();
        for (long id: context.userDataBaseSet.getFollowingsId(context.userDataBaseSet.get(clientId))) {
            User user= context.userDataBaseSet.get(id);
            if (user.getProfile().isActive()){list.add(id);}
        }
        LinkedList<Long> nextId= new LinkedList<>();
        for (long id: list) {
            if (id>currentUserId){
                nextId.add(id);
            }
        }
        User user;
        if (nextId.size()==0){
            user= context.userDataBaseSet.get(currentUserId);
        }
        else {
            long next_Id= Collections.min(nextId);
            user= context.userDataBaseSet.get(next_Id);
        }
        MyLogger myLogger = new MyLogger(
                "src/accessListsPage/controller/AccessListController.java" ,
                "nextMemberOfFollowings" ,
                clientId
        );
        return user;
    }
















    private User previousMemberOfFollowings(long currentUserId  , long clientId){
        LinkedList<Long> list= new LinkedList<>();
        for (long id: context.userDataBaseSet.getFollowingsId(context.userDataBaseSet.get(clientId))) {
            User user= context.userDataBaseSet.get(id);
            if (user.getProfile().isActive()){list.add(id);}
        }
        LinkedList<Long> previousId= new LinkedList<>();
        for (long id : list) {
            if (id<currentUserId){
                previousId.add(id);
            }
        }
        User user;
        if (previousId.size()==0){
            user= context.userDataBaseSet.get(currentUserId);
        }
        else {
            long previous_Id= Collections.max(previousId);
            user= context.userDataBaseSet.get(previous_Id);
        }
        MyLogger myLogger = new MyLogger(
                "src/accessListsPage/controller/AccessListController.java" ,
                "previousMemberOfFollowings" ,
                clientId
        );
        return user;
    }














    public User getBlocked (  long clientId ){
        LinkedList<Long> list= new LinkedList<>();
        for (long id: context.userDataBaseSet.getBlackListsId(context.userDataBaseSet.get(clientId))) {
            User user= context.userDataBaseSet.get(id);
            if (user.getProfile().isActive()){list.add(id);}
        }
        User myUser= null;
        if (list.size()>0) {
            long userId = Collections.min(list);
            myUser= context.userDataBaseSet.get(userId);
        }
        MyLogger myLogger = new MyLogger(
                "src/accessListsPage/controller/AccessListController.java" ,
                "getBlocked" ,
                clientId
        );
        return myUser;
    }






















    private User nextMemberOfBlackList ( long currentUserId  , long clientId){
        LinkedList<Long> list= new LinkedList<>();
        for (long id: context.userDataBaseSet.getBlackListsId(context.userDataBaseSet.get(clientId))) {
            User user= context.userDataBaseSet.get(id);
            if (user.getProfile().isActive()){list.add(id);}
        }
        LinkedList<Long> nextId= new LinkedList<>();
        for (long id: list) {
            if (id>currentUserId){
                nextId.add(id);
            }
        }
        User user;
        if (nextId.size()==0){
            user= context.userDataBaseSet.get(currentUserId);
        }
        else {
            long next_Id= Collections.min(nextId);
            user= context.userDataBaseSet.get(next_Id);
        }
        MyLogger myLogger  =  new MyLogger(
                "src/accessListsPage/controller/AccessListController.java" ,
                "nextMemberOfBlackList" ,
                clientId
        );
        return user;
    }











    private User previousMemberOfBlackList(long currentUserId  , long clientId){
        LinkedList<Long> list= new LinkedList<>();
        for (long id: context.userDataBaseSet.getBlackListsId(context.userDataBaseSet.get(clientId))) {
            User user= context.userDataBaseSet.get(id);
            if (user.getProfile().isActive()){list.add(id);}
        }
        LinkedList<Long> previousId= new LinkedList<>();
        for (long id : list) {
            if (id<currentUserId){
                previousId.add(id);
            }
        }
        User user;
        if (previousId.size()==0){
            user= context.userDataBaseSet.get(currentUserId);
        }
        else {
            long previous_Id= Collections.max(previousId);
            user= context.userDataBaseSet.get(previous_Id);
        }
        MyLogger myLogger = new MyLogger(
                "src/accessListsPage/controller/AccessListController.java" ,
                "previousMemberOfBlackList" ,
                clientId
        );
        return user;
    }



















    public User next ( String list , long currentUserId  , long clientId ){
        User user= null;
        if (list.equals("followers")){user= nextMemberOfFollowers (currentUserId, clientId) ;}
        if (list.equals("followings")){user= nextMemberOfFollowings (currentUserId, clientId) ;}
        if (list.equals("black list")){user= nextMemberOfBlackList (currentUserId, clientId) ;}
        MyLogger myLogger = new MyLogger(
                "src/accessListsPage/controller/AccessListController.java" ,
                "next" ,
                clientId
        );
        return user;
    }























    public User previous(String list,long currentUserId , long clientId){
        User user= null;
        if (list.equals("followers")){user= previousMemberOfFollowers (currentUserId,clientId);}
        if (list.equals("followings")){user= previousMemberOfFollowings (currentUserId,clientId);}
        if (list.equals("black list")){user= previousMemberOfBlackList (currentUserId,clientId);}
        MyLogger myLogger = new MyLogger(
                "src/accessListsPage/controller/AccessListController.java" ,
                "previous" ,
                clientId
        );
        return user;
    }




















    public String buttonMode (long userId  , long clientId){
        String buttonMode= "";
        boolean b1= context.userDataBaseSet.getFollowingsId(context.userDataBaseSet.get(clientId)).contains(userId);
        boolean b2= context.userDataBaseSet.getBlackListsId(context.userDataBaseSet.get(clientId)).contains(userId);
        boolean b3= context.userDataBaseSet.getBlackListsId(getUserWithId (userId , clientId)).contains(clientId);
        boolean b4= context.userDataBaseSet.getFollowersId(context.userDataBaseSet.get(clientId)).contains(userId);

        if (b1 && !b2 && !b3){buttonMode= "buttonMode1";}
        if (!b1 && !b2){
            if (b4){buttonMode= "buttonMode2";}
            else {buttonMode= "buttonMode3";}
        }
        if (!b1 && b2){buttonMode= "buttonMode4";}
        MyLogger myLogger = new MyLogger(
                "src/accessListsPage/controller/AccessListController.java" ,
                "buttonMode" ,
                clientId
        );
        return buttonMode;
    }





























    public boolean showLastSeenDate (long userId  , long clientId){
        User user= getUserWithId(userId , clientId);
        boolean show= false;
        if (context.userDataBaseSet.getFollowersId(user).contains(clientId)) {
            if (user.getProfile().getShowLastSeenDate().equals("everybody")) {
                show= true;
            }
            if (user.getProfile().getShowLastSeenDate().equals("nobody")) {
                show= false;
            }
            if (user.getProfile().getShowLastSeenDate().equals("followings")) {
                show= context.userDataBaseSet.getFollowingsId(user).contains(clientId);
            }
        }
        MyLogger myLogger = new MyLogger(
                "src/accessListsPage/controller/AccessListController.java" ,
                "showLastSeenDate",
                clientId
        );
        return show;
    }














    public boolean showDateOfBirth(long userId , long clientId){
        User user= getUserWithId(userId , clientId);
        boolean show= false;
        if (user.getProfile().getShowDateOfBirth().equals("everybody")) {
            if (user.getProfile().getDateOfBirth()!=null) {
                show= true;
            }
        }
        if (user.getProfile().getShowDateOfBirth().equals("followings")) {
            if (context.userDataBaseSet.getFollowingsId(user).contains(clientId)) {
                if (user.getProfile().getDateOfBirth()!=null) {
                    show= true;
                }
            }
        }
        MyLogger myLogger = new MyLogger(
                "src/accessListsPage/controller/AccessListController.java" ,
                "showDateOfBirth" ,
                clientId
        );
        return show;
    }

















    public boolean showEmail (long userId  , long clientId) {
        User user= getUserWithId(userId ,clientId);
        boolean show= false;
        if (user.getProfile().getShowEmail().equals("everybody")) {
            show= true;
        }
        if (user.getProfile().getShowEmail().equals("followings")) {
            if (context.userDataBaseSet.getFollowingsId(user).contains(clientId)) {
                show= true;
            }
        }
        MyLogger myLogger = new MyLogger(
                "src/accessListsPage/controller/AccessListController.java" ,
                "showEmail" ,
                clientId
        );
        return show;
    }

















    public boolean showPhoneNumber(long userId , long clientId){
        User user= getUserWithId(userId ,clientId);
        boolean show= false;
        if (user.getProfile().getShowPhoneNumber().equals("everybody")) {
            show= true;
        }
        if (user.getProfile().getShowPhoneNumber().equals("followings")) {
            if (context.userDataBaseSet.getFollowingsId(user).contains(clientId)) {
                show= true;
            }
        }
        MyLogger myLogger = new MyLogger(
                "src/accessListsPage/controller/AccessListController.java" ,
                "showPhoneNumber" ,
                clientId
        );
        return show;
    }
}
