package message.model;

import authentication.model.User;
import model.DateTime;
import model.Model;

public class Message extends Model {


    private User creatorUser;
    private final long creatorUserId;
    private User recipientUser;
    private final long recipientUserId;
    private final String text;

    public Message(long creatorUserId, String text, long recipientUserId){
        this.creatorUserId= creatorUserId;
        this.recipientUserId= recipientUserId;
        this.text= text;
        dateTimeOfCreation= DateTime.now();
    }


    public User getCreatorUser() {
        return creatorUser;
    }

    public void setCreatorUser(User creatorUser) {
        this.creatorUser = creatorUser;
    }

    public User getRecipientUser() {
        return recipientUser;
    }

    public void setRecipientUser(User recipientUser) {
        this.recipientUser = recipientUser;
    }

    public String getText() {
        return text;
    }


    public long getCreatorUserId() {
        return creatorUserId;
    }

    public long getRecipientUserId() {
        return recipientUserId;
    }
}
