package message.model;

import authentication.model.User;
import model.Model;

public class Chat extends Model {

    private User user1;
    private User user2;

    private long user1Id;
    private long user2Id;

    public Chat(long user1Id, long user2Id){
        this.user1Id= user1Id;
        this.user2Id= user2Id;
        //this.id=createNewId();
    }


    public User getUser1() {
        return user1;
    }

    public void setUser1(User user1) {
        this.user1 = user1;
    }

    public User getUser2() {
        return user2;
    }

    public void setUser2(User user2) {
        this.user2 = user2;
    }

    public long getUser1Id() {
        return user1Id;
    }

    public void setUser1Id(long user1Id) {
        this.user1Id = user1Id;
    }

    public long getUser2Id() {
        return user2Id;
    }

    public void setUser2Id(long user2Id) {
        this.user2Id = user2Id;
    }
}
