package message.controller;

import authentication.model.User;
import controller.Controller;
import database.MyLogger;
import message.model.Chat;
import message.model.Message;
import message.model.SystemMessage;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.Collections;
import java.util.LinkedList;

public class MessageController extends Controller {






    public SystemMessage getPreviousSystemMessage (long currentSystemMessageId   , long clientId){
        LinkedList<Long> previousId= new LinkedList<>();
        for (long systemMessageId: mySystemMessages(clientId)) {
            if (systemMessageId < currentSystemMessageId ){
                previousId.add(systemMessageId);
            }
        }
        SystemMessage systemMessage;
        if (previousId.size()==0){
            systemMessage= getSystemMessageWithId( currentSystemMessageId ,clientId);
        }
        else {
            long previous_Id= Collections.max(previousId);
            systemMessage= context.systemMessageDataBaseSet.get(previous_Id);
        }
        systemMessage.setRecipient(context.userDataBaseSet.get(systemMessage.getRecipientId()));
        MyLogger myLogger = new MyLogger(
                "src/message/controller/MessageController.java" ,
                "getPreviousSystemMessage" ,
                clientId
        );
        return systemMessage;
    }


























    private SystemMessage getSystemMessageWithId(long id , long clientId){
        SystemMessage systemMessage= context.systemMessageDataBaseSet.get(id);
        systemMessage.setRecipient( context.userDataBaseSet.get(systemMessage.getRecipientId()));
        MyLogger myLogger = new MyLogger(
                "src/message/controller/MessageController.java" ,
                "getSystemMessageWithId" ,
                clientId
        );
        return systemMessage;
    }

































    public SystemMessage getNextSystemMessage( long currentSystemMessageId  , long clientId){
        LinkedList<Long> nextId= new LinkedList<>();
        for (long systemMessageId: mySystemMessages(clientId)) {
            if (systemMessageId> currentSystemMessageId ){
                nextId.add(systemMessageId);
            }
        }
        SystemMessage systemMessage;
        if (nextId.size()==0){
            systemMessage= getSystemMessageWithId(currentSystemMessageId,clientId);
        }
        else {
            long next_Id= Collections.min(nextId);
            systemMessage= context.systemMessageDataBaseSet.get(next_Id);
        }
        systemMessage.setRecipient(context.userDataBaseSet.get(systemMessage.getRecipientId()));
        MyLogger myLogger = new MyLogger(
                "src/message/controller/MessageController.java" ,
                "getNextSystemMessage" ,
                clientId
        );
        return systemMessage;
    }

















    private LinkedList<Long> mySystemMessages(  long clientId){
        LinkedList<Long> mySystemMessages= new LinkedList<>();
        for (SystemMessage systemMessage: context.systemMessageDataBaseSet.all()) {
            if (systemMessage.getRecipientId()== clientId){
                mySystemMessages.add(systemMessage.getId());
            }
        }
        MyLogger myLogger = new MyLogger(
                "src/message/controller/MessageController.java" ,
                "mySystemMessages" ,
                clientId
        );
        return mySystemMessages;
    }

























    public void deleteMessage(long  messageId  ,  long clientId){
        context.messageDataBaseSet.remove(context.messageDataBaseSet.get(messageId));
        MyLogger myLogger= new MyLogger(
                "src/message/controller/MessageController.java",
                "deleteMessage",
                clientId
        );
    }




























    public BufferedImage getMessageImage(long messageId , long clientId){
        try {
            String path = new File("").getAbsolutePath();
            String photoPath = path + "\\" + "resources\\Messages Photos\\" + messageId+".jpg";
            MyLogger myLogger = new MyLogger(
                    "src/message/controller/MessageController.java" ,
                    "getMessageImage" ,
                    clientId
            );
            return ImageIO.read(new File(photoPath));
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }




















    public BufferedImage getProfileImage (long userId , long clientId){
        try {
            String path = new File("").getAbsolutePath();
            String photoPath = path + "\\" + "resources\\Users Photos\\" + userId+".jpg";
            MyLogger myLogger = new MyLogger(
                    "src/message/controller/MessageController.java" ,
                    "getProfileImage" ,
                    clientId
            );
            return ImageIO.read(new File(photoPath));
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }


























    public Message getPreviousChatMessage (long userId, long currentMessageId  , long clientId){
        LinkedList<Long> previousMessagesId= new LinkedList<>();
        for (long messageId: context.chatDataBaseSet.getChatGroupAllMessages(getChatWithUser(context.userDataBaseSet.get(userId), clientId))) {
            if (messageId<currentMessageId){
                previousMessagesId.add(messageId);
            }
        }
        Message message;
        if (previousMessagesId.size()==0){
            message=context.messageDataBaseSet.get(currentMessageId);
        }
        else {
            long previousMessageId= Collections.max(previousMessagesId);
            message= context.messageDataBaseSet.get(previousMessageId);
        }
        message.setCreatorUser(context.userDataBaseSet.get(message.getCreatorUserId()));
        message.setRecipientUser(context.userDataBaseSet.get(message.getRecipientUserId()));
        MyLogger myLogger = new MyLogger(
                "src/message/controller/MessageController.java" ,
                "getPreviousChatMessage" ,
                clientId
        );
        return message;
    }




























    public Message getNextChatMessage (long userId, long currentMessageId  , long clientId){
        LinkedList<Long> nextMessagesId= new LinkedList<>();
        for (long messageId: context.chatDataBaseSet.getChatGroupAllMessages(getChatWithUser(context.userDataBaseSet.get(userId), clientId))) {
            if (messageId>currentMessageId){
                nextMessagesId.add(messageId);
            }
        }
        Message message;
        if (nextMessagesId.size()==0){
            message=context.messageDataBaseSet.get(currentMessageId);
        }
        else {
            long nextMessageId= Collections.min(nextMessagesId);
            message= context.messageDataBaseSet.get(nextMessageId);
        }
        message.setCreatorUser(context.userDataBaseSet.get(message.getCreatorUserId()));
        message.setRecipientUser(context.userDataBaseSet.get(message.getRecipientUserId()));
        MyLogger myLogger = new MyLogger(
                "src/message/controller/MessageController.java" ,
                "getNextChatMessage" ,
                clientId
        );
        return message;
    }

















    private synchronized long createNewChatId ( long clientId ) {
        long n = 1;
        LinkedList<Long> idList=new LinkedList<>();
        for (Chat chat : context.chatDataBaseSet.all()) { idList.add(chat.getId()); }
        if (idList.size()>0){n= Collections.max(idList)+1;}
        MyLogger myLogger = new MyLogger(
                "src/message/controller/MessageController.java" ,
                "createNewChatId" ,
                clientId
        );
        return n;
    }
































    private Chat getChatWithUser (User user  , long clientId){
        Chat chat;
        if (findChatWithUsers(context.userDataBaseSet.get(clientId), user,clientId) == null) {
            chat = new Chat(clientId, user.getId());
            chat.setId(createNewChatId(clientId));
            chat.setUser1(context.userDataBaseSet.get(clientId));
            chat.setUser2(context.userDataBaseSet.get(user.getId()));
            context.chatDataBaseSet.add(chat);
        }
        else {
            chat= findChatWithUsers(context.userDataBaseSet.get(clientId), user,clientId);
        }
        MyLogger myLogger = new MyLogger(
                "src/message/controller/MessageController.java" ,
                "getChatWithUser" ,
                clientId
        );
        return chat;
    }






















    private Chat findChatWithUsers(User user1, User user2 , long clientId){
        Chat myChat= null;
        for (Chat chat: context.chatDataBaseSet.all()) {
            if ((chat.getUser1Id()==(user1.getId()) && chat.getUser2Id()==(user2.getId())) || (chat.getUser1Id()==(user2.getId()) && chat.getUser2Id()==(user1.getId()))){
                myChat= chat;
                myChat.setUser1(context.userDataBaseSet.get(myChat.getUser1Id()));
                myChat.setUser2(context.userDataBaseSet.get(myChat.getUser2Id()));
                break;
            }
        }
        MyLogger myLogger = new MyLogger(
                "src/message/controller/MessageController.java" ,
                "findChatWithUsers" ,
                clientId
        );
        return myChat;
    }



































    private synchronized long createMessageNewId (long clientId) {
        long n = 1;
        LinkedList<Long> idList=new LinkedList<>();
        for (Message message : context.messageDataBaseSet.all()) { idList.add(message.getId()); }
        if (idList.size()>0){n= Collections.max(idList)+1;}
        MyLogger myLogger = new MyLogger(
                "src/message/controller/MessageController.java" ,
                "createMessageNewId" ,
                clientId
        );
        return n;
    }




























    public Message createNewMessage ( long chatId , long userId , String text , BufferedImage image  , long clientId){
        Chat chat= getChatWithId(chatId,clientId);
        Message message= null;
        if ( chat == null) {
            Chat myChat = new Chat ( clientId , userId ) ;
            myChat.setId(createNewChatId(clientId));
            myChat.setUser1(context.userDataBaseSet.get(clientId));
            myChat.setUser2(context.userDataBaseSet.get ( userId ));
            context.chatDataBaseSet.add(myChat);

            message = new Message(clientId, text, userId);
            message.setId(createMessageNewId(clientId));
            message.setCreatorUser(context.userDataBaseSet.get(message.getCreatorUserId()));
            message.setRecipientUser(context.userDataBaseSet.get(message.getRecipientUserId()));
            context.messageDataBaseSet.add(message);

            putMessageInChat(message,clientId);
            MyLogger myLogger= new MyLogger(
                    "src/message/controller/MessageController.java",
                    "createNewMessage",
                    clientId
            );
        }
        else {
            chat.setUser1(context.userDataBaseSet.get(chat.getUser1Id()));
            chat.setUser2(context.userDataBaseSet.get(chat.getUser2Id()));

            if (chat.getUser1Id() == clientId) {
                message = new Message(clientId, text, chat.getUser2().getId());
                message.setId(createMessageNewId(clientId));
                message.setCreatorUser(context.userDataBaseSet.get(message.getCreatorUserId()));
                message.setRecipientUser(context.userDataBaseSet.get(message.getRecipientUserId()));
                context.messageDataBaseSet.add(message);

                putMessageInChat(message,clientId);
            }
            if (chat.getUser2Id() == clientId) {
                message = new Message(clientId, text, chat.getUser1().getId());
                message.setId(createMessageNewId(clientId));
                message.setCreatorUser(context.userDataBaseSet.get(message.getCreatorUserId()));
                message.setRecipientUser(context.userDataBaseSet.get(message.getRecipientUserId()));
                context.messageDataBaseSet.add(message);

                putMessageInChat(message,clientId);
            }
            MyLogger myLogger= new MyLogger(
                    "src/message/controller/MessageController.java",
                    "createNewMessage",
                    clientId
            );
        }
        if (message != null) {
            if (image != null) {
                copy(image , message.getId(),clientId);
            }
        }
        return message;
    }























    private void putMessageInChat(Message message , long clientId){
        for (Chat chat: getUserChats(message.getCreatorUserId(),clientId)) {
            if (chat.getUser1Id()==message.getRecipientUserId() || chat.getUser2Id()==message.getRecipientUserId()){
                if (chat.getUser1Id()==message.getRecipientUserId()){
                    context.chatDataBaseSet.addUser1UnreadMessages(chat,message.getId());
                    context.chatDataBaseSet.addChatGroupAllMessages(chat,message.getId());
                }
                if (chat.getUser2Id()==message.getRecipientUserId()){
                    context.chatDataBaseSet.addUser2UnreadMessages(chat,message.getId());
                    context.chatDataBaseSet.addChatGroupAllMessages(chat,message.getId());
                }
            }
        }
        MyLogger myLogger = new MyLogger(
                "src/message/controller/MessageController.java" ,
                "putMessageInChat" ,
                clientId
        );
    }




















    private LinkedList<Chat> getUserChats(long userId , long clientId){
        LinkedList<Chat> chats= new LinkedList<>();
        for (Chat chat: context.chatDataBaseSet.all()) {
            if (chat.getUser1Id()==userId || chat.getUser2Id()==userId){
                chat.setUser1(context.userDataBaseSet.get(chat.getUser1Id()));
                chat.setUser2(context.userDataBaseSet.get(chat.getUser2Id()));
                chats.add(chat);
            }
        }
        MyLogger myLogger = new MyLogger(
                "src/message/controller/MessageController.java" ,
                "getUserChats" ,
                clientId
        );
        return chats;
    }


















    public Chat  getChatWithUserId (long userId  , long clientId) {
        Chat myChat=null;
        for (Chat chat: context.chatDataBaseSet.all()) {
            if (chat.getUser1Id()==userId){
                if (chat.getUser2Id()== clientId){
                    myChat=chat;
                    myChat.setUser1(context.userDataBaseSet.get(myChat.getUser1Id()));
                    myChat.setUser2(context.userDataBaseSet.get(myChat.getUser2Id()));
                    break;
                }
            }
            if (chat.getUser2Id()==userId){
                if (chat.getUser1Id()== clientId){
                    myChat=chat;
                    myChat.setUser1(context.userDataBaseSet.get(myChat.getUser1Id()));
                    myChat.setUser2(context.userDataBaseSet.get(myChat.getUser2Id()));
                    break;
                }
            }
        }
        MyLogger myLogger = new MyLogger(
                "src/message/controller/MessageController.java" ,
                "getChatWithUserId" ,
                clientId
        );
        return myChat;
    }







































    public Chat nextChat(long currentChatId  , long clientId){
        Chat currentChat= getChatWithId(currentChatId,clientId);
        LinkedList<Long> nextChatsId= new LinkedList<>();
        for (Chat chat: getUserChats(clientId ,clientId)) {
            if (chat.getId()>currentChat.getId()){
                nextChatsId.add(chat.getId());
            }
        }
        Chat chat;
        if (nextChatsId.size()==0){
            chat= currentChat;
        }
        else {
            long nextChatId= Collections.min(nextChatsId);
            chat= context.chatDataBaseSet.get(nextChatId);
        }
        chat.setUser1(context.userDataBaseSet.get(chat.getUser1Id()));
        chat.setUser2(context.userDataBaseSet.get(chat.getUser2Id()));
        MyLogger myLogger = new MyLogger(
                "src/message/controller/MessageController.java" ,
                "nextChat" ,
                clientId
        );
        return chat;
    }

















    public Chat previousChat (long currentChatId  , long clientId){
        Chat currentChat= getChatWithId(currentChatId,clientId);
        LinkedList<Long> previousChatsId= new LinkedList<>();
        for (Chat chat: getUserChats(clientId,clientId)) {
            if (chat.getId()<currentChat.getId()){
                previousChatsId.add(chat.getId());
            }
        }
        Chat chat;
        if (previousChatsId.size()==0){
            chat= currentChat;
        }
        else {
            long previousChatId= Collections.max(previousChatsId);
            chat= context.chatDataBaseSet.get(previousChatId);
        }
        chat.setUser1(context.userDataBaseSet.get(chat.getUser1Id()));
        chat.setUser2(context.userDataBaseSet.get(chat.getUser2Id()));
        MyLogger myLogger = new MyLogger(
                "src/message/controller/MessageController.java" ,
                "previousChat" ,
                clientId
        );
        return chat;
    }














    public int getNumberOfUnreadMessages (long chatId  , long clientId){
        Chat chat= getChatWithId(chatId,clientId);
        int n=0;
        if (chat!=null) {
            if (chat.getUser1Id() == clientId) {
                n = context.chatDataBaseSet.getUser1UnreadMessages(chat).size();
            }
            if (chat.getUser2Id() == clientId) {
                n = context.chatDataBaseSet.getUser2UnreadMessages(chat).size();
            }
        }
        MyLogger myLogger = new MyLogger(
                "src/message/controller/MessageController.java" ,
                "getNumberOfUnreadMessages" ,
                clientId
        );
        return n;
    }




















    private Chat getChatWithId (long chatId , long clientId){
        Chat chat= null;
        for (Chat myChat : context.chatDataBaseSet.all()) {
            if (myChat.getId() == chatId){
                chat = myChat;
                chat.setUser1( context.userDataBaseSet.get(chat.getUser1Id()));
                chat.setUser2( context.userDataBaseSet.get(chat.getUser2Id()));
            }
        }
        MyLogger myLogger = new MyLogger(
                "src/message/controller/MessageController.java" ,
                "getChatWithId" ,
                clientId
        );
        return chat;
    }


















    public User getAnotherUser(long chatId  , long clientId){
        Chat chat= getChatWithId(chatId,clientId);
        User user= null;
        if (chat!=null){
            if (chat.getUser1Id() == clientId) {
                user = context.userDataBaseSet.get(chat.getUser2Id());
            }
            if (chat.getUser2Id() == clientId) {
                user = context.userDataBaseSet.get(chat.getUser1Id());
            }
        }
        MyLogger myLogger = new MyLogger(
                "src/message/controller/MessageController.java" ,
                "getAnotherUser" ,
                clientId
        );
        return user;
    }




























    /*private void copy(String photoAddress, long messageId){
        try {
            String path = new File("").getAbsolutePath();
            String photoPath = path + "\\" + "resources\\Messages Photos\\" + messageId+".jpg";
            File photoFile= new File(photoPath);
            photoFile.getParentFile().mkdirs();
            if (!photoFile.exists()) {
                photoFile.createNewFile();
            }


            File file = new File(photoAddress);
            file.getParentFile().mkdirs();
            if (!file.exists()) {
                file.createNewFile();
            }

            copyFileUsingStream(file,photoFile);
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }*/

    /*private static void copyFileUsingStream(File source, File dest) {
        InputStream is = null;    OutputStream os = null;
        try {
            is = new FileInputStream(source);     os = new FileOutputStream(dest);
            byte[] buffer = new byte[1024];
            int length;
            while ((length = is.read(buffer)) > 0) {
                os.write(buffer, 0, length);
            }
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        finally {
            try {
                is.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                os.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }*/






























    public void copy ( BufferedImage image , long messageId  , long clientId){
        try {
            String path = new File("").getAbsolutePath();
            String photoPath = path + "\\" + "resources\\Messages Photos\\" + messageId+".jpg";
            File photoFile= new File(photoPath);
            photoFile.getParentFile().mkdirs();
            if (!photoFile.exists()) {
                photoFile.createNewFile();
            }
            ImageIO.write(image, "jpg", photoFile );
            MyLogger myLogger = new MyLogger(
                    "src/message/controller/MessageController.java" ,
                    "copy" ,
                    clientId
            );
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
}
