package category.controller;

import authentication.model.User;
import category.model.Category;
import controller.Controller;
import database.MyLogger;

import java.util.Collections;
import java.util.LinkedList;

public class CategoryController extends Controller {




    public User previousCategoryMember ( long currentCategoryMemberId , long categoryId , long clientId ){
        LinkedList<Long> previousId= new LinkedList<>();
        for (long userId: context.categoryDataBaseSet.getMembers( getCategoryWithId(categoryId ,clientId) )) {
            if ( userId < currentCategoryMemberId ){
                previousId.add(userId);
            }
        }
        User user;
        if (previousId.size()==0){
            user= getUserWithId(currentCategoryMemberId ,clientId);
        }
        else {
            long previous_Id= Collections.max(previousId);
            user= context.userDataBaseSet.get(previous_Id);
        }
        MyLogger myLogger = new MyLogger(
                "src/category/controller/CategoryController.java" ,
                "previousCategoryMember" ,
                clientId
        );
        return user;
    }












    private User getUserWithId(long id  , long clientId ){
        MyLogger myLogger = new MyLogger(
                "src/category/controller/CategoryController.java" ,
                "getUserWithId" ,
                clientId
        );
        return context.userDataBaseSet.get(id);
    }


























    private Category  getCategoryWithId (long id , long clientId) {
        Category category= context.categoryDataBaseSet.get(id);
        category.setUser( context.userDataBaseSet.get(category.getUserId()));
        MyLogger myLogger = new MyLogger(
                "src/category/controller/CategoryController.java" ,
                "getCategoryWithId" ,
                clientId
        );
        return category;
    }























    public User nextCategoryMember ( long currentCategoryMemberId , long categoryId  , long clientId){
        LinkedList<Long> nextId= new LinkedList<>();
        for ( long userId: context.categoryDataBaseSet.getMembers ( getCategoryWithId(categoryId ,clientId) ) ) {
            if ( userId > currentCategoryMemberId ){
                nextId.add(userId);
            }
        }
        User user;
        if (nextId.size()==0){
            user= getUserWithId(currentCategoryMemberId ,clientId);
        }
        else {
            long next_Id= Collections.min(nextId);
            user= context.userDataBaseSet.get(next_Id);
        }
        MyLogger myLogger = new MyLogger(
                "src/category/controller/CategoryController.java" ,
                "nextCategoryMember" ,
                clientId
        );
        return user;
    }

























    public Category getCategory(long categoryId  ,  long  clientId){
        MyLogger myLogger = new MyLogger(
                "src/category/controller/CategoryController.java" ,
                "getCategory" ,
                clientId
        );
        return context.categoryDataBaseSet.get(categoryId);
    }


























    public void addMember(String username, long categoryId ,  long clientId){
        long userId=0;
        for (User user: context.userDataBaseSet.all()) {
            if (user.getUsername().equals(username)){
                userId= user.getId(); break;
            }
        }
        if (context.userDataBaseSet.getFollowingsId(context.userDataBaseSet.get(clientId)).contains(userId)) {
            if (!context.categoryDataBaseSet.getMembers(context.categoryDataBaseSet.get(categoryId)).contains(userId)) {
                context.categoryDataBaseSet.addMember(context.categoryDataBaseSet.get(categoryId), userId);
                MyLogger myLogger= new MyLogger(
                        "src/category/controller/CategoryController.java",
                        "addMember",
                        clientId
                );
            }
        }
    }
















    public User firstCategoryMember (long categoryId , long clientId){
        Category category= getCategory(categoryId ,clientId);
        User user= null;
        if (context.categoryDataBaseSet.getMembers (category).size()>0){
            long userId= Collections.min(context.categoryDataBaseSet.getMembers (category));
            user= context.userDataBaseSet.get(userId);
        }
        MyLogger myLogger =  new MyLogger(
                "src/category/controller/CategoryController.java"  ,
                "firstCategoryMember"  ,
                clientId
        );
        return user;
    }





























    public Category previousCategory(long currentCategoryId  , long clientId){
        LinkedList<Long> previousId= new LinkedList<>();
        for (long categoryId: myCategories(clientId)) {
            if ( categoryId < currentCategoryId ){
                previousId.add(categoryId);
            }
        }
        Category category;
        if (previousId.size()==0){
            category= getCategory(currentCategoryId ,clientId);
        }
        else {
            long previous_Id= Collections.max(previousId);
            category= context.categoryDataBaseSet.get(previous_Id);
        }
        category.setUser(context.userDataBaseSet.get(category.getUserId()));
        MyLogger myLogger = new MyLogger(
                "src/category/controller/CategoryController.java" ,
                "previousCategory" ,
                clientId
        );
        return category;
    }











    public Category nextCategory(long currentCategoryId  , long clientId){
        Category currentCategory= getCategory(currentCategoryId ,clientId);
        LinkedList<Long> nextId= new LinkedList<>();

        for (long categoryId: myCategories(clientId)) {
            if ( categoryId > currentCategoryId ){
                nextId.add(categoryId);
            }
        }
        Category category;
        if (nextId.size()==0){
            category= currentCategory;
        }
        else {
            long next_Id= Collections.min(nextId);
            category= context.categoryDataBaseSet.get(next_Id);
        }
        category.setUser(context.userDataBaseSet.get(category.getUserId()));
        MyLogger myLogger = new MyLogger(
                "src/category/controller/CategoryController.java" ,
                "nextCategory" ,
                clientId
        );
        return category;
    }






















    private LinkedList<Long> myCategories(   long clientId ){
        LinkedList<Long> myCategories= new LinkedList<>();
        for (Category category: context.categoryDataBaseSet.all()) {
            if (category.getUserId()== clientId){
                myCategories.add(category.getId());
            }
        }
        MyLogger myLogger = new MyLogger(
                "src/category/controller/CategoryController.java" ,
                "myCategories" ,
                clientId
        );
        return myCategories;
    }
}
