package controller;

import database.Context;

public class Controller {

    protected Context context;

    public Controller(){
        context= new Context();
    }
}
