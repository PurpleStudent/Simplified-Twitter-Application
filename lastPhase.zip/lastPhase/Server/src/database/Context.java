package database;

import authentication.model.User;
import category.model.Category;
import group.model.Group;
import message.model.Chat;
import message.model.Message;
import message.model.SystemMessage;
import request.model.Request;
import tweet.model.Comment;
import tweet.model.Tweet;

public class Context {

    public DataBaseSet<User> userDataBaseSet= new UserDataBase();
    public DataBaseSet<Tweet> tweetDataBaseSet= new TweetDataBase();
    public DataBaseSet<Comment> commentDataBaseSet= new CommentDataBase();
    public DataBaseSet<Message> messageDataBaseSet= new MessageDataBase();
    public DataBaseSet<Request> requestDataBaseSet= new RequestDataBase();
    public DataBaseSet<Chat> chatDataBaseSet= new ChatDataBase();
    public DataBaseSet<Group> groupDataBaseSet= new GroupDataBase();
    public DataBaseSet<Category> categoryDataBaseSet= new CategoryDataBase();
    public DataBaseSet<SystemMessage> systemMessageDataBaseSet= new SystemMessageDataBase();
}
