package database;

import model.DateTime;
import tweet.model.Comment;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.LinkedList;
import java.util.Objects;
import java.util.Scanner;

public class CommentDataBase implements DataBaseSet<Comment>{


    @Override
    public Comment get(long id) {
            Comment comment = null;
            for ( Comment myComment : all()) {
                if (myComment.getId() == id){
                    comment = myComment;
                }
            }
            return comment;
            /*String path = new File("").getAbsolutePath();
            String commentsPath= path+"\\"+"resources\\Comments Folder\\";
            Files.createDirectories(Paths.get(commentsPath));
            File commentsFolder = new File(commentsPath);

            File file = null;
            for (File f : Objects.requireNonNull(commentsFolder.listFiles())) {
                if (f.getName().equals(id + ".txt")) {
                    file = f;
                }
            }
            return get(file);*/
    }




















    @Override
    public Comment get(File file) {
        try{
            Scanner scanner = new Scanner(file);
            int n=1;
            String text="";
            long id=-1, creatorUserId=-1, ownerTweetId=-1, reportNumber=-1;
            DateTime dateTime= null;

            while (scanner.hasNext() && n<7) {
                String s = scanner.nextLine();
                if (n==1){creatorUserId=Long.parseLong(s);}
                if (n==2){id=Long.parseLong(s);}
                if (n==3){ownerTweetId=Long.parseLong(s);}
                if (n==4){dateTime= DateTime.convertStringToDateTime(s);}
                if (n==5){text=s;}
                if (n==6){reportNumber=Long.parseLong(s);}
                n++;
            }
            scanner.close();

            Comment comment= new Comment(creatorUserId,text,ownerTweetId);

            comment.setId(id);
            comment.setDateTimeOfCreation(dateTime);
            comment.setReportNumber(reportNumber);

            return comment;
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }





















    @Override
    public LinkedList<Comment> all() {
        try {
            LinkedList<Comment> allComments= new LinkedList<>();

            String path = new File("").getAbsolutePath();
            String commentsPath= path+"\\"+"resources\\Comments Folder\\";
            Files.createDirectories(Paths.get(commentsPath));
            File commentsFolder = new File(commentsPath);

            for (File f : Objects.requireNonNull(commentsFolder.listFiles())) {
                Comment comment = get(f);
                allComments.add(comment);
            }
            return allComments;
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;

    }



























    @Override
    public void add(Comment comment) {
        try {
            String path = new File("").getAbsolutePath();
            String commentsPath= path+"\\"+"resources\\Comments Folder\\";
            Files.createDirectories(Paths.get(commentsPath));
            File commentsFolder = new File(commentsPath);

            String commentPath = commentsFolder.getAbsolutePath() + "\\" + comment.getId() + ".txt";
            File commentFile = new File(commentPath);
            commentFile.getParentFile().mkdirs();
            if (!commentFile.exists()) {
                commentFile.createNewFile();
            }
            FileOutputStream fout = new FileOutputStream(commentFile, false);
            PrintStream out = new PrintStream(fout);

            out.println(comment.getCreatorUserId());
            out.println(comment.getId());
            out.println(comment.getOwnerTweetId());
            out.println(comment.getDateTimeOfCreation().toString());
            out.println(comment.getText());
            out.println(comment.getReportNumber());

            out.flush();
            out.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }


























    @Override
    public void remove(Comment comment) {

    }

    @Override
    public void update(Comment comment) {

    }

    @Override
    public LinkedList<Long> getFollowersId(Comment comment) {
        return null;
    }

    @Override
    public void addFollower(Comment comment, Long l) {

    }

    @Override
    public void removeFollower(Comment comment, Long l) {

    }

    @Override
    public LinkedList<Long> getFollowingsId(Comment comment) {
        return null;
    }

    @Override
    public void addFollowing(Comment comment, Long l) {

    }

    @Override
    public void removeFollowing(Comment comment, Long l) {

    }

    @Override
    public LinkedList<Long> getBlackListsId(Comment comment) {
        return null;
    }

    @Override
    public void addBlackList(Comment comment, Long l) {

    }

    @Override
    public void removeBlackList(Comment comment, Long l) {

    }

    @Override
    public LinkedList<Long> getSavedMessages(Comment comment) {
        return null;
    }

    @Override
    public void addSavedMessage(Comment comment, Long l) {

    }

    /*@Override
    public LinkedList<String> getSystemMessages(Comment comment) {
        return null;
    }

    @Override
    public void addSystemMessage(Comment comment, String s) {

    }*/

    @Override
    public LinkedList<Long> getLikedTweetsId(Comment comment) {
        return null;
    }

    @Override
    public void addLikedTweet(Comment comment, Long l) {

    }

    @Override
    public LinkedList<Long> getRetweetedTweetsId(Comment comment) {
        return null;
    }

    @Override
    public void addRetweetedTweet(Comment comment, Long l) {

    }

    @Override
    public LinkedList<Long> getMutedUsersId(Comment comment) {
        return null;
    }

    @Override
    public void addMutedUser(Comment comment, Long l) {

    }

    @Override
    public LinkedList<Long> getChatGroupAllMessages(Comment comment) {
        return null;
    }

    @Override
    public void addChatGroupAllMessages(Comment comment, long l) {

    }

    @Override
    public LinkedList<Long> getUser1UnreadMessages(Comment comment) {
        return null;
    }

    @Override
    public void addUser1UnreadMessages(Comment comment, long l) {

    }

    @Override
    public LinkedList<Long> getUser2UnreadMessages(Comment comment) {
        return null;
    }

    @Override
    public void addUser2UnreadMessages(Comment comment, long l) {

    }

    @Override
    public LinkedList<Long> getMembers(Comment comment) {
        return null;
    }

    @Override
    public void addMember(Comment comment, long l) {

    }

    @Override
    public void removeMember(Comment comment, long l) {

    }
}
