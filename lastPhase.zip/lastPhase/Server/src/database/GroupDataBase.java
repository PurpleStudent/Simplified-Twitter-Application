package database;

import group.model.Group;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.LinkedList;
import java.util.Objects;
import java.util.Scanner;

public class GroupDataBase implements DataBaseSet<Group>{


    @Override
    public Group get(long id) {
        Group group= null;
        for (Group myGroup : all()) {
            if (myGroup.getId()==id){group=myGroup;break;}
        }
        return group;
    }



















    @Override
    public Group get(File file) {
        Group group = null;
        for (File f : Objects.requireNonNull(file.listFiles())){
            if (f.getName().equals(file.getName()+".txt")){group=loadGroup(f);}
        }
        return group;
    }

    private Group loadGroup(File file){
        try {
            Scanner s= new Scanner(file);
            Group group= null;

            int n=1;
            long groupId = 0;
            String groupName = "";
            while (s.hasNext()){
                String str= s.nextLine();
                if (n==1){groupId= Long.parseLong(str);}
                if (n==2){groupName= str;}
                n++;
            }
            s.close();
            group= new Group(groupName);
            group.setId(groupId);
            return group;
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }























    @Override
    public LinkedList<Group> all() {
        try {
            LinkedList<Group> groups= new LinkedList<>();

            String path = new File("").getAbsolutePath();
            String myPath = path + "\\" + "resources\\Groups Directory\\";
            Files.createDirectories(Paths.get(myPath));
            File groupsDirectory = new File(myPath);

            for (File f : Objects.requireNonNull(groupsDirectory.listFiles())) {
                if (f != null) {
                    groups.add(get(f));
                }
            }
            return groups;
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
























    @Override
    public void add(Group group) {
        try {
            String path = new File("").getAbsolutePath();
            String chatPath= path+"\\" + "resources\\Groups Directory\\"+group.getId()+"\\" +group.getId()+".txt";
            File chatFile= new File(chatPath);
            chatFile.getParentFile().mkdirs();
            if (!chatFile.exists()) {
                chatFile.createNewFile();
            }
            FileOutputStream fout = new FileOutputStream(chatFile, false);
            PrintStream out = new PrintStream(fout);

            out.println(group.getId());
            out.println(group.getName());
            out.flush();
            out.close();

            String allMessages= path+"\\" + "resources\\Groups Directory\\"+group.getId()+"\\" +"all Messages.txt";
            File allMessagesFile= new File(allMessages);
            allMessagesFile.getParentFile().mkdirs();
            if (!allMessagesFile.exists()) {
                allMessagesFile.createNewFile();
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }



























    @Override
    public void remove(Group group) {

    }

    @Override
    public void update(Group group) {

    }

    @Override
    public LinkedList<Long> getFollowersId(Group group) {
        return null;
    }

    @Override
    public void addFollower(Group group, Long l) {

    }

    @Override
    public void removeFollower(Group group, Long l) {

    }

    @Override
    public LinkedList<Long> getFollowingsId(Group group) {
        return null;
    }

    @Override
    public void addFollowing(Group group, Long l) {

    }

    @Override
    public void removeFollowing(Group group, Long l) {

    }

    @Override
    public LinkedList<Long> getBlackListsId(Group group) {
        return null;
    }

    @Override
    public void addBlackList(Group group, Long l) {

    }

    @Override
    public void removeBlackList(Group group, Long l) {

    }

    @Override
    public LinkedList<Long> getSavedMessages(Group group) {
        return null;
    }

    @Override
    public void addSavedMessage(Group group, Long l) {

    }

    /*@Override
    public LinkedList<String> getSystemMessages(Group group) {
        return null;
    }

    @Override
    public void addSystemMessage(Group group, String s) {

    }*/

    @Override
    public LinkedList<Long> getLikedTweetsId(Group group) {
        return null;
    }

    @Override
    public void addLikedTweet(Group group, Long l) {

    }

    @Override
    public LinkedList<Long> getRetweetedTweetsId(Group group) {
        return null;
    }

    @Override
    public void addRetweetedTweet(Group group, Long l) {

    }

    @Override
    public LinkedList<Long> getMutedUsersId(Group group) {
        return null;
    }

    @Override
    public void addMutedUser(Group group, Long l) {

    }

















    @Override
    public LinkedList<Long> getChatGroupAllMessages(Group group) {
        try {
            LinkedList<Long> list= new LinkedList<>();

            String path = new File("").getAbsolutePath();
            String myPath = path + "\\" + "resources\\Groups Directory\\";
            Files.createDirectories(Paths.get(myPath));
            File groupsDirectory = new File(myPath);

            File allMessagesFile= null;

            for (File f : Objects.requireNonNull(groupsDirectory.listFiles())) {
                if (f!=null && f.getName().equals(String.valueOf(group.getId()))) {
                    for (File file : Objects.requireNonNull(f.listFiles())) {
                        if (file.getName().equals("all Messages.txt")) {
                            allMessagesFile = file;
                        }
                    }
                }
            }

            if (allMessagesFile!=null) {
                Scanner scanner = new Scanner(allMessagesFile);
                while (scanner.hasNext()) {
                    String s = scanner.nextLine();
                    long id = Long.parseLong(s);
                    list.add(id);
                }
                scanner.close();
            }
            return list;
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }











    @Override
    public void addChatGroupAllMessages(Group group, long id) {
        try {
            File file= get_All_Messages_File(group);
            FileOutputStream fout = new FileOutputStream(file, true);
            PrintStream out = new PrintStream(fout);
            out.println(id);
            out.flush();
            out.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }















    private File get_All_Messages_File(Group group){
        try {
            String path = new File("").getAbsolutePath();
            String allMessages = path + "\\" + "resources\\Groups Directory\\" + group.getId() + "\\" + "all Messages.txt";
            File allMessagesFile = new File(allMessages);

            allMessagesFile.getParentFile().mkdirs();
            if (!allMessagesFile.exists()) {
                allMessagesFile.createNewFile();
            }
            return allMessagesFile;
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }


























    @Override
    public LinkedList<Long> getUser1UnreadMessages(Group group) {
        return null;
    }

    @Override
    public void addUser1UnreadMessages(Group group, long l) {

    }

    @Override
    public LinkedList<Long> getUser2UnreadMessages(Group group) {
        return null;
    }

    @Override
    public void addUser2UnreadMessages(Group group, long l) {

    }




















    @Override
    public LinkedList<Long> getMembers(Group group) {
        try {
            String path = new File("").getAbsolutePath();
            String myPath = path + "\\" + "resources\\Groups Directory\\";
            Files.createDirectories(Paths.get(myPath));
            File groupsDirectory = new File(myPath);

            File groupFile = null;

            for (File f : Objects.requireNonNull(groupsDirectory.listFiles())) {
                if (f != null && f.getName().equals(String.valueOf(group.getId()))) {
                    for (File file : Objects.requireNonNull(f.listFiles())) {
                        if (file.getName().equals(group.getId()+".txt")) {
                            groupFile = file;
                        }
                    }
                }
            }

            return loadMembers(groupFile);
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }




    private LinkedList<Long> loadMembers(File file){
        try {
            Scanner s= new Scanner(file);
            LinkedList<Long> list= new LinkedList<>();

            int n=1;
            long groupId = 0;
            String groupName = "";
            while (s.hasNext()){
                String str= s.nextLine();
                if (n==1){groupId= Long.parseLong(str);}
                if (n==2){groupName= str;}
                if (n>2){list.add(Long.parseLong(str));}
                n++;
            }
            s.close();
            return list;
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }

























    @Override
    public void addMember(Group group, long id) {
        try {
            String path = new File("").getAbsolutePath();
            String myPath = path + "\\" + "resources\\Groups Directory\\";
            Files.createDirectories(Paths.get(myPath));
            File groupsDirectory = new File(myPath);
            File groupFile = null;
            for (File f : Objects.requireNonNull(groupsDirectory.listFiles())) {
                if (f != null && f.getName().equals(String.valueOf(group.getId()))) {
                    for (File file : Objects.requireNonNull(f.listFiles())) {
                        if (file.getName().equals(group.getId()+".txt")) {
                            groupFile = file;
                        }
                    }
                }
            }
            FileOutputStream fout = new FileOutputStream(groupFile, true);
            PrintStream out = new PrintStream(fout);
            out.println(id);
            out.flush();
            out.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }































    @Override
    public void removeMember(Group group , long id){
        try {
            String path = new File("").getAbsolutePath();
            String myPath = path + "\\" + "resources\\Groups Directory\\";
            Files.createDirectories(Paths.get(myPath));
            File groupsDirectory = new File(myPath);
            File groupFile = null;
            for (File f : Objects.requireNonNull(groupsDirectory.listFiles())) {
                if (f != null && f.getName().equals(String.valueOf(group.getId()))) {
                    for (File file : Objects.requireNonNull(f.listFiles())) {
                        if (file.getName().equals(group.getId()+".txt")) {
                            groupFile = file;
                        }
                    }
                }
            }
            //---------------------------------
            Scanner scanner = new Scanner(groupFile);
            LinkedList<String> newList= new LinkedList<>();
            int line = 1;
            while (scanner.hasNext()) {
                String s = scanner.nextLine();
                if ( !s.equals(String.valueOf(id))   &&   line>2) {newList.add(s);}
                line++;
            }
            scanner.close();
            FileOutputStream fout = new FileOutputStream(groupFile, false);
            PrintStream out = new PrintStream(fout);
            out.println(group.getId());
            out.println(group.getName());
            for (String s: newList) {
                out.println(s);
            }
            out.flush();
            out.close();
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
}
