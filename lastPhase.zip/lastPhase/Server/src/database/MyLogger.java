package database;

import model.DateTime;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;

public class MyLogger {

    File loggerFile;
    String classPath;
    String function;
    DateTime dateTime;
    long clientId;







    public MyLogger ( String classPath , String function , long clientId ) {
        this.classPath=classPath;
        this.function=function;
        this.dateTime=DateTime.now();
        this.clientId = clientId;
        this.loggerFile=createLoggerFile();

        this.addToLoggerFile();
    }










    public void addToLoggerFile(){
        try {
            FileOutputStream fout = new FileOutputStream(this.loggerFile, true);
            PrintStream out = new PrintStream(fout);

            out.println("--------------------------------------------------------------------------------------------------------------------");
            out.println(this.classPath);
            out.println(this.function);
            out.println(this.dateTime.toString());
            out.println(this.clientId);
            out.println("--------------------------------------------------------------------------------------------------------------------");

            out.flush();
            out.close();
        }
        catch (IOException e) {
            MyLogger myLogger= new MyLogger("MyLogger","addToLoggerFile",clientId);
            e.printStackTrace();
        }
    }
























    public File createLoggerFile(){
        try {
            String path1 = new File("").getAbsolutePath();
            String path2= path1+"\\"+"resources\\"+"\\"   + "Logger File.txt";
            File file= new File(path2);
            file.getParentFile().mkdirs();
            if (!file.exists()) {
                file.createNewFile();
            }
            return file;
        }
        catch (IOException e) {
            MyLogger myLogger= new MyLogger("MyLogger","createLoggerFile",clientId);
            e.printStackTrace();
        }
        return null;
    }
}
