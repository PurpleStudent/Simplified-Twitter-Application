package database;

import message.model.SystemMessage;
import model.DateTime;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.LinkedList;
import java.util.Objects;
import java.util.Scanner;

public class SystemMessageDataBase implements DataBaseSet<SystemMessage>{


    @Override
    public SystemMessage get(long id) {
        try {
            String path = new File("").getAbsolutePath();
            String messagesPath = path+"\\"+"resources\\System Message Folder\\";
            Files.createDirectories(Paths.get(messagesPath));
            File folder = new File(messagesPath);

            File file = null;
            for (File f : Objects.requireNonNull(folder.listFiles())) {
                if (f.getName().equals(id + ".txt")) {
                    file = f;
                }
            }
            return get(file);
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }























    @Override
    public SystemMessage get(File file) {
        try{
            Scanner scanner = new Scanner(file);
            int n=1;
            String text="";
            long id=-1, recipientId=-1;
            DateTime dateTime= null;
            while (scanner.hasNext() && n<5) {
                String s = scanner.nextLine();
                if (n==1){recipientId=Long.parseLong(s);}
                if (n==2){id=Long.parseLong(s);}
                if (n==3){dateTime=DateTime.convertStringToDateTime(s);}
                if (n==4){text=s;}
                n++;
            }
            scanner.close();
            SystemMessage systemMessage= new SystemMessage(recipientId,text);
            systemMessage.setId(id);
            systemMessage.setDateTimeOfCreation(dateTime);
            return systemMessage;
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }

























    @Override
    public LinkedList<SystemMessage> all() {
        try {
            LinkedList<SystemMessage> all= new LinkedList<>();

            String path = new File("").getAbsolutePath();
            String messagesPath = path+"\\"+"resources\\System Message Folder\\";
            Files.createDirectories(Paths.get(messagesPath));
            File folder = new File(messagesPath);

            for (File f : Objects.requireNonNull(folder.listFiles())) {
                SystemMessage systemMessage = get(f);
                all.add(systemMessage);
            }
            return all;
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

























    @Override
    public void add(SystemMessage systemMessage) {
        try {
            String path = new File("").getAbsolutePath();
            String messagesPath = path+"\\"+"resources\\System Message Folder\\";
            Files.createDirectories(Paths.get(messagesPath));
            File messagesFolder = new File(messagesPath);

            String messagePath = messagesFolder.getAbsolutePath() + "\\" + systemMessage.getId() + ".txt";
            File messageFile = new File(messagePath);
            messageFile.getParentFile().mkdirs();
            if (!messageFile.exists()) {
                messageFile.createNewFile();
            }
            FileOutputStream fout = new FileOutputStream(messageFile, false);
            PrintStream out = new PrintStream(fout);

            out.println(systemMessage.getRecipientId());
            out.println(systemMessage.getId());
            out.println(systemMessage.getDateTimeOfCreation().toString());
            out.println(systemMessage.getText());

            out.flush();
            out.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }



























    @Override
    public void remove(SystemMessage systemMessage) {

    }

    @Override
    public void update(SystemMessage systemMessage) {

    }

    @Override
    public LinkedList<Long> getFollowersId(SystemMessage systemMessage) {
        return null;
    }

    @Override
    public void addFollower(SystemMessage systemMessage, Long l) {

    }

    @Override
    public void removeFollower(SystemMessage systemMessage, Long l) {

    }

    @Override
    public LinkedList<Long> getFollowingsId(SystemMessage systemMessage) {
        return null;
    }

    @Override
    public void addFollowing(SystemMessage systemMessage, Long l) {

    }

    @Override
    public void removeFollowing(SystemMessage systemMessage, Long l) {

    }

    @Override
    public LinkedList<Long> getBlackListsId(SystemMessage systemMessage) {
        return null;
    }

    @Override
    public void addBlackList(SystemMessage systemMessage, Long l) {

    }

    @Override
    public void removeBlackList(SystemMessage systemMessage, Long l) {

    }

    @Override
    public LinkedList<Long> getSavedMessages(SystemMessage systemMessage) {
        return null;
    }

    @Override
    public void addSavedMessage(SystemMessage systemMessage, Long l) {

    }




















    /*@Override
    public LinkedList<String> getSystemMessages(SystemMessage systemMessage) {
        return null;
    }

    @Override
    public void addSystemMessage(SystemMessage systemMessage, String s) {

    }*/


















    @Override
    public LinkedList<Long> getLikedTweetsId(SystemMessage systemMessage) {
        return null;
    }

    @Override
    public void addLikedTweet(SystemMessage systemMessage, Long l) {

    }

    @Override
    public LinkedList<Long> getRetweetedTweetsId(SystemMessage systemMessage) {
        return null;
    }

    @Override
    public void addRetweetedTweet(SystemMessage systemMessage, Long l) {

    }

    @Override
    public LinkedList<Long> getMutedUsersId(SystemMessage systemMessage) {
        return null;
    }

    @Override
    public void addMutedUser(SystemMessage systemMessage, Long l) {

    }

    @Override
    public LinkedList<Long> getChatGroupAllMessages(SystemMessage systemMessage) {
        return null;
    }

    @Override
    public void addChatGroupAllMessages(SystemMessage systemMessage, long l) {

    }

    @Override
    public LinkedList<Long> getUser1UnreadMessages(SystemMessage systemMessage) {
        return null;
    }

    @Override
    public void addUser1UnreadMessages(SystemMessage systemMessage, long l) {

    }

    @Override
    public LinkedList<Long> getUser2UnreadMessages(SystemMessage systemMessage) {
        return null;
    }

    @Override
    public void addUser2UnreadMessages(SystemMessage systemMessage, long l) {

    }

    @Override
    public LinkedList<Long> getMembers(SystemMessage systemMessage) {
        return null;
    }

    @Override
    public void addMember(SystemMessage systemMessage, long l) {

    }

    @Override
    public void removeMember(SystemMessage systemMessage, long l) {

    }
}
