package database;

import authentication.model.Profile;
import authentication.model.User;
import model.Date;
import model.DateTime;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.LinkedList;
import java.util.Objects;
import java.util.Scanner;

public class UserDataBase implements DataBaseSet<User>{


    @Override
    public User get(long id) {
            User user= null;
            for ( User myUser : all()) {
                if (myUser.getId() == id){
                    user= myUser;
                }
            }
            return user;
            /*File file =null;
            String path = new File("").getAbsolutePath();
            String usersPath = path + "\\" + "resources\\Users Directory\\";
            Files.createDirectories(Paths.get(usersPath));
            File usersDirectory = new File(usersPath);

            for (File f : Objects.requireNonNull(usersDirectory.listFiles())) {
                if (f.getName().equals(id+".txt")){file=f;break;}
            }
            return get(file);*/
    }












    @Override
    public User get(File file) {
        try{
            Scanner scanner = new Scanner(file);
            int n=1;
            String firstName="", lastName="", userName="", password="", email="", bio="", showLastSeenDate="";
            String showDateOfBirth="", showEmail="", showPhoneNumber="";
            long phoneNumber=-1, id=0;
            Date date=null;
            DateTime dateTime=null;
            boolean privateAccount = false, active = false;
            while (scanner.hasNext() && n<17) {
                String s = scanner.nextLine();
                if (n==1){firstName=s;}
                if (n==2){lastName=s;}
                if (n==3){userName=s;}
                if (n==4){password=s;}
                if (n==5){email=s;}
                if (n==6){
                    if (!s.equals("null")) {
                        date = Date.convertStringToDate(s);
                    }
                    else {date=null;}
                }

                if (n==7){
                    if (!s.equals("null")) {
                        phoneNumber = Long.parseLong(s);
                    }
                    else {phoneNumber = -1;}
                }

                if (n==8){
                    if (!s.equals("null")) {
                        bio = s;
                    }
                    else {bio="";}
                }

                if (n==9){id=Long.parseLong(s);}
                if (n==10){
                    if (s.equals("true")){privateAccount=true;}
                    if (s.equals("false")){privateAccount=false;}
                }
                if (n==11){
                    if (s.equals("true")){active=true;}
                    if (s.equals("false")){active=false;}
                }
                if (n==12){
                    dateTime= DateTime.convertStringToDateTime(s);
                }
                if (n==13){
                    if (s.equals("everybody")){showLastSeenDate="everybody";}
                    if (s.equals("nobody")){showLastSeenDate="nobody";}
                    if (s.equals("followings")){showLastSeenDate="followings";}
                }

                if (n==14){
                    if (s.equals("everybody")){showDateOfBirth="everybody";}
                    if (s.equals("nobody")){showDateOfBirth="nobody";}
                    if (s.equals("followings")){showDateOfBirth="followings";}
                }
                if (n==15){
                    if (s.equals("everybody")){showEmail="everybody";}
                    if (s.equals("nobody")){showEmail="nobody";}
                    if (s.equals("followings")){showEmail="followings";}
                }
                if (n==16){
                    if (s.equals("everybody")){showPhoneNumber="everybody";}
                    if (s.equals("nobody")){showPhoneNumber="nobody";}
                    if (s.equals("followings")){showPhoneNumber="followings";}
                }
                n++;
            }
            scanner.close();

            Profile profile= new Profile(firstName,lastName,email);

            profile.setBiography(bio);
            profile.setPhoneNumber(phoneNumber);
            profile.setDateOfBirth(date);
            profile.setPrivateAccount(privateAccount);
            profile.setActive(active);
            profile.setLastSeenDate(dateTime);
            profile.setShowLastSeenDate(showLastSeenDate);
            profile.setShowDateOfBirth(showDateOfBirth);
            profile.setShowEmail(showEmail);
            profile.setShowPhoneNumber(showPhoneNumber);

            User user= new User(userName,password,profile);
            user.setId(id);


            return user;
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }










    @Override
    public LinkedList<User> all() {
        try {
            LinkedList<User> allUsers = new LinkedList<>();

            String path = new File("").getAbsolutePath();
            String usersPath = path + "\\" + "resources\\Users Directory\\";
            Files.createDirectories(Paths.get(usersPath));
            File usersDirectory = new File(usersPath);

            for (File f : Objects.requireNonNull(usersDirectory.listFiles())) {
                User user = get(f);
                allUsers.add(user);
            }
            return allUsers;
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }







    @Override
    public void add(User user) {
        try {
            String path = new File("").getAbsolutePath();
            String usersPath = path + "\\" + "resources\\Users Directory\\";
            Files.createDirectories(Paths.get(usersPath));
            File usersDirectory = new File(usersPath);

            String userPath = usersDirectory.getAbsolutePath() + "\\" + user.getId() + ".txt";
            File userFile = new File(userPath);
            userFile.getParentFile().mkdirs();
            if (!userFile.exists()) {
                userFile.createNewFile();
            }
            FileOutputStream fout = new FileOutputStream(userFile, false);
            PrintStream out = new PrintStream(fout);

            out.println(user.getProfile().getFirstName());
            out.println(user.getProfile().getLastName());
            out.println(user.getUsername());
            out.println(user.getPassword());
            out.println(user.getProfile().getEmail());

            if (user.getProfile().getDateOfBirth()==null){out.println("null");}
            else {out.println(user.getProfile().getDateOfBirth().toString());}
            if (user.getProfile().getPhoneNumber()==-1){out.println("null");}
            else {out.println(user.getProfile().getPhoneNumber());}
            if (user.getProfile().getBiography().equals("")){out.println("null");}
            else {out.println(user.getProfile().getBiography());}

            out.println(user.getId());
            out.println(user.getProfile().isPrivateAccount());
            out.println(user.getProfile().isActive());
            out.println(user.getProfile().getLastSeenDate().toString());
            out.println(user.getProfile().getShowLastSeenDate());
            out.println(user.getProfile().getShowDateOfBirth());
            out.println(user.getProfile().getShowEmail());
            out.println(user.getProfile().getShowPhoneNumber());

            out.flush();
            out.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }











    @Override
    public void remove(User user) {

    }







    @Override
    public void update(User user) {
        try {
            String path = new File("").getAbsolutePath();
            String usersPath = path + "\\" + "resources\\Users Directory\\";
            Files.createDirectories(Paths.get(usersPath));
            File usersDirectory = new File(usersPath);

            File userFile= null;

            for (File f : Objects.requireNonNull(usersDirectory.listFiles())) {
                if (f.getName().equals(user.getId()+".txt")){userFile=f;break;}
            }

            FileOutputStream fout = new FileOutputStream(userFile, false);
            PrintStream out = new PrintStream(fout);

            out.println(user.getProfile().getFirstName());
            out.println(user.getProfile().getLastName());
            out.println(user.getUsername());
            out.println(user.getPassword());
            out.println(user.getProfile().getEmail());

            if (user.getProfile().getDateOfBirth()==null){out.println("null");}
            else {out.println(user.getProfile().getDateOfBirth().toString());}
            if (user.getProfile().getPhoneNumber()==-1){out.println("null");}
            else {out.println(user.getProfile().getPhoneNumber());}
            if (user.getProfile().getBiography().equals("")){out.println("null");}
            else {out.println(user.getProfile().getBiography());}

            out.println(user.getId());
            out.println(user.getProfile().isPrivateAccount());
            out.println(user.getProfile().isActive());
            out.println(user.getProfile().getLastSeenDate().toString());
            out.println(user.getProfile().getShowLastSeenDate());
            out.println(user.getProfile().getShowDateOfBirth());
            out.println(user.getProfile().getShowEmail());
            out.println(user.getProfile().getShowPhoneNumber());

            out.flush();
            out.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }


























    private File getFollowersFile(User user){
        try {
            String path = new File("").getAbsolutePath();
            String listsPath = path + "\\" + "resources\\Lists Directory\\";
            Files.createDirectories(Paths.get(listsPath));
            File listsDirectory = new File(listsPath);
            File myFile = null;
            for (File f : Objects.requireNonNull(listsDirectory.listFiles())) {
                if (f.getName().equals(String.valueOf(user.getId()))) {
                    for (File file : Objects.requireNonNull(f.listFiles())) {
                        if (file.getName().equals("Followers.txt")) {
                            myFile = file;
                            break;
                        }
                    }
                }
            }
            if (myFile == null) {
                String myPath = new File("").getAbsolutePath();
                String myListsPath = myPath + "\\" + "resources\\Lists Directory\\" + user.getId() + "\\";
                Files.createDirectories(Paths.get(myListsPath));

                String listPath1 = myPath + "\\" + "resources\\Lists Directory\\" + user.getId() + "\\" + "Followers.txt";
                File userFile1 = new File(listPath1);
                userFile1.getParentFile().mkdirs();
                if (!userFile1.exists()) {
                    userFile1.createNewFile();
                }
                myFile = userFile1;
            }
            return myFile;
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }













    @Override
    public LinkedList<Long> getFollowersId(User user) {
        try {
            LinkedList<Long> followersId= new LinkedList<>();
            File file = getFollowersFile(user);
            if (file!=null) {
                Scanner scanner = new Scanner(file);
                while (scanner.hasNext()) {
                    String s = scanner.nextLine();
                    long l = Long.parseLong(s);
                    followersId.add(l);
                }
                scanner.close();
            }
            return followersId;
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }









    @Override
    public void addFollower(User user,Long followerId) {
        try {
            File myFile= getFollowersFile(user);
            FileOutputStream fout = new FileOutputStream(myFile, true);
            PrintStream out = new PrintStream(fout);
            out.println(followerId);
            out.flush();
            out.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }

    }






    @Override
    public void removeFollower(User user, Long l) {
        try {
            File file = getFollowersFile(user);
            Scanner scanner = new Scanner(file);
            LinkedList<String> newFollowersList= new LinkedList<>();
            while (scanner.hasNext()) {
                String s = scanner.nextLine();
                if ( !s.equals (String.valueOf (l) ) ){newFollowersList.add(s);}
            }
            scanner.close();
            FileOutputStream fout = new FileOutputStream(file, false);
            PrintStream out = new PrintStream(fout);
            for (String s: newFollowersList) {
                out.println(s);
            }
            out.flush();
            out.close();
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
























    private File getFollowingsFile(User user){
        try {
            String path = new File("").getAbsolutePath();
            String listsPath = path + "\\" + "resources\\Lists Directory\\";
            Files.createDirectories(Paths.get(listsPath));
            File listsDirectory = new File(listsPath);
            File myFile = null;
            for (File f : Objects.requireNonNull(listsDirectory.listFiles())) {
                if (f.getName().equals(String.valueOf(user.getId()))) {
                    for (File file : Objects.requireNonNull(f.listFiles())) {
                        if (file.getName().equals("Followings.txt")) {
                            myFile = file;
                            break;
                        }
                    }
                }
            }
            if (myFile == null) {
                String myPath = new File("").getAbsolutePath();
                String myListsPath = myPath + "\\" + "resources\\Lists Directory\\" + user.getId() + "\\";
                Files.createDirectories(Paths.get(myListsPath));

                String listPath1 = myPath + "\\" + "resources\\Lists Directory\\" + user.getId() + "\\" + "Followings.txt";
                File userFile1 = new File(listPath1);
                userFile1.getParentFile().mkdirs();
                if (!userFile1.exists()) {
                    userFile1.createNewFile();
                }
                myFile = userFile1;
            }
            return myFile;
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

















    @Override
    public LinkedList<Long> getFollowingsId(User user) {
        try {
            LinkedList<Long> followingsId= new LinkedList<>();
            File file = getFollowingsFile(user);
            if (file!=null) {
                Scanner scanner = new Scanner(file);
                while (scanner.hasNext()) {
                    String s = scanner.nextLine();
                    long l = Long.parseLong(s);
                    followingsId.add(l);
                }
                scanner.close();
            }
            return followingsId;
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }














    @Override
    public void addFollowing(User user, Long followingId) {
        try {
            File myFile= getFollowingsFile(user);
            FileOutputStream fout = new FileOutputStream(myFile, true);
            PrintStream out = new PrintStream(fout);
            out.println(followingId);
            out.flush();
            out.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }






    @Override
    public void removeFollowing(User user, Long l) {
        try {
            File file = getFollowingsFile(user);
            Scanner scanner = new Scanner(file);
            LinkedList<String> newFollowingsList= new LinkedList<>();
            while (scanner.hasNext()) {
                String s = scanner.nextLine();
                if ( !s.equals (String.valueOf (l) ) ){newFollowingsList.add(s);}
            }
            scanner.close();
            FileOutputStream fout = new FileOutputStream(file, false);
            PrintStream out = new PrintStream(fout);
            for (String s: newFollowingsList) {
                out.println(s);
            }
            out.flush();
            out.close();
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }























    private File getBlackListFile(User user){
        try {
            String path = new File("").getAbsolutePath();
            String listsPath = path + "\\" + "resources\\Lists Directory\\";
            Files.createDirectories(Paths.get(listsPath));
            File listsDirectory = new File(listsPath);

            File myFile = null;
            for (File f : Objects.requireNonNull(listsDirectory.listFiles())) {
                if (f.getName().equals(String.valueOf(user.getId()))) {
                    for (File file : Objects.requireNonNull(f.listFiles())) {
                        if (file.getName().equals("BlackList.txt")) {
                            myFile = file;
                            break;
                        }
                    }
                }
            }
            if (myFile == null) {
                String myPath = new File("").getAbsolutePath();
                String myListsPath = myPath + "\\" + "resources\\Lists Directory\\" + user.getId() + "\\";
                Files.createDirectories(Paths.get(myListsPath));

                String listPath1 = myPath + "\\" + "resources\\Lists Directory\\" + user.getId() + "\\" + "BlackList.txt";
                File userFile1 = new File(listPath1);
                userFile1.getParentFile().mkdirs();
                if (!userFile1.exists()) {
                    userFile1.createNewFile();
                }
                myFile = userFile1;
            }
            return myFile;
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }










    @Override
    public LinkedList<Long> getBlackListsId(User user) {
        try {
            LinkedList<Long> blackListsId= new LinkedList<>();
            File file = getBlackListFile(user);
            if (file!=null) {
                Scanner scanner = new Scanner(file);
                while (scanner.hasNext()) {
                    String s = scanner.nextLine();
                    long l = Long.parseLong(s);
                    blackListsId.add(l);
                }
                scanner.close();
            }
            return blackListsId;
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }





    @Override
    public void addBlackList(User user, Long blocked) {
        try {
            File myFile= getBlackListFile(user);
            FileOutputStream fout = new FileOutputStream(myFile, true);
            PrintStream out = new PrintStream(fout);
            out.println(blocked);
            out.flush();
            out.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }






    @Override
    public void removeBlackList(User user, Long l) {
        try {
            File file = getBlackListFile(user);
            Scanner scanner = new Scanner(file);
            LinkedList<String> newBlackList= new LinkedList<>();
            while (scanner.hasNext()) {
                String s = scanner.nextLine();
                if ( !s.equals (String.valueOf (l) ) ){newBlackList.add(s);}
            }
            scanner.close();
            FileOutputStream fout = new FileOutputStream(file, false);
            PrintStream out = new PrintStream(fout);
            for (String s: newBlackList) {
                out.println(s);
            }
            out.flush();
            out.close();
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }






















    private File getSavedMessagesFile(User user){
        try {
            String path= new File("").getAbsolutePath();
            String smPath= path+"\\" + "resources\\Saved Messages Folder\\";
            Files.createDirectories(Paths.get(smPath));
            File savedMessagesFolder = new File(smPath);

            File myFile = null;
            for (File f : Objects.requireNonNull(savedMessagesFolder.listFiles())) {
                if (f.getName().equals(user.getId() +".txt")) {
                    myFile = f;
                    break;
                }
            }
            if (myFile == null) {
                String myPath = savedMessagesFolder.getAbsolutePath() + "\\" + user.getId() + ".txt";
                File file = new File(myPath);
                file.getParentFile().mkdirs();
                if (!file.exists()) {
                    file.createNewFile();
                }
                myFile = file;
            }
            return myFile;
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }










    @Override
    public LinkedList<Long> getSavedMessages(User user) {
        try {
            LinkedList<Long> savedMessagesId= new LinkedList<>();
            File file = getSavedMessagesFile(user);
            if (file!=null) {
                Scanner scanner = new Scanner(file);
                while (scanner.hasNext()) {
                    String s = scanner.nextLine();
                    long l = Long.parseLong(s);
                    savedMessagesId.add(l);
                }
                scanner.close();
            }
            return savedMessagesId;
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }



    @Override
    public void addSavedMessage(User user, Long savedMessageId) {
        try {
            File myFile= getSavedMessagesFile(user);
            FileOutputStream fout = new FileOutputStream(myFile, true);
            PrintStream out = new PrintStream(fout);
            out.println(savedMessageId);
            out.flush();
            out.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
















    /*@Override
    public LinkedList<String> getSystemMessages(User user) {
        return null;
    }

    @Override
    public void addSystemMessage(User recipient, String text) {
        try {
            String path= new File("").getAbsolutePath();
            String myPath= path+"\\" + "resources\\System Messages Folder\\";
            Files.createDirectories(Paths.get(myPath));
            File systemMessagesFolder = new File(myPath);


            File file=null;
            for (File f : Objects.requireNonNull(systemMessagesFolder.listFiles())) {
                if (f.getName().equals(recipient.getId() + ".txt")){
                    file=f;
                }
            }

            if (file==null) {
                String path_ = systemMessagesFolder.getAbsolutePath() + "\\" + recipient.getId() + ".txt";
                File file_ = new File(path_);
                file_.getParentFile().mkdirs();
                if (!file_.exists()) {
                    file_.createNewFile();
                }
                file=file_;
            }

            FileOutputStream fout = new FileOutputStream(file, true);
            PrintStream out = new PrintStream(fout);

            out.println(text);
            out.flush();
            out.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }*/





























    private File getLikedTweetsFile(User user){
        try {
            String path= new File("").getAbsolutePath();
            String myPath= path+"\\" + "resources\\Liked Tweets\\";
            Files.createDirectories(Paths.get(myPath));
            File folder = new File(myPath);

            File myFile = null;
            for (File f : Objects.requireNonNull(folder.listFiles())) {
                if (f.getName().equals(user.getId() +".txt")) {
                    myFile = f;
                    break;
                }
            }
            if (myFile == null) {
                String myPath_ = folder.getAbsolutePath() + "\\" + user.getId() + ".txt";
                File file = new File(myPath_);
                file.getParentFile().mkdirs();
                if (!file.exists()) {
                    file.createNewFile();
                }
                myFile = file;
            }
            return myFile;
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }








    @Override
    public LinkedList<Long> getLikedTweetsId(User user) {
        try {
            LinkedList<Long> list= new LinkedList<>();
            File file = getLikedTweetsFile(user);
            if (file!=null) {
                Scanner scanner = new Scanner(file);
                while (scanner.hasNext()) {
                    String s = scanner.nextLine();
                    long l = Long.parseLong(s);
                    list.add(l);
                }
                scanner.close();
            }
            return list;
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }










    @Override
    public void addLikedTweet(User user, Long id) {
        try {
            File myFile= getLikedTweetsFile(user);
            FileOutputStream fout = new FileOutputStream(myFile, true);
            PrintStream out = new PrintStream(fout);
            out.println(id);
            out.flush();
            out.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }





    private File getRetweetedTweetsFile(User user){
        try {
            String path= new File("").getAbsolutePath();
            String myPath= path+"\\" + "resources\\Retweeted Tweets\\";
            Files.createDirectories(Paths.get(myPath));
            File folder = new File(myPath);

            File myFile = null;
            for (File f : Objects.requireNonNull(folder.listFiles())) {
                if (f.getName().equals(user.getId() +".txt")) {
                    myFile = f;
                    break;
                }
            }
            if (myFile == null) {
                String myPath_ = folder.getAbsolutePath() + "\\" + user.getId() + ".txt";
                File file = new File(myPath_);
                file.getParentFile().mkdirs();
                if (!file.exists()) {
                    file.createNewFile();
                }
                myFile = file;
            }
            return myFile;
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }





    @Override
    public LinkedList<Long> getRetweetedTweetsId(User user) {
        try {
            LinkedList<Long> list= new LinkedList<>();
            File file = getRetweetedTweetsFile(user);
            if (file!=null) {
                Scanner scanner = new Scanner(file);
                while (scanner.hasNext()) {
                    String s = scanner.nextLine();
                    long l = Long.parseLong(s);
                    list.add(l);
                }
                scanner.close();
            }
            return list;
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }















    @Override
    public void addRetweetedTweet(User user, Long id) {
        try {
            File myFile= getRetweetedTweetsFile(user);
            FileOutputStream fout = new FileOutputStream(myFile, true);
            PrintStream out = new PrintStream(fout);
            out.println(id);
            out.flush();
            out.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }






    private File getMutedUsersFile(User user){
        try {
            String path= new File("").getAbsolutePath();
            String myPath= path+"\\" + "resources\\Muted Users\\";
            Files.createDirectories(Paths.get(myPath));
            File folder = new File(myPath);

            File myFile = null;
            for (File f : Objects.requireNonNull(folder.listFiles())) {
                if (f.getName().equals(user.getId() +".txt")) {
                    myFile = f;
                    break;
                }
            }
            if (myFile == null) {
                String myPath_ = folder.getAbsolutePath() + "\\" + user.getId() + ".txt";
                File file = new File(myPath_);
                file.getParentFile().mkdirs();
                if (!file.exists()) {
                    file.createNewFile();
                }
                myFile = file;
            }
            return myFile;
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }













    @Override
    public LinkedList<Long> getMutedUsersId(User user) {
        try {
            LinkedList<Long> list= new LinkedList<>();
            File file = getMutedUsersFile(user);
            if (file!=null) {
                Scanner scanner = new Scanner(file);
                while (scanner.hasNext()) {
                    String s = scanner.nextLine();
                    long l = Long.parseLong(s);
                    list.add(l);
                }
                scanner.close();
            }
            return list;
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }










    @Override
    public void addMutedUser(User user, Long id) {
        try {
            File myFile= getMutedUsersFile(user);
            FileOutputStream fout = new FileOutputStream(myFile, true);
            PrintStream out = new PrintStream(fout);
            out.println(id);
            out.flush();
            out.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public LinkedList<Long> getChatGroupAllMessages(User user) {
        return null;
    }

    @Override
    public void addChatGroupAllMessages(User user, long l) {

    }

    @Override
    public LinkedList<Long> getUser1UnreadMessages(User user) {
        return null;
    }

    @Override
    public void addUser1UnreadMessages(User user, long l) {

    }

    @Override
    public LinkedList<Long> getUser2UnreadMessages(User user) {
        return null;
    }

    @Override
    public void addUser2UnreadMessages(User user, long l) {

    }

    @Override
    public LinkedList<Long> getMembers(User user) {
        return null;
    }

    @Override
    public void addMember(User user, long l) {

    }

    @Override
    public void removeMember(User user, long l) {

    }
}
