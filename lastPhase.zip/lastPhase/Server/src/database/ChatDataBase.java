package database;

import message.model.Chat;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.LinkedList;
import java.util.Objects;
import java.util.Scanner;

public class ChatDataBase implements DataBaseSet<Chat>{


    private File getMainFile(long id){
        try {
            String path = new File("").getAbsolutePath();
            String chatPath = path + "\\" + "resources\\Chats Directory\\" + id + "\\";
            Files.createDirectories(Paths.get(chatPath));
            File chatDirectory = new File(chatPath);

            File file = null;
            for (File f : Objects.requireNonNull(chatDirectory.listFiles())) {
                if (f.getName().equals(id + ".txt")) {
                    file = f;
                }
            }
            return file;
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }






    @Override
    public Chat get(long id) {
        return loadUsersOfChat(getMainFile(id));
    }











    @Override
    public Chat get(File file) {
        /*Chat chat = null;
        for (File f : Objects.requireNonNull(file.listFiles())){
            if (f.getName().equals(file.getName()+".txt")){chat=loadUsersOfChat(f);}
        }
        return chat;*/
        return null;
    }











    private Chat loadUsersOfChat(File file){
        try {
            Scanner s= new Scanner(file);
            Chat chat= null;

            int n=1;
            long chatId = 0, user1Id = 0, user2Id = 0;
            while (s.hasNext()){
                String str= s.nextLine();
                if (n==1){chatId= Long.parseLong(str);}
                if (n==2){user1Id= Long.parseLong(str);}
                if (n==3){user2Id= Long.parseLong(str);}
                n++;
            }
            s.close();
            chat= new Chat(user1Id,user2Id);
            chat.setId(chatId);
            return chat;
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }


























    @Override
    public LinkedList<Chat> all() {
        try {
            LinkedList<Chat> chats= new LinkedList<>();

            String path = new File("").getAbsolutePath();
            String chatsPath = path + "\\" + "resources\\Chats Directory\\";
            Files.createDirectories(Paths.get(chatsPath));
            File chatsDirectory = new File(chatsPath);

            for (File f : Objects.requireNonNull(chatsDirectory.listFiles())) {
                if (f != null) {
                    Chat chat= loadUsersOfChat(getMainFile(Long.parseLong(f.getName())));
                    chats.add(chat);
                }
            }
            return chats;
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }











    @Override
    public void add(Chat myChat) {
        try {
            String path = new File("").getAbsolutePath();

            String un1 = path + "\\" + "resources\\Chats Directory\\"+myChat.getId()+"\\" + "user 1 Unread Messages.txt";
            File unread1 = new File(un1);
            unread1.getParentFile().mkdirs();
            if (!unread1.exists()) {
                unread1.createNewFile();
            }

            String un2 = path + "\\" + "resources\\Chats Directory\\"+myChat.getId()+"\\" + "user 2 Unread Messages.txt";
            File unread2 = new File(un2);
            unread2.getParentFile().mkdirs();
            if (!unread2.exists()) {
                unread2.createNewFile();
            }

            String chatPath= path+"\\" + "resources\\Chats Directory\\"+myChat.getId()+"\\" +myChat.getId()+".txt";
            File chatFile= new File(chatPath);
            chatFile.getParentFile().mkdirs();
            if (!chatFile.exists()) {
                chatFile.createNewFile();
            }
            FileOutputStream fout = new FileOutputStream(chatFile, false);
            PrintStream out = new PrintStream(fout);

            out.println(myChat.getId());
            out.println(myChat.getUser1().getId());
            out.println(myChat.getUser2().getId());
            out.flush();
            out.close();

            String allMessages= path+"\\" + "resources\\Chats Directory\\"+myChat.getId()+"\\" +"all Messages.txt";
            File allMessagesFile= new File(allMessages);
            allMessagesFile.getParentFile().mkdirs();
            if (!allMessagesFile.exists()) {
                allMessagesFile.createNewFile();
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }





























    @Override
    public void remove(Chat chat) {

    }

    @Override
    public void update(Chat chat) {

    }

    @Override
    public LinkedList<Long> getFollowersId(Chat chat) {
        return null;
    }

    @Override
    public void addFollower(Chat chat, Long l) {

    }

    @Override
    public void removeFollower(Chat chat, Long l) {

    }

    @Override
    public LinkedList<Long> getFollowingsId(Chat chat) {
        return null;
    }

    @Override
    public void addFollowing(Chat chat, Long l) {

    }

    @Override
    public void removeFollowing(Chat chat, Long l) {

    }

    @Override
    public LinkedList<Long> getBlackListsId(Chat chat) {
        return null;
    }

    @Override
    public void addBlackList(Chat chat, Long l) {

    }

    @Override
    public void removeBlackList(Chat chat, Long l) {

    }

    @Override
    public LinkedList<Long> getSavedMessages(Chat chat) {
        return null;
    }

    @Override
    public void addSavedMessage(Chat chat, Long l) {

    }

    /*@Override
    public LinkedList<String> getSystemMessages(Chat chat) {
        return null;
    }

    @Override
    public void addSystemMessage(Chat chat, String s) {

    }*/

    @Override
    public LinkedList<Long> getLikedTweetsId(Chat chat) {
        return null;
    }

    @Override
    public void addLikedTweet(Chat chat, Long l) {

    }

    @Override
    public LinkedList<Long> getRetweetedTweetsId(Chat chat) {
        return null;
    }

    @Override
    public void addRetweetedTweet(Chat chat, Long l) {

    }

    @Override
    public LinkedList<Long> getMutedUsersId(Chat chat) {
        return null;
    }

    @Override
    public void addMutedUser(Chat chat, Long l) {

    }














    @Override
    public LinkedList<Long> getChatGroupAllMessages(Chat chat) {
        try {
            LinkedList<Long> list= new LinkedList<>();
            if (chat != null && get_All_Messages_File(chat) != null) {
                Scanner scanner = new Scanner(Objects.requireNonNull(get_All_Messages_File(chat)));
                while (scanner.hasNext()) {
                    String s = scanner.nextLine();
                    long id = Long.parseLong(s);
                    list.add(id);
                }
                scanner.close();
            }
            return list;
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }














    @Override
    public void addChatGroupAllMessages(Chat chat, long id) {
        try {
            File file= get_All_Messages_File(chat);
            FileOutputStream fout = null;
            if (file != null) {
                fout = new FileOutputStream(file, true);
            }
            PrintStream out = new PrintStream(fout);
            out.println(id);
            out.flush();
            out.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
















    private File get_All_Messages_File(Chat chat){
        try {
            String path = new File("").getAbsolutePath();
            String allMessages = path + "\\" + "resources\\Chats Directory\\" + chat.getId() + "\\" + "all Messages.txt";
            File allMessagesFile = new File(allMessages);

            allMessagesFile.getParentFile().mkdirs();
            if (!allMessagesFile.exists()) {
                allMessagesFile.createNewFile();
            }
            return allMessagesFile;
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }



























    @Override
    public LinkedList<Long> getUser1UnreadMessages(Chat chat) {
        try {
            LinkedList<Long> list= new LinkedList<>();

            if (get_User1_Unread_Messages_File(chat)!=null) {
                Scanner scanner = new Scanner(Objects.requireNonNull(get_User1_Unread_Messages_File(chat)));
                while (scanner.hasNext()) {
                    String s = scanner.nextLine();
                    if (!s.equals("")) {
                        long id = Long.parseLong(s);
                        list.add(id);
                    }
                }
                scanner.close();
            }
            return list;
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }










    @Override
    public void addUser1UnreadMessages(Chat chat, long id) {
        try {
            File file = get_User1_Unread_Messages_File(chat);
            FileOutputStream fout = null;
            if (file != null) {
                fout = new FileOutputStream(file, true);
            }
            PrintStream out = new PrintStream(fout);
            out.println(id);
            out.flush();
            out.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }








    private File get_User1_Unread_Messages_File(Chat chat){
        try {
            String path = new File("").getAbsolutePath();
            String un1 = path + "\\" + "resources\\Chats Directory\\"+chat.getId()+"\\" + "user 1 Unread Messages.txt";

            File unread1 = new File(un1);

            unread1.getParentFile().mkdirs();
            if (!unread1.exists()) {
                unread1.createNewFile();
            }
            return unread1;
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }





























    @Override
    public LinkedList<Long> getUser2UnreadMessages(Chat chat) {
        try {
            LinkedList<Long> list= new LinkedList<>();
            if (get_User2_Unread_Messages_File(chat)!=null) {
                Scanner scanner = new Scanner(get_User2_Unread_Messages_File(chat));
                while (scanner.hasNext()) {
                    String s = scanner.nextLine();
                    if (!s.equals("")) {
                        long id = Long.parseLong(s);
                        list.add(id);
                    }
                }
                scanner.close();
            }
            return list;
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }























    @Override
    public void addUser2UnreadMessages(Chat chat, long id) {
        try {
            File file= get_User2_Unread_Messages_File(chat);
            FileOutputStream fout = new FileOutputStream(file, true);
            PrintStream out = new PrintStream(fout);
            out.println(id);
            out.flush();
            out.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }






    public File get_User2_Unread_Messages_File(Chat chat){
        try {
            String path = new File("").getAbsolutePath();
            String un2 = path + "\\" + "resources\\Chats Directory\\"+chat.getId()+"\\" + "user 2 Unread Messages.txt";
            File unread2 = new File(un2);
            unread2.getParentFile().mkdirs();
            if (!unread2.exists()) {
                unread2.createNewFile();
            }
            return unread2;
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }























    @Override
    public LinkedList<Long> getMembers(Chat chat) {
        return null;
    }

    @Override
    public void addMember(Chat chat, long l) {

    }

    @Override
    public void removeMember(Chat chat, long l) {

    }
}
