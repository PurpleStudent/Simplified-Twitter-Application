package database;

import model.DateTime;
import tweet.model.Tweet;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.LinkedList;
import java.util.Objects;
import java.util.Scanner;

public class TweetDataBase implements DataBaseSet<Tweet>{


    @Override
    public Tweet get(long id) {
        try {
            String path = new File("").getAbsolutePath();
            String tweetsPath = path + "\\" + "resources\\Tweets Folder\\";
            Files.createDirectories(Paths.get(tweetsPath));
            File tweetsFolder = new File(tweetsPath);

            File file = null;
            for (File f : Objects.requireNonNull(tweetsFolder.listFiles())) {
                if (f.getName().equals(id + ".txt")) {
                    file = f;
                }
            }
            return get(file);
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
















    @Override
    public Tweet get(File file) {
        try{
            Scanner scanner = new Scanner(file);
            int n=1;
            String text="";
            long id=-1, creatorUserId=-1, reportNumber=-1;
            DateTime dateTime= null;

            while (scanner.hasNext() && n<6) {
                String s = scanner.nextLine();
                if (n==1){creatorUserId=Long.parseLong(s);}
                if (n==2){id=Long.parseLong(s);}
                if (n==3){dateTime= DateTime.convertStringToDateTime(s);}
                if (n==4){text=s;}
                if (n==5){reportNumber=Long.parseLong(s);}
                n++;
            }
            scanner.close();

            Tweet tweet= new Tweet(creatorUserId,text);

            tweet.setId(id);
            tweet.setDateTimeOfCreation(dateTime);
            tweet.setReportNumber(reportNumber);

            return tweet;
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }















    @Override
    public LinkedList<Tweet> all() {
        try {
            LinkedList<Tweet> allTweets= new LinkedList<>();

            String path = new File("").getAbsolutePath();
            String tweetsPath = path + "\\" + "resources\\Tweets Folder\\";
            Files.createDirectories(Paths.get(tweetsPath));
            File tweetsFolder = new File(tweetsPath);

            for (File f : Objects.requireNonNull(tweetsFolder.listFiles())) {
                Tweet tweet = get(f);
                allTweets.add(tweet);
            }
            return allTweets;
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }















    @Override
    public void add(Tweet tweet) {
        try {
            String path = new File("").getAbsolutePath();
            String tweetsPath = path + "\\" + "resources\\Tweets Folder\\";
            Files.createDirectories(Paths.get(tweetsPath));
            File tweetsFolder = new File(tweetsPath);

            String tweetPath = tweetsFolder.getAbsolutePath() + "\\" + tweet.getId() + ".txt";
            File tweetFile = new File(tweetPath);
            tweetFile.getParentFile().mkdirs();
            if (!tweetFile.exists()) {
                tweetFile.createNewFile();
            }
            FileOutputStream fout = new FileOutputStream(tweetFile, false);
            PrintStream out = new PrintStream(fout);

            out.println(tweet.getCreatorUserId());
            out.println(tweet.getId());
            out.println(tweet.getDateTimeOfCreation().toString());
            out.println(tweet.getText());
            out.println(tweet.getReportNumber());

            out.flush();
            out.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }






    @Override
    public void remove(Tweet tweet) {

    }



















    @Override
    public void update(Tweet tweet) {
        try {
            String path = new File("").getAbsolutePath();
            String tweetsPath = path + "\\" + "resources\\Tweets Folder\\";
            Files.createDirectories(Paths.get(tweetsPath));
            File tweetsFolder = new File(tweetsPath);

            File tweetFile= null;

            for (File f : Objects.requireNonNull(tweetsFolder.listFiles())) {
                if (f.getName().equals(tweet.getId()+".txt")){tweetFile=f;break;}
            }

            FileOutputStream fout = new FileOutputStream(tweetFile, false);
            PrintStream out = new PrintStream(fout);

            out.println(tweet.getCreatorUserId());
            out.println(tweet.getId());
            out.println(tweet.getDateTimeOfCreation().toString());
            out.println(tweet.getText());
            out.println(tweet.getReportNumber());

            out.flush();
            out.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }




































    @Override
    public LinkedList<Long> getFollowersId(Tweet tweet) {
        return null;
    }

    @Override
    public void addFollower(Tweet tweet, Long l) {

    }

    @Override
    public void removeFollower(Tweet tweet, Long l) {

    }

    @Override
    public LinkedList<Long> getFollowingsId(Tweet tweet) {
        return null;
    }

    @Override
    public void addFollowing(Tweet tweet, Long l) {

    }

    @Override
    public void removeFollowing(Tweet tweet, Long l) {

    }

    @Override
    public LinkedList<Long> getBlackListsId(Tweet tweet) {
        return null;
    }

    @Override
    public void addBlackList(Tweet tweet, Long l) {

    }

    @Override
    public void removeBlackList(Tweet tweet, Long l) {

    }

    @Override
    public LinkedList<Long> getSavedMessages(Tweet tweet) {
        return null;
    }

    @Override
    public void addSavedMessage(Tweet tweet, Long l) {

    }

    /*@Override
    public LinkedList<String> getSystemMessages(Tweet tweet) {
        return null;
    }

    @Override
    public void addSystemMessage(Tweet tweet, String s) {

    }*/

    @Override
    public LinkedList<Long> getLikedTweetsId(Tweet tweet) {
        return null;
    }

    @Override
    public void addLikedTweet(Tweet tweet, Long l) {

    }

    @Override
    public LinkedList<Long> getRetweetedTweetsId(Tweet tweet) {
        return null;
    }

    @Override
    public void addRetweetedTweet(Tweet tweet, Long l) {

    }

    @Override
    public LinkedList<Long> getMutedUsersId(Tweet tweet) {
        return null;
    }

    @Override
    public void addMutedUser(Tweet tweet, Long l) {

    }

    @Override
    public LinkedList<Long> getChatGroupAllMessages(Tweet tweet) {
        return null;
    }

    @Override
    public void addChatGroupAllMessages(Tweet tweet, long l) {

    }

    @Override
    public LinkedList<Long> getUser1UnreadMessages(Tweet tweet) {
        return null;
    }

    @Override
    public void addUser1UnreadMessages(Tweet tweet, long l) {

    }

    @Override
    public LinkedList<Long> getUser2UnreadMessages(Tweet tweet) {
        return null;
    }

    @Override
    public void addUser2UnreadMessages(Tweet tweet, long l) {

    }

    @Override
    public LinkedList<Long> getMembers(Tweet tweet) {
        return null;
    }

    @Override
    public void addMember(Tweet tweet, long l) {

    }

    @Override
    public void removeMember(Tweet tweet, long l) {

    }
}
