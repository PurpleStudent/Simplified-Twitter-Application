package database;

import java.io.File;
import java.util.LinkedList;

public interface DataBaseSet<T> {

    T get(long id);
    T get(File file);
    LinkedList<T> all();
    void add(T t);
    void remove(T t);
    void update(T t);

    LinkedList<Long> getFollowersId(T t);
    void addFollower(T t,Long l);
    void removeFollower(T t,Long l);

    LinkedList<Long> getFollowingsId(T t);
    void addFollowing(T t,Long l);
    void removeFollowing(T t,Long l);

    LinkedList<Long> getBlackListsId(T t);
    void addBlackList(T t,Long l);
    void removeBlackList(T t,Long l);

    LinkedList<Long> getSavedMessages(T t);
    void addSavedMessage(T t,Long l);

    LinkedList<Long> getLikedTweetsId(T t);
    void addLikedTweet(T t,Long l);

    LinkedList<Long> getRetweetedTweetsId(T t);
    void addRetweetedTweet(T t,Long l);

    LinkedList<Long> getMutedUsersId(T t);
    void addMutedUser(T t,Long l);

    LinkedList<Long> getChatGroupAllMessages(T t);
    void addChatGroupAllMessages(T t,long l);

    LinkedList<Long> getUser1UnreadMessages(T t);
    void addUser1UnreadMessages(T t,long l);

    LinkedList<Long> getUser2UnreadMessages(T t);
    void addUser2UnreadMessages(T t,long l);

    LinkedList<Long> getMembers(T t);
    void addMember(T t,long l);
    void removeMember(T t,long l);
}
