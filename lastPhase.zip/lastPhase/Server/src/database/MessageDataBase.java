package database;

import message.model.Message;
import model.DateTime;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.LinkedList;
import java.util.Objects;
import java.util.Scanner;

public class MessageDataBase implements DataBaseSet<Message>{


    @Override
    public Message get(long id) {
            Message message= null;
            for (Message myMessage : all()) {
                if (myMessage.getId() == id){
                    message= myMessage;
                }
            }
            return message;
            /*String path = new File("").getAbsolutePath();
            String messagesPath = path + "\\" + "resources\\Messages Folder\\";
            Files.createDirectories(Paths.get(messagesPath));
            File folder = new File(messagesPath);

            File file = null;
            for (File f : Objects.requireNonNull(folder.listFiles())) {
                if (f.getName().equals(id + ".txt")) {
                    file = f;
                }
            }
            return get(file);*/
    }










    @Override
    public Message get(File file) {
        try{
            Scanner scanner = new Scanner(file);
            int n=1;
            String text="";
            long id=-1, creatorUserId=-1, recipientUserId=-1;
            DateTime dateTime= null;
            while (scanner.hasNext() && n<6) {
                String s = scanner.nextLine();
                if (n==1){creatorUserId=Long.parseLong(s);}

                if (n==2){
                    if (s.equals("null")){recipientUserId=-1;}
                    else {recipientUserId=Long.parseLong(s);}
                }

                if (n==3){id=Long.parseLong(s);}
                if (n==4){dateTime= DateTime.convertStringToDateTime(s);}
                if (n==5){text=s;}
                n++;
            }
            scanner.close();
            Message message= new Message(creatorUserId,text,recipientUserId);
            message.setId(id);
            message.setDateTimeOfCreation(dateTime);
            return message;
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }























    @Override
    public LinkedList<Message> all() {
        try {
            LinkedList<Message> all= new LinkedList<>();

            String path = new File("").getAbsolutePath();
            String messagesPath = path + "\\" + "resources\\Messages Folder\\";
            Files.createDirectories(Paths.get(messagesPath));
            File folder = new File(messagesPath);

            for (File f : Objects.requireNonNull(folder.listFiles())) {
                Message message = get(f);
                all.add(message);
            }
            return all;
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }












    @Override
    public void add(Message message) {
        try {
            String path = new File("").getAbsolutePath();
            String messagesPath = path+"\\"+"resources\\Messages Folder\\";
            Files.createDirectories(Paths.get(messagesPath));
            File messagesFolder = new File(messagesPath);

            String messagePath = messagesFolder.getAbsolutePath() + "\\" + message.getId() + ".txt";
            File messageFile = new File(messagePath);
            messageFile.getParentFile().mkdirs();
            if (!messageFile.exists()) {
                messageFile.createNewFile();
            }
            FileOutputStream fout = new FileOutputStream(messageFile, false);
            PrintStream out = new PrintStream(fout);

            out.println(message.getCreatorUserId());
            if (message.getRecipientUser()==null) {out.println("null");}
            else {out.println(message.getRecipientUser().getId());}
            out.println(message.getId());
            out.println(message.getDateTimeOfCreation().toString());
            out.println(message.getText());

            out.flush();
            out.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }













    @Override
    public void remove(Message message) {
        try {
            String path = new File("").getAbsolutePath();
            String messagesPath = path + "\\" + "resources\\Messages Folder\\";
            Files.createDirectories(Paths.get(messagesPath));
            File folder = new File(messagesPath);

            File file = null;
            for (File f : Objects.requireNonNull(folder.listFiles())) {
                if (f.getName().equals(message.getId() + ".txt")) {
                    file = f;
                }
            }
            if (file != null) {
                file.delete();
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }























    @Override
    public void update(Message message) {

    }

    @Override
    public LinkedList<Long> getFollowersId(Message message) {
        return null;
    }

    @Override
    public void addFollower(Message message, Long l) {

    }

    @Override
    public void removeFollower(Message message, Long l) {

    }

    @Override
    public LinkedList<Long> getFollowingsId(Message message) {
        return null;
    }

    @Override
    public void addFollowing(Message message, Long l) {

    }

    @Override
    public void removeFollowing(Message message, Long l) {

    }

    @Override
    public LinkedList<Long> getBlackListsId(Message message) {
        return null;
    }

    @Override
    public void addBlackList(Message message, Long l) {

    }

    @Override
    public void removeBlackList(Message message, Long l) {

    }

    @Override
    public LinkedList<Long> getSavedMessages(Message message) {
        return null;
    }

    @Override
    public void addSavedMessage(Message message, Long l) {

    }

    /*@Override
    public LinkedList<String> getSystemMessages(Message message) {
        return null;
    }

    @Override
    public void addSystemMessage(Message message, String s) {

    }*/

    @Override
    public LinkedList<Long> getLikedTweetsId(Message message) {
        return null;
    }

    @Override
    public void addLikedTweet(Message message, Long l) {

    }

    @Override
    public LinkedList<Long> getRetweetedTweetsId(Message message) {
        return null;
    }

    @Override
    public void addRetweetedTweet(Message message, Long l) {

    }

    @Override
    public LinkedList<Long> getMutedUsersId(Message message) {
        return null;
    }

    @Override
    public void addMutedUser(Message message, Long l) {

    }

    @Override
    public LinkedList<Long> getChatGroupAllMessages(Message message) {
        return null;
    }

    @Override
    public void addChatGroupAllMessages(Message message, long l) {

    }

    @Override
    public LinkedList<Long> getUser1UnreadMessages(Message message) {
        return null;
    }

    @Override
    public void addUser1UnreadMessages(Message message, long l) {

    }

    @Override
    public LinkedList<Long> getUser2UnreadMessages(Message message) {
        return null;
    }

    @Override
    public void addUser2UnreadMessages(Message message, long l) {

    }

    @Override
    public LinkedList<Long> getMembers(Message message) {
        return null;
    }

    @Override
    public void addMember(Message message, long l) {

    }

    @Override
    public void removeMember(Message message, long l) {

    }
}
