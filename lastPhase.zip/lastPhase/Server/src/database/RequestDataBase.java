package database;

import request.model.Request;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.LinkedList;
import java.util.Objects;
import java.util.Scanner;

public class RequestDataBase implements DataBaseSet<Request>{


    @Override
    public Request get(long id) {
        try {
            String path= new File("").getAbsolutePath();
            String rPath= path+"\\"+"resources\\Requests Folder\\";
            Files.createDirectories(Paths.get(rPath));
            File requestsFolder = new File(rPath);

            File file = null;
            for (File f : Objects.requireNonNull(requestsFolder.listFiles())) {
                if (f.getName().equals(id + ".txt")) {
                    file = f;
                }
            }
            return get(file);
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }




















    @Override
    public Request get(File file) {
        try {
            Scanner scanner = new Scanner(file);
            int n=1;
            long requesterId=-1, requestedId=-1, id=-1;
            String text="";

            while (scanner.hasNext()){
                String s = scanner.nextLine();

                if (n==1){requesterId=Long.parseLong(s);}
                if (n==2){requestedId=Long.parseLong(s);}
                if (n==3){id=Long.parseLong(s);}
                if (n==4){text=s;}

                n++;
            }
            scanner.close();
            Request request= new Request(requesterId,requestedId);
            request.setId(id);
            request.setText(text);

            return request;
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }

















    @Override
    public LinkedList<Request> all() {
        try {
            LinkedList<Request> all= new LinkedList<>();

            String path= new File("").getAbsolutePath();
            String rPath= path+"\\"+"resources\\Requests Folder\\";
            Files.createDirectories(Paths.get(rPath));
            File requestsFolder = new File(rPath);

            for (File f : Objects.requireNonNull(requestsFolder.listFiles())) {
                Request request = get(f);
                all.add(request);
            }
            return all;
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }























    @Override
    public void add(Request request) {
        try {
            String path= new File("").getAbsolutePath();
            String rPath= path+"\\"+"resources\\Requests Folder\\";
            Files.createDirectories(Paths.get(rPath));
            File requestsFolder = new File(rPath);

            String myPath = requestsFolder.getAbsolutePath() + "\\" + request.getId() + ".txt";
            File file = new File(myPath);
            file.getParentFile().mkdirs();
            if (!file.exists()) {
                file.createNewFile();
            }

            FileOutputStream fout = new FileOutputStream(file, false);
            PrintStream out = new PrintStream(fout);

            out.println(request.getRequesterId());
            out.println(request.getRequestedId());
            out.println(request.getId());
            out.println(request.getText());

            out.flush();
            out.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

























    @Override
    public void remove(Request request) {
        try {
            String path= new File("").getAbsolutePath();
            String rPath= path+"\\"+"resources\\Requests Folder\\";
            Files.createDirectories(Paths.get(rPath));
            File requestsFolder = new File(rPath);

            File file = null;
            for (File f : Objects.requireNonNull(requestsFolder.listFiles())) {
                if (f.getName().equals(request.getId() + ".txt")) {
                    file = f;
                }
            }
            if (file != null) {
                file.delete();
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }




















    @Override
    public void update(Request request) {

    }

    @Override
    public LinkedList<Long> getFollowersId(Request request) {
        return null;
    }

    @Override
    public void addFollower(Request request, Long l) {

    }

    @Override
    public void removeFollower(Request request, Long l) {

    }

    @Override
    public LinkedList<Long> getFollowingsId(Request request) {
        return null;
    }

    @Override
    public void addFollowing(Request request, Long l) {

    }

    @Override
    public void removeFollowing(Request request, Long l) {

    }

    @Override
    public LinkedList<Long> getBlackListsId(Request request) {
        return null;
    }

    @Override
    public void addBlackList(Request request, Long l) {

    }

    @Override
    public void removeBlackList(Request request, Long l) {

    }

    @Override
    public LinkedList<Long> getSavedMessages(Request request) {
        return null;
    }

    @Override
    public void addSavedMessage(Request request, Long l) {

    }

    /*@Override
    public LinkedList<String> getSystemMessages(Request request) {
        return null;
    }

    @Override
    public void addSystemMessage(Request request, String s) {

    }*/

    @Override
    public LinkedList<Long> getLikedTweetsId(Request request) {
        return null;
    }

    @Override
    public void addLikedTweet(Request request, Long l) {

    }

    @Override
    public LinkedList<Long> getRetweetedTweetsId(Request request) {
        return null;
    }

    @Override
    public void addRetweetedTweet(Request request, Long l) {

    }

    @Override
    public LinkedList<Long> getMutedUsersId(Request request) {
        return null;
    }

    @Override
    public void addMutedUser(Request request, Long l) {

    }

    @Override
    public LinkedList<Long> getChatGroupAllMessages(Request request) {
        return null;
    }

    @Override
    public void addChatGroupAllMessages(Request request, long l) {

    }

    @Override
    public LinkedList<Long> getUser1UnreadMessages(Request request) {
        return null;
    }

    @Override
    public void addUser1UnreadMessages(Request request, long l) {

    }

    @Override
    public LinkedList<Long> getUser2UnreadMessages(Request request) {
        return null;
    }

    @Override
    public void addUser2UnreadMessages(Request request, long l) {

    }

    @Override
    public LinkedList<Long> getMembers(Request request) {
        return null;
    }

    @Override
    public void addMember(Request request, long l) {

    }

    @Override
    public void removeMember(Request request, long l) {

    }
}
