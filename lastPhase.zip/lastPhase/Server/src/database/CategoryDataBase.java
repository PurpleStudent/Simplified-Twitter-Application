package database;

import category.model.Category;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.LinkedList;
import java.util.Objects;
import java.util.Scanner;

public class CategoryDataBase implements DataBaseSet<Category>{


    @Override
    public Category get(long id) {
        try {
            String path= new File("").getAbsolutePath();
            String cPath= path+"\\" + "resources\\Categories Folder\\";
            Files.createDirectories(Paths.get(cPath));
            File categoriesFolder = new File(cPath);

            File file = null;
            for (File f : Objects.requireNonNull(categoriesFolder.listFiles())) {
                if (f.getName().equals(id + ".txt")) {
                    file = f;
                }
            }
            return get(file);
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }


















    @Override
    public Category get(File file) {
        try{
            Scanner scanner = new Scanner(file);
            int n=1;
            String categoryName="";
            long id=-1, creatorUserId=-1;
            while (scanner.hasNext() && n<4) {
                String s = scanner.nextLine();
                if (n==1){creatorUserId=Long.parseLong(s);}
                if (n==2){id=Long.parseLong(s);}
                if (n==3){categoryName= s;}
                n++;
            }
            scanner.close();
            Category category= new Category(categoryName,creatorUserId);
            category.setId(id);
            return category;
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }
























    @Override
    public LinkedList<Category> all() {
        try {
            LinkedList<Category> all= new LinkedList<>();

            String path= new File("").getAbsolutePath();
            String cPath= path+"\\" + "resources\\Categories Folder\\";
            Files.createDirectories(Paths.get(cPath));
            File categoriesFolder = new File(cPath);

            for (File f : Objects.requireNonNull(categoriesFolder.listFiles())) {
                Category category = get(f);
                all.add(category);
            }
            return all;
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }


















    @Override
    public void add(Category category) {
        try {
            String path= new File("").getAbsolutePath();
            String cPath= path+"\\" + "resources\\Categories Folder\\";
            Files.createDirectories(Paths.get(cPath));
            File categoriesFolder = new File(cPath);

            String path_category = categoriesFolder.getAbsolutePath() + "\\"+ category.getId() + ".txt";
            File file = new File(path_category);
            file.getParentFile().mkdirs();
            if (!file.exists()) {
                file.createNewFile();
            }
            FileOutputStream fout = new FileOutputStream(file, false);
            PrintStream out = new PrintStream(fout);

            out.println(category.getUser().getId());
            out.println(category.getId());
            out.println(category.getCategoryName());

            out.flush();
            out.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }






























    @Override
    public void remove(Category category) {

    }

    @Override
    public void update(Category category) {

    }

    @Override
    public LinkedList<Long> getFollowersId(Category category) {
        return null;
    }

    @Override
    public void addFollower(Category category, Long l) {

    }

    @Override
    public void removeFollower(Category category, Long l) {

    }

    @Override
    public LinkedList<Long> getFollowingsId(Category category) {
        return null;
    }

    @Override
    public void addFollowing(Category category, Long l) {

    }

    @Override
    public void removeFollowing(Category category, Long l) {

    }

    @Override
    public LinkedList<Long> getBlackListsId(Category category) {
        return null;
    }

    @Override
    public void addBlackList(Category category, Long l) {

    }

    @Override
    public void removeBlackList(Category category, Long l) {

    }

    @Override
    public LinkedList<Long> getSavedMessages(Category category) {
        return null;
    }

    @Override
    public void addSavedMessage(Category category, Long l) {

    }

    /*@Override
    public LinkedList<String> getSystemMessages(Category category) {
        return null;
    }

    @Override
    public void addSystemMessage(Category category, String s) {

    }*/

    @Override
    public LinkedList<Long> getLikedTweetsId(Category category) {
        return null;
    }

    @Override
    public void addLikedTweet(Category category, Long l) {

    }

    @Override
    public LinkedList<Long> getRetweetedTweetsId(Category category) {
        return null;
    }

    @Override
    public void addRetweetedTweet(Category category, Long l) {

    }

    @Override
    public LinkedList<Long> getMutedUsersId(Category category) {
        return null;
    }

    @Override
    public void addMutedUser(Category category, Long l) {

    }

    @Override
    public LinkedList<Long> getChatGroupAllMessages(Category category) {
        return null;
    }

    @Override
    public void addChatGroupAllMessages(Category category, long l) {

    }

    @Override
    public LinkedList<Long> getUser1UnreadMessages(Category category) {
        return null;
    }

    @Override
    public void addUser1UnreadMessages(Category category, long l) {

    }

    @Override
    public LinkedList<Long> getUser2UnreadMessages(Category category) {
        return null;
    }

    @Override
    public void addUser2UnreadMessages(Category category, long l) {

    }



    @Override
    public LinkedList<Long> getMembers(Category category) {
        try {
            String path= new File("").getAbsolutePath();
            String cPath= path+"\\" + "resources\\Categories Folder\\";
            Files.createDirectories(Paths.get(cPath));
            File categoriesFolder = new File(cPath);

            File categoryFile = null;

            for (File file : Objects.requireNonNull(categoriesFolder.listFiles())) {
                if (file != null && file.getName().equals(category.getId()+".txt")) {
                    categoryFile = file;
                }
            }

            return loadMembers(categoryFile);
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }






    private LinkedList<Long> loadMembers(File file){
        try {
            Scanner s= new Scanner(file);
            LinkedList<Long> list= new LinkedList<>();
            int n=1;

            long categoryUserId = 0;
            long categoryId = 0;
            String categoryName = "";

            while (s.hasNext()){
                String str= s.nextLine();
                if (n==1){categoryUserId= Long.parseLong(str);}
                if (n==2){categoryId= Long.parseLong(str);}
                if (n==3){categoryName=str;}
                if (n>3){list.add(Long.parseLong(str));}
                n++;
            }
            s.close();
            return list;
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }
























    @Override
    public void addMember(Category category, long id) {
        try {
            String path= new File("").getAbsolutePath();
            String cPath= path+"\\" + "resources\\Categories Folder\\";
            Files.createDirectories(Paths.get(cPath));
            File categoriesFolder = new File(cPath);

            for (File f : Objects.requireNonNull(categoriesFolder.listFiles())) {
                if (f.getName().equals(category.getId()+".txt")){
                    FileOutputStream fout = new FileOutputStream(f, true);
                    PrintStream out = new PrintStream(fout);
                    out.println(id);
                    out.flush();
                    out.close();
                    break;
                }
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void removeMember(Category category, long l) {

    }
}
