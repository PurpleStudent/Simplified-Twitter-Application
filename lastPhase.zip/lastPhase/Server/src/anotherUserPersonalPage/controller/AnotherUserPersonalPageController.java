package anotherUserPersonalPage.controller;

import authentication.model.User;
import category.model.Category;
import controller.Controller;
import database.MyLogger;
import message.model.Chat;
import message.model.Message;
import message.model.SystemMessage;
import request.model.Request;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Collections;
import java.util.LinkedList;

public class AnotherUserPersonalPageController extends Controller {






    private synchronized long createNewSystemMessageId(long clientId) {
        long n = 1;
        LinkedList<Long> idList=new LinkedList<>();
        for (SystemMessage systemMessage : context.systemMessageDataBaseSet.all()) { idList.add(systemMessage.getId()); }
        if (idList.size()>0){n= Collections.max(idList)+1;}
        MyLogger myLogger = new MyLogger(
                "src/anotherUserPersonalPage/controller/AnotherUserPersonalPageController.java",
                "createNewSystemMessageId" ,
                clientId
        );
        return n;
    }
























    public BufferedImage getMessageImage(long messageId , long clientId){
        try {
            String path = new File("").getAbsolutePath();
            String photoPath = path + "\\" + "resources\\Messages Photos\\" + messageId+".jpg";
            MyLogger myLogger = new MyLogger(
                    "src/anotherUserPersonalPage/controller/AnotherUserPersonalPageController.java" ,
                    "getMessageImage" ,
                    clientId
            );
            return ImageIO.read(new File(photoPath));
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

























    public BufferedImage getProfileImage (long userId , long clientId){
        try {
            String path = new File("").getAbsolutePath();
            String photoPath = path + "\\" + "resources\\Users Photos\\" + userId+".jpg";
            MyLogger myLogger = new MyLogger(
                    "src/anotherUserPersonalPage/controller/AnotherUserPersonalPageController.java" ,
                    "getProfileImage" ,
                    clientId
            );
            return ImageIO.read(new File(photoPath));
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }


























    public void addUserToCategories(String categoryName , long userId  , long clientId){

        if (getCategoryWithName(categoryName , clientId)!=null){
            context.categoryDataBaseSet.addMember(getCategoryWithName(categoryName , clientId),userId);
            MyLogger myLogger= new MyLogger(
                    "src/anotherUserPersonalPage/controller/AnotherUserPersonalPageController.java",
                    "addUserToCategories" ,
                    clientId
            );
        }
        else {
            System.out.println("This category does not exist.");
        }
    }

















    private Category getCategoryWithName(String categoryName  , long clientId){
        Category myCategory= null;
        for (Category category: context.categoryDataBaseSet.all()) {
            if (category.getUserId()== clientId){
                if (category.getCategoryName().equals(categoryName)){
                    myCategory= category;
                }
            }
        }
        MyLogger myLogger = new MyLogger(
                "src/anotherUserPersonalPage/controller/AnotherUserPersonalPageController.java" ,
                "getCategoryWithName" ,
                clientId
        );
        return myCategory;
    }


















    public void blockUser(long userid  , long clientId){
        User user= getUserWithId(userid ,clientId);
        context.userDataBaseSet.addBlackList ( context.userDataBaseSet.get (clientId) , userid );
        context.userDataBaseSet.removeFollowing ( context.userDataBaseSet.get (clientId) , userid );
        context.userDataBaseSet.removeFollower ( context.userDataBaseSet.get (clientId) , userid );
        context.userDataBaseSet.removeFollowing ( user, clientId);
        context.userDataBaseSet.removeFollower ( user, clientId);
        MyLogger myLogger= new MyLogger(
                "src/anotherUserPersonalPage/controller/AnotherUserPersonalPageController.java",
                "blockUser" ,
                clientId
        );
    }






















    public void unBlockUser(long userid  , long clientId){
        context.userDataBaseSet.removeBlackList(context.userDataBaseSet.get (clientId), userid );
        MyLogger myLogger= new MyLogger(
                "src/anotherUserPersonalPage/controller/AnotherUserPersonalPageController.java",
                "unBlockUser" ,
                clientId
        );
    }


















    private synchronized long createNewRequestId( long  clientId ) {
        long n = 1;
        LinkedList<Long> idList=new LinkedList<>();
        for (Request request : context.requestDataBaseSet.all()) { idList.add(request.getId()); }
        if (idList.size()>0){n= Collections.max(idList)+1;}
        MyLogger myLogger = new MyLogger(
                "src/anotherUserPersonalPage/controller/AnotherUserPersonalPageController.java" ,
                "createNewRequestId" ,
                clientId
        );
        return n;
    }























    public void followUser(long userid  , long clientId){
        User user= getUserWithId(userid ,clientId);
        String s="";
        if (context.userDataBaseSet.getBlackListsId(user).contains(clientId)) {
            s="You are blocked.";
        }
        else {
            if (user.getProfile().isPrivateAccount()) {
                Request request = new Request ( clientId , user.getId());
                request.setId(createNewRequestId(clientId));
                context.requestDataBaseSet.add(request);
                s="This user account is private, Your request has been sent.";
                MyLogger myLogger= new MyLogger(
                        "src/anotherUserPersonalPage/controller/AnotherUserPersonalPageController.java" ,
                        "followUser" ,
                        clientId
                );
            }
            else {
                context.userDataBaseSet.addFollowing(context.userDataBaseSet.get (clientId) ,user.getId());
                context.userDataBaseSet.addFollower(user, clientId);
                SystemMessage systemMessage = new SystemMessage(user.getId(), context.userDataBaseSet.get ( clientId ).getUsername() + " followed you.");
                systemMessage.setId(createNewSystemMessageId(clientId));
                context.systemMessageDataBaseSet.add(systemMessage);
            }
        }
    }












    public void unfollowUser(long userId  , long clientId){
        User user= getUserWithId(userId ,clientId);
        context.userDataBaseSet.removeFollowing(context.userDataBaseSet.get ( clientId),user.getId());
        context.userDataBaseSet.removeFollower (user, clientId);
        SystemMessage systemMessage = new SystemMessage(user.getId(), context.userDataBaseSet.get (clientId).getUsername() + " stopped following you.");
        systemMessage.setId(createNewSystemMessageId(clientId));
        context.systemMessageDataBaseSet.add(systemMessage);
        MyLogger myLogger= new MyLogger(
                "src/anotherUserPersonalPage/controller/AnotherUserPersonalPageController.java" ,
                "unfollowUser",
                clientId
        );
    }





















    public String buttonMode (long userId  , long clientId){
        User user= getUserWithId(userId ,clientId);
        String buttonMode= "";
        boolean b1= context.userDataBaseSet.getFollowingsId(context.userDataBaseSet.get(clientId)).contains (user.getId());
        boolean b2= context.userDataBaseSet.getBlackListsId(context.userDataBaseSet.get(clientId)).contains (user.getId());
        boolean b3= context.userDataBaseSet.getBlackListsId (user).contains(clientId);
        boolean b4= context.userDataBaseSet.getFollowersId(context.userDataBaseSet.get(clientId)).contains (user.getId());
        if (b1 && !b2 && !b3){buttonMode= "buttonMode1";}
        if (!b1 && !b2){
            if (b4){buttonMode= "buttonMode2";}
            else {buttonMode= "buttonMode3";}
        }
        if (!b1 && b2){buttonMode= "buttonMode4";}
        MyLogger myLogger = new MyLogger(
                "src/anotherUserPersonalPage/controller/AnotherUserPersonalPageController.java" ,
                "buttonMode" ,
                clientId
        );
        return buttonMode;
    }
















    private Chat findChatWithUsers (User user1, User user2 , long clientId){
        Chat myChat= null;
        for (Chat chat : context.chatDataBaseSet.all()) {
            if ((chat.getUser1Id() == user1.getId() && chat.getUser2Id() == user2.getId()) || (chat.getUser1Id() == user2.getId() && chat.getUser2Id() == user1.getId())) {
                myChat = chat;
                myChat.setUser1(context.userDataBaseSet.get(myChat.getUser1Id()));
                myChat.setUser2(context.userDataBaseSet.get(myChat.getUser2Id()));
                break;
            }
        }
        MyLogger myLogger = new MyLogger(
                "src/anotherUserPersonalPage/controller/AnotherUserPersonalPageController.java" ,
                "findChatWithUsers" ,
                clientId
        );
        return myChat;
    }



















    private Chat getChatWithUserId (long userId  , long clientId){
        Chat chat= null;
        if (findChatWithUsers (context.userDataBaseSet.get(clientId), context.userDataBaseSet.get(userId), clientId) == null) {
        }
        else {
            chat = findChatWithUsers (context.userDataBaseSet.get(clientId), context.userDataBaseSet.get(userId) ,clientId ) ;
            chat.setUser1(context.userDataBaseSet.get(chat.getUser1Id()));
            chat.setUser2(context.userDataBaseSet.get(chat.getUser2Id()));
        }
        MyLogger myLogger = new MyLogger(
                "src/anotherUserPersonalPage/controller/AnotherUserPersonalPageController.java" ,
                "getChatWithUserId" ,
                clientId
        );
        return chat;
    }

















    private synchronized long createNewChatId (long clientId) {
        long n = 1;
        LinkedList<Long> idList=new LinkedList<>();
        for (Chat chat : context.chatDataBaseSet.all()) { idList.add(chat.getId()); }
        if (idList.size()>0){n= Collections.max(idList)+1;}
        MyLogger myLogger = new MyLogger(
                "src/anotherUserPersonalPage/controller/AnotherUserPersonalPageController.java" ,
                "createNewChatId" ,
                clientId
        );
        return n;
    }
























    public Message getLatestChatMessage(long userId  , long clientId){
        Message message= null;
        if (getChatWithUserId(userId , clientId)==null){
        }
        else {
            if (context.chatDataBaseSet.getChatGroupAllMessages(getChatWithUserId(userId , clientId)).size() == 0) {
            }
            else {
                long id = Collections.max(context.chatDataBaseSet.getChatGroupAllMessages(getChatWithUserId(userId , clientId)));
                message = context.messageDataBaseSet.get(id);
                message.setCreatorUser(context.userDataBaseSet.get(message.getCreatorUserId()));
                message.setRecipientUser(context.userDataBaseSet.get(message.getRecipientUserId()));
            }
        }
        MyLogger myLogger = new MyLogger(
                "src/anotherUserPersonalPage/controller/AnotherUserPersonalPageController.java" ,
                "getLatestChatMessage" ,
                clientId
        );
        return message;
    }





































    public User getUserWithId(long id , long clientId){
        MyLogger myLogger = new MyLogger(
                "src/anotherUserPersonalPage/controller/AnotherUserPersonalPageController.java" ,
                "getUserWithId" ,
                clientId
        );
        return context.userDataBaseSet.get(id);
    }



























    public boolean showLastSeenDate(long userid  , long clientId){
        User user= getUserWithId(userid,clientId);
        boolean show= false;
        if (context.userDataBaseSet.getFollowersId(user).contains(clientId)) {
            if (user.getProfile().getShowLastSeenDate().equals("everybody")) {
                show= true;
            }
            if (user.getProfile().getShowLastSeenDate().equals("nobody")) {
                show= false;
            }
            if (user.getProfile().getShowLastSeenDate().equals("followings")) {
                show= context.userDataBaseSet.getFollowingsId(user).contains(clientId);
            }
        }
        MyLogger myLogger = new MyLogger(
                "src/anotherUserPersonalPage/controller/AnotherUserPersonalPageController.java" ,
                "showLastSeenDate" ,
                clientId
        );
        return show;
    }

















    public boolean showDateOfBirth(long userid  , long clientId){
        User user= getUserWithId(userid ,clientId);
        boolean show= false;
        if (user.getProfile().getShowDateOfBirth().equals("everybody")) {
            if (user.getProfile().getDateOfBirth()!=null) {
                show= true;
            }
        }
        if (user.getProfile().getShowDateOfBirth().equals("followings")) {
            if (context.userDataBaseSet.getFollowingsId(user).contains(clientId)) {
                if (user.getProfile().getDateOfBirth()!=null) {
                    show= true;
                }
            }
        }
        MyLogger myLogger = new MyLogger(
                "src/anotherUserPersonalPage/controller/AnotherUserPersonalPageController.java" ,
                "showDateOfBirth" ,
                clientId
        );
        return show;
    }



















    public boolean showEmail(long userid  , long clientId){
        User user= getUserWithId(userid ,clientId);
        boolean show= false;
        if (user.getProfile().getShowEmail().equals("everybody")) {
            show= true;
        }
        if (user.getProfile().getShowEmail().equals("followings")) {
            if (context.userDataBaseSet.getFollowingsId(user).contains(clientId)) {
                show= true;
            }
        }
        MyLogger myLogger = new MyLogger(
                "src/anotherUserPersonalPage/controller/AnotherUserPersonalPageController.java" ,
                "showEmail" ,
                clientId
        );
        return show;
    }
























    public boolean showPhoneNumber (long userid  , long clientId){
        User user= getUserWithId(userid ,clientId);
        boolean show= false;
        if (user.getProfile().getShowPhoneNumber().equals("everybody")) {
            show= true;
        }
        if (user.getProfile().getShowPhoneNumber().equals("followings")) {
            if (context.userDataBaseSet.getFollowingsId(user).contains(clientId)) {
                show= true;
            }
        }
        MyLogger myLogger = new MyLogger(
                "src/anotherUserPersonalPage/controller/AnotherUserPersonalPageController.java" ,
                "showPhoneNumber" ,
                clientId
         );
        return show;
    }
}
