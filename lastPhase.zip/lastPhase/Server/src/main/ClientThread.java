package main;

import accessListsPage.controller.AccessListController;
import announcements.controller.AnnouncementsController;
import anotherUserPersonalPage.controller.AnotherUserPersonalPageController;
import authentication.controller.AuthenticationController;
import authentication.model.User;
import category.controller.CategoryController;
import category.model.Category;
import editProfilePage.controller.EditProfileController;
import explorerPage.controller.ExplorerPageController;
import forwardTweetToSeveralPeople.controller.ForwardTweetController;
import group.controller.GroupController;
import group.model.Group;
import homepage.controller.HomePageController;
import message.controller.MessageController;
import message.model.Chat;
import message.model.Message;
import message.model.SystemMessage;
import messagingPage.controller.MessagingPageController;
import model.Date;
import personalPage.controller.PostNewTweetController;
import personalPage.controller.ViewYourTweetController;
import privacySettingsPage.controller.PrivacySettingsController;
import request.controller.RequestController;
import request.model.Request;
import tweet.controller.TweetController;
import tweet.model.Comment;
import tweet.model.Tweet;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.*;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.security.SecureRandom;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Scanner;





public class ClientThread extends Thread{

    static HashMap<Long,Long> authTokenIdMap = new HashMap<>();
    private final Socket socket;
    public ClientThread(Socket socket)  {
        this.socket = socket;
    }













    @Override
    public void run() {
        try {
            // first inputs
            Scanner input = new Scanner(socket.getInputStream());
            String information= input.nextLine();
            //-----------------------------------------------------------------------------------------------------------------------------------------------------------
            String remaining= information;
            LinkedList<String> informationList = new LinkedList<>();
            while (!remaining.equals("")) {
                String info = remaining.substring(remaining.indexOf('{') + 1, remaining.indexOf('}'));
                informationList.add(info);  // Synchronized
                if ( remaining.indexOf('}') + 1 == remaining.length()){remaining="";}
                else {
                    remaining = remaining.substring(remaining.indexOf('}') + 1);
                }
            }
            LinkedList<String> methodInputs = new LinkedList<>();
            //***************************************
            String authToken= informationList.get(0);
            String myId= informationList.get(1);
            String className= informationList.get(2);
            String methodName= informationList.get(3);
            //***************************************
            for (int i = 4; i < informationList.size(); i++) {
                methodInputs.add(informationList.get(i));
            }
            System.out.println(className +"     "+ methodName);
            System.out.println(authToken);
            System.out.println(myId);
            BufferedImage image = null;

            //--------------------------------------------------------------------------------------------------------------------------------------------------------------
            if (methodName.equals("createNewMessage")   ||   methodName.equals("copy")   ||   methodName.equals("addMessage")   ||   methodName.equals("createNewSavedMessage")   ||     methodName.equals("createNewTweet")){
                // first outputs
                PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
                output.println("Send the image.");
                //-----------------------------------------------------------------------------------------------------------------------------------------------------------
                // second inputs
                InputStream inputStream = socket.getInputStream();
                byte[] sizeAr = new byte[4];
                inputStream.read(sizeAr);
                int size = ByteBuffer.wrap(sizeAr).asIntBuffer().get();
                byte[] imageAr = new byte[size];
                inputStream.read(imageAr);
                image = ImageIO.read(new ByteArrayInputStream(imageAr));
            }

            if ( methodName.equals("getProfileImage")     ||      methodName.equals("getMessageImage")      ||     methodName.equals("getTweetImage") ) {
                // first outputs
                OutputStream outputStream= socket.getOutputStream();
                ByteArrayOutputStream byteArrayOutputStream = null;
                BufferedImage myImage = getImage( authToken , Long.parseLong(myId), className , methodName , methodInputs );
                byteArrayOutputStream = new ByteArrayOutputStream();
                if (myImage != null) {
                    ImageIO.write(myImage, "jpg", byteArrayOutputStream);
                }
                byte[] size = ByteBuffer.allocate(4).putInt(byteArrayOutputStream.size()).array();
                outputStream.write(size);
                outputStream.write(byteArrayOutputStream.toByteArray());
                outputStream.flush();
                //------------------------------------------------------------------------------------------------------------------------------------------------------------
                // second inputs
                Scanner input2 = new Scanner(socket.getInputStream());
                String information2= input.nextLine();
            }

            //--------------------------------------------------------------------------------------------------------------------------------------------------------------
            // processing
            String message = inputProcessing ( authToken , Long.parseLong(myId), className , methodName , methodInputs , image ) ; //question
            //----------------------------------------------------------------------------------------------------------------------------------------------------------------
            // second outputs
            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            output.println(message);
        }
        catch (Exception e){
            System.out.println(e.getMessage());
        }
    }




































    private String inputProcessing (String authToken , long clientId , String className , String methodName , LinkedList<String> methodInputs , BufferedImage image) {
        String response= "";
        //*****************************************************
        if ( clientId==0 ){
            if (authToken.equals("0")) {
                if (className.equals("AuthenticationController")) {
                    System.out.println("AuthenticationController");
                    response = authenticationController(methodName, methodInputs , clientId);
                }
            }
        }

        else {
            if (authTokenIdMap.get(Long.parseLong(authToken))== clientId ) {
                if (className.equals("AccessListController")){
                    System.out.println("AccessListController");
                    response= accessListController(methodName , clientId, methodInputs);
                }
                if (className.equals("AnnouncementsController")){
                    System.out.println("AnnouncementsController");
                    response= announcementsController(methodName, clientId);
                }
                if (className.equals("AnotherUserPersonalPageController")){
                    System.out.println("AnotherUserPersonalPageController");
                    response= anotherUserPersonalPageController ( methodName , clientId , methodInputs);
                }
                if (className.equals("CategoryController")){
                    System.out.println("CategoryController");
                    response= categoryController(methodName , methodInputs , clientId);
                }
                if (className.equals("EditProfileController")){
                    System.out.println("EditProfileController");
                    response= editProfileController(methodName,methodInputs , clientId , image);
                }
                if (className.equals("ExplorerPageController")){
                    System.out.println("ExplorerPageController");
                    response= explorerPageController(methodName , methodInputs , clientId);
                }
                if (className.equals("ForwardTweetController")){
                    System.out.println("ForwardTweetController");
                    response= forwardTweetController(methodName , methodInputs , clientId);
                }
                if (className.equals("GroupController")){
                    System.out.println("GroupController");
                    response= groupController(methodName , methodInputs , clientId ,image);
                }
                if (className.equals("HomePageController")) {
                    System.out.println("HomePageController");
                    response= homePageController(methodName, clientId ,methodInputs);
                }
                if (className.equals("MessageController")){
                    System.out.println("MessageController");
                    response= messageController(methodName , clientId, methodInputs ,image);
                }
                if (className.equals("MessagingPageController")){
                    System.out.println("MessagingPageController");
                    response= messagingPageController(methodName , clientId, methodInputs , image);
                }
                if (className.equals("PostNewTweetController")){
                    System.out.println("PostNewTweetController");
                    response= postNewTweetController(methodName , methodInputs , clientId , image);
                }
                if (className.equals("ViewYourTweetController")){
                    System.out.println("ViewYourTweetController");
                    response= viewYourTweetController(methodName , clientId, methodInputs);
                }
                if (className.equals("PrivacySettingsController")){
                    System.out.println("PrivacySettingsController");
                    response= privacySettingsController(methodName , methodInputs , clientId);
                }
                if (className.equals("RequestController")){
                    System.out.println("RequestController");
                    response= requestController(methodName , methodInputs , clientId);
                }
                if (className.equals("TweetController")){
                    System.out.println("TweetController");
                    response= tweetController(methodName , methodInputs , clientId);
                }
            }
        }



        return response;
    }
































    private BufferedImage getImage( String authToken , long clientId , String className , String methodName , LinkedList<String> methodInputs ){
        BufferedImage image= null;
        if (authTokenIdMap.get(Long.parseLong(authToken))==clientId) {
            if (className.equals("AccessListController")){
                AccessListController controller= new AccessListController();

                if (methodName.equals("getProfileImage")) {
                    image = controller.getProfileImage(Long.parseLong(methodInputs.get(0)), clientId);
                }
            }

            if (className.equals("AnotherUserPersonalPageController")){
                AnotherUserPersonalPageController controller= new AnotherUserPersonalPageController();

                if (methodName.equals("getProfileImage")) {
                    image = controller.getProfileImage(Long.parseLong(methodInputs.get(0)), clientId);
                }
                if (methodName.equals("getMessageImage")) {
                    image = controller.getMessageImage(Long.parseLong(methodInputs.get(0)) ,clientId);
                }

            }

            if (className.equals("ExplorerPageController")){
                ExplorerPageController controller = new ExplorerPageController();

                if (methodName.equals("getProfileImage")) {
                    image = controller.getProfileImage(Long.parseLong(methodInputs.get(0)) ,clientId);
                }
                if (methodName.equals("getTweetImage")){
                    image = controller.getTweetImage(Long.parseLong(methodInputs.get(0)) ,clientId);
                }
            }
            if (className.equals("ForwardTweetController")){
                ForwardTweetController controller= new ForwardTweetController();

                if (methodName.equals("getProfileImage")) {
                    controller.getProfileImage(Long.parseLong(methodInputs.get(0)) ,clientId);
                }
                if (methodName.equals("getTweetImage")){
                    controller.getTweetImage(Long.parseLong(methodInputs.get(0)) ,clientId);
                }
            }
            if (className.equals("GroupController")){
                GroupController controller= new GroupController();

                if (methodName.equals("getProfileImage")) {
                    image = controller.getProfileImage(Long.parseLong(methodInputs.get(0)) ,clientId);
                }
                if (methodName.equals("getMessageImage")) {
                    image = controller.getMessageImage(Long.parseLong(methodInputs.get(0)) ,clientId);
                }
            }
            if (className.equals("HomePageController")) {
                HomePageController controller= new HomePageController();

                if (methodName.equals("getProfileImage")) {
                    image = controller.getProfileImage(Long.parseLong(methodInputs.get(0)) ,clientId);
                }
                if (methodName.equals("getTweetImage")) {
                    image = controller.getTweetImage(Long.parseLong(methodInputs.get(0)) ,clientId);
                }

            }
            if (className.equals("MessageController")){
                MessageController controller = new MessageController();

                if (methodName.equals("getProfileImage")) {
                    image = controller.getProfileImage(Long.parseLong(methodInputs.get(0)) ,clientId);
                }
                if (methodName.equals("getMessageImage")) {
                    image = controller.getMessageImage(Long.parseLong(methodInputs.get(0)) ,clientId);
                }

            }
            if (className.equals("MessagingPageController")){
                MessagingPageController controller = new MessagingPageController();

                if (methodName.equals("getMessageImage")) {
                    image = controller.getMessageImage(Long.parseLong(methodInputs.get(0)) ,clientId);
                }

            }

            if (className.equals("ViewYourTweetController")){
                ViewYourTweetController controller= new ViewYourTweetController();

                if (methodName.equals("getProfileImage")) {
                    image = controller.getProfileImage(Long.parseLong(methodInputs.get(0)) ,clientId);
                }

                if (methodName.equals("getTweetImage")) {
                    image = controller.getTweetImage(Long.parseLong(methodInputs.get(0)) ,clientId);
                }
            }

            if (className.equals("TweetController")){
                TweetController controller = new TweetController();

                if (methodName.equals("getProfileImage")) {
                    image = controller.getProfileImage(Long.parseLong(methodInputs.get(0)) ,clientId);
                }
                if (methodName.equals("getTweetImage")) {
                    controller.getTweetImage(Long.parseLong(methodInputs.get(0)) ,clientId);
                }

            }
        }
        return image;
    }


































    private String anotherUserPersonalPageController(String methodName , long myId , LinkedList<String> methodInputs){
            String response = "";
            AnotherUserPersonalPageController controller = new AnotherUserPersonalPageController();

            if (methodName.equals("getLatestChatMessage")) {
                Message message= controller.getLatestChatMessage( Long.parseLong(methodInputs.get(0)) , myId );

                System.out.println( message== null);
                if ( message  == null) {
                    response = "null";
                } else {
                    response= "{"+ message.getCreatorUserId()+"}"
                            +"{"+ message.getRecipientUserId()+"}"
                            +"{"+ message.getCreatorUser().getUsername()+"}"
                            +"{"+ message.getRecipientUser().getUsername()+"}"
                            +"{"+ message.getText()+"}"
                            +"{"+ message.getId()+"}"
                            +"{"+ message.getDateTimeOfCreation()+"}";
                }
            }

            /*if (methodName.equals("getProfileImage")) {
                BufferedImage image = controller.getProfileImage(Long.parseLong(methodInputs.get(0)));
                if (image == null) {
                    response = "null";
                } else {
                    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                    ImageIO.write(image,"jpg",byteArrayOutputStream);
                    response = new String(byteArrayOutputStream.toByteArray());
                }
            }*/

            if (methodName.equals("showLastSeenDate")) {
                response = String.valueOf(controller.showLastSeenDate(Long.parseLong(methodInputs.get(0)), myId));
            }

            if (methodName.equals("showDateOfBirth")) {
                response = String.valueOf(controller.showDateOfBirth(Long.parseLong(methodInputs.get(0)), myId));
            }

            if (methodName.equals("showEmail")) {
                response = String.valueOf(controller.showEmail(Long.parseLong(methodInputs.get(0)), myId));
            }

            if (methodName.equals("showPhoneNumber")) {
                response = String.valueOf(controller.showPhoneNumber(Long.parseLong(methodInputs.get(0)), myId));
            }
            if (methodName.equals("blockUser")) {
                controller.blockUser(Long.parseLong(methodInputs.get(0)), myId);
                response = "done";
            }
            if (methodName.equals("unBlockUser")) {
                controller.unBlockUser(Long.parseLong(methodInputs.get(0)), myId);
                response = "done";
            }
            if (methodName.equals("followUser")) {
                controller.followUser(Long.parseLong(methodInputs.get(0)), myId);
                response= "done";
            }
            if (methodName.equals("unfollowUser")){
                controller.unfollowUser(Long.parseLong(methodInputs.get(0)), myId );
            }

            /*if (methodName.equals("getMessageImage")) {
                BufferedImage image = controller.getMessageImage(Long.parseLong(methodInputs.get(0)));
                if (image == null) {
                    response = "null";
                } else {
                    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                    ImageIO.write(image, "jpg", byteArrayOutputStream);
                    response = new String(byteArrayOutputStream.toByteArray());
                }
            }*/

            if (methodName.equals("buttonMode")){
                response= controller.buttonMode(Long.parseLong(methodInputs.get(0)), myId );
            }
            if (methodName.equals("addUserToCategories")){
                controller.addUserToCategories( methodInputs.get(0) , Long.parseLong(methodInputs.get(1)), myId);
            }

            return response;
    }





























    private String announcementsController(String methodName , long myId  ){
        String response= "";
        AnnouncementsController controller= new AnnouncementsController();

        if (methodName.equals("getFirstSystemMessages")){
            if (controller.getFirstSystemMessages(myId) == null){response = "null";}
            else {
                response = "{"+controller.getFirstSystemMessages(myId).getId()+"}"
                           +"{"+ controller.getFirstSystemMessages(myId).getText()+"}"
                           +"{"+ controller.getFirstSystemMessages(myId).getRecipientId()+"}"
                           +"{"+ controller.getFirstSystemMessages(myId).getDateTimeOfCreation()+"}";
            }
        }

        if (methodName.equals("getFirstRequest")){
            if (controller.getFirstRequest(myId) == null){response = "null";}
            else {
                response = "{"+controller.getFirstRequest(myId).getId()+"}"
                        +"{"+ controller.getFirstRequest(myId).getText()+"}"
                        +"{"+ controller.getFirstRequest(myId).getRequesterId()+"}"
                        +"{"+ controller.getFirstRequest(myId).getRequestedId()+"}";
            }
        }

        return response;
    }

























    private String accessListController (String methodName , long myId , LinkedList<String> methodInputs) {
        AccessListController controller= new AccessListController();
        String response= "";

        if (methodName.equals("getFollowerUsername")){
            response= "";
            if (controller.getFollower(myId)!=null){
                response= controller.getFollower(myId).getUsername();
            }
        }
        if (methodName.equals("getFollowingUsername")){
            response= "";
            if (controller.getFollowing(myId)!=null){
                response= controller.getFollowing(myId).getUsername();
            }
        }
        if (methodName.equals("getBlockedUsername")){
            response= "";
            if (controller.getBlocked(myId)!=null){
                response= controller.getBlocked(myId).getUsername();
            }
        }
        if (methodName.equals("getFollowerId")){
            response= "-1";
            if (controller.getFollower(myId)!=null){
                response= String.valueOf(controller.getFollower(myId).getId());
            }
        }
        if (methodName.equals("getFollowingId")){
            response= "-1";
            if (controller.getFollowing(myId)!=null){
                response= String.valueOf(controller.getFollowing(myId).getId());
            }
        }
        if (methodName.equals("getBlockedId")){
            response= "-1";
            if (controller.getBlocked(myId)!=null){
                response= String.valueOf(controller.getBlocked(myId).getId());
            }
        }

        if (methodName.equals("firstCategory")){

            if (controller.firstCategory(myId)==null){response= "null";}
            else {
                response= "{"+controller.firstCategory(myId).getCategoryName()+"}"
                          +"{"+controller.firstCategory(myId).getId()+"}"
                          +"{"+controller.firstCategory(myId).getUserId()+"}";
            }
        }

        if (methodName.equals("createNewCategory")){
            controller.createNewCategory(methodInputs.get(0), myId);
            response = "done";
        }
        if (methodName.equals("getUserWithId")){
            User user= controller.getUserWithId ( Long.parseLong(methodInputs.get(0)) , myId );
            if (user==null){response="null";}
            else {
                response= "{"+user.getId()+"}"
                        +"{"+user.getUsername()+"}"
                        +"{"+user.getProfile().getFirstName()+"}"
                        +"{"+user.getProfile().getLastName()+"}"
                        +"{"+user.getProfile().getEmail()+"}"
                        +"{"+user.getProfile().getBiography()+"}"
                        +"{"+user.getProfile().getPhoneNumber()+"}"
                        +"{"+user.getProfile().getLastSeenDate()+"}"
                        +"{"+user.getProfile().getDateOfBirth()+"}"
                        +"{"+user.getProfile().isActive()+"}"
                        +"{"+user.getProfile().isPrivateAccount()+"}"
                        +"{"+user.getProfile().getShowLastSeenDate()+"}"
                        +"{"+user.getProfile().getShowDateOfBirth()+"}"
                        +"{"+user.getProfile().getShowEmail()+"}"
                        +"{"+user.getProfile().getShowPhoneNumber()+"}";
            }
        }
        if (methodName.equals("buttonMode")){
            response= controller.buttonMode( Long.parseLong(methodInputs.get(0)) , myId);
        }
        if (methodName.equals("showLastSeenDate")){
            response= String.valueOf(controller.showLastSeenDate( Long.parseLong(methodInputs.get(0)) , myId ));
        }
        if (methodName.equals("showDateOfBirth")){
            response= String.valueOf(controller.showDateOfBirth ( Long.parseLong(methodInputs.get(0)) , myId ));
        }
        if (methodName.equals("showEmail")){
            response= String.valueOf(controller.showEmail( Long.parseLong(methodInputs.get(0)) , myId));
        }
        if (methodName.equals("showPhoneNumber")){
            response= String.valueOf(controller.showPhoneNumber( Long.parseLong(methodInputs.get(0)) , myId));
        }
        if (methodName.equals("nextUsername")){
            response= controller.next ( methodInputs.get(0) , Long.parseLong(methodInputs.get(1)) , myId ).getUsername();
        }
        if (methodName.equals("nextUserid")){
            response= String.valueOf(controller.next( methodInputs.get(0) , Long.parseLong(methodInputs.get(1)) , myId).getId());
        }
        if (methodName.equals("previousUsername")){
            response= controller.previous( methodInputs.get(0) , Long.parseLong(methodInputs.get(1)) , myId).getUsername();
        }
        if (methodName.equals("previousUserid")){
            response= String.valueOf(controller.previous(methodInputs.get(0) , Long.parseLong(methodInputs.get(1)) , myId).getId());
        }
        /*if (methodName.equals("getProfileImage")){
            BufferedImage image= controller.getProfileImage(Long.parseLong(methodInputs.get(0)));
            if (image==null){response="null";}
            else {
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                //ImageIO.write(image,"jpg",byteArrayOutputStream);
                response = new String(byteArrayOutputStream.toByteArray());
            }
        }*/

        return response;
    }































    private String homePageController(String methodName, long myId , LinkedList<String>methodInputs){
        String response="";
        HomePageController controller = new HomePageController();

        if (methodName.equals("firstDisplayableTweet")) {
            Tweet tweet = controller.firstDisplayableTweet(myId);
            if (tweet==null){response="null";}
            else {
                response =
                        "{" + tweet.getText() + "}" +
                        "{" + tweet.getId() + "}" +
                        "{" + tweet.getReportNumber() + "}" +
                        "{" + tweet.getDateTimeOfCreation() + "}" +
                        "{" + tweet.getOwnerTweetId() + "}" +
                        "{" + tweet.getCreatorUserId() + "}" +
                        "{" + tweet.getCreatorUser().getUsername()+"}";
            }
        }

        /*if (methodName.equals("getTweetImage")){
            BufferedImage image= controller.getTweetImage(Long.parseLong(methodInputs.get(0)));
            if (image==null){response="null";}
            else {
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                //ImageIO.write(image,"jpg",byteArrayOutputStream);
                response = new String(byteArrayOutputStream.toByteArray());
            }
        }*/
        /*if (methodName.equals("getProfileImage")){
            BufferedImage image= controller.getProfileImage(Long.parseLong(methodInputs.get(0)));
            if (image==null){response="null";}
            else {
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                //ImageIO.write(image,"jpg",byteArrayOutputStream);
                response = new String(byteArrayOutputStream.toByteArray());
            }
        }*/

        return response;
    }































    private String editProfileController( String methodName , LinkedList<String> methodInputs , long clientId , BufferedImage image){
        String response= "";
        EditProfileController controller= new EditProfileController();

        if (methodName.equals("copy")){
            controller.copy( image , Long.parseLong(methodInputs.get(0)) ,clientId);
        }

        if (methodName.equals("changeFirstName")){
            controller.changeFirstName (methodInputs.get(0) , clientId );
        }

        if (methodName.equals("changeLastName")){
            controller.changeLastName(methodInputs.get(0) , clientId);
        }

        if (methodName.equals("changeUsername")){
            controller.changeUsername(methodInputs.get(0) , clientId);
        }

        if (methodName.equals("changeDateOfBirth")){
            controller.changeDateOfBirth(Date.convertStringToDate(methodInputs.get(0)), clientId);
        }

        if (methodName.equals("changeEmail")){
            controller.changeEmail( methodInputs.get(0) , clientId );
        }

        if (methodName.equals("changePhoneNumber")){
            controller.changePhoneNumber( methodInputs.get(0) , clientId );
        }
        if (methodName.equals("changeBiography")){
            controller.changeBiography(methodInputs.get(0) , clientId);
        }
        if (methodName.equals("changePassword")){
            controller.changePassword(methodInputs.get(0) , clientId);
        }

        return response;
    }































    private String authenticationController (String methodName , LinkedList<String> methodInputs , long clientId) {
        String response= "";
        AuthenticationController controller= new AuthenticationController();


        if (methodName.equals("isDuplicateUser")){
            boolean b= controller.isDuplicateUser(
                    methodInputs.get(0),
                    methodInputs.get(1),
                    Long.parseLong(methodInputs.get(2)),
                    clientId
            );
            response= String.valueOf(b);
        }

        if (methodName.equals("register")){
            long id= controller.register(
                    methodInputs.get(0),
                    methodInputs.get(1),
                    methodInputs.get(2),
                    methodInputs.get(3),
                    methodInputs.get(4),
                    methodInputs.get(5),
                    methodInputs.get(6),
                    methodInputs.get(7),
                    methodInputs.get(8),
                    methodInputs.get(9),
                    clientId
            );
            SecureRandom rand = new SecureRandom();
            int token = rand.nextInt(1000000000);
            authTokenIdMap.put((long) token,id);
            response= token+" "+id;
        }

        if (methodName.equals("login")){
            long id= controller.login(
                    methodInputs.get(0),
                    methodInputs.get(1),
                    clientId
            );
            SecureRandom rand = new SecureRandom();
            int token = rand.nextInt(1000000000);
            authTokenIdMap.put((long) token,id);
            response= token+" "+id;
        }

        if (methodName.equals("userFound")){
            response= String.valueOf(controller.userFound( methodInputs.get(0) , methodInputs.get(1) ,clientId ));
        }

        return response;
    }































    private String categoryController(String methodName, LinkedList<String> methodInputs, long clientId){
        String response= "";
        CategoryController controller= new CategoryController();

        if (methodName.equals("addMember")){
            controller.addMember(methodInputs.get(0) , Long.parseLong(methodInputs.get(1)), clientId);
        }

        if (methodName.equals("getCategory")){
            Category category= controller.getCategory(Long.parseLong(methodInputs.get(0)),clientId);
            if (category==null){response= "null";}
            else {
                response="{"+ category.getId()+"}"
                        +"{"+ category.getCategoryName()+"}"
                        +"{"+ category.getUserId()+"}";
            }
        }

        if (methodName.equals("previousCategory")){
            Category category= controller.previousCategory(Long.parseLong(methodInputs.get(0)) , clientId);
            if (category==null){response= "null";}
            else {
                response="{"+ category.getId()+"}"
                        +"{"+ category.getCategoryName()+"}"
                        +"{"+ category.getUserId()+"}";
            }
        }

        if (methodName.equals("nextCategory")){
            Category category= controller.nextCategory(Long.parseLong(methodInputs.get(0)) , clientId);
            if (category==null){response= "null";}
            else {
                response="{"+ category.getId()+"}"
                        +"{"+ category.getCategoryName()+"}"
                        +"{"+ category.getUserId()+"}";
            }
        }

        if (methodName.equals("firstCategoryMember")){
            User user= controller.firstCategoryMember(Long.parseLong(methodInputs.get(0)),clientId);
            if (user==null){response= "null";}
            else {
                response= "{"+user.getId()+"}"
                        +"{"+user.getUsername()+"}"
                        +"{"+user.getProfile().getFirstName()+"}"
                        +"{"+user.getProfile().getLastName()+"}"
                        +"{"+user.getProfile().getEmail()+"}"
                        +"{"+user.getProfile().getBiography()+"}"
                        +"{"+user.getProfile().getPhoneNumber()+"}"
                        +"{"+user.getProfile().getLastSeenDate()+"}"
                        +"{"+user.getProfile().getDateOfBirth()+"}"
                        +"{"+user.getProfile().isActive()+"}"
                        +"{"+user.getProfile().isPrivateAccount()+"}"
                        +"{"+user.getProfile().getShowLastSeenDate()+"}"
                        +"{"+user.getProfile().getShowDateOfBirth()+"}"
                        +"{"+user.getProfile().getShowEmail()+"}"
                        +"{"+user.getProfile().getShowPhoneNumber()+"}";
            }
        }

        if (methodName.equals("nextCategoryMember")){
            User user= controller.nextCategoryMember( Long.parseLong(methodInputs.get(0)) ,  Long.parseLong(methodInputs.get(1)) ,clientId);
            if (user==null){response= "null";}
            else {
                response= "{"+user.getId()+"}"
                        +"{"+user.getUsername()+"}"
                        +"{"+user.getProfile().getFirstName()+"}"
                        +"{"+user.getProfile().getLastName()+"}"
                        +"{"+user.getProfile().getEmail()+"}"
                        +"{"+user.getProfile().getBiography()+"}"
                        +"{"+user.getProfile().getPhoneNumber()+"}"
                        +"{"+user.getProfile().getLastSeenDate()+"}"
                        +"{"+user.getProfile().getDateOfBirth()+"}"
                        +"{"+user.getProfile().isActive()+"}"
                        +"{"+user.getProfile().isPrivateAccount()+"}"
                        +"{"+user.getProfile().getShowLastSeenDate()+"}"
                        +"{"+user.getProfile().getShowDateOfBirth()+"}"
                        +"{"+user.getProfile().getShowEmail()+"}"
                        +"{"+user.getProfile().getShowPhoneNumber()+"}";
            }
        }

        if (methodName.equals("previousCategoryMember")){
            User user= controller.previousCategoryMember( Long.parseLong(methodInputs.get(0)) , Long.parseLong(methodInputs.get(1)),clientId );
            if (user==null){response= "null";}
            else {
                response= "{"+user.getId()+"}"
                        +"{"+user.getUsername()+"}"
                        +"{"+user.getProfile().getFirstName()+"}"
                        +"{"+user.getProfile().getLastName()+"}"
                        +"{"+user.getProfile().getEmail()+"}"
                        +"{"+user.getProfile().getBiography()+"}"
                        +"{"+user.getProfile().getPhoneNumber()+"}"
                        +"{"+user.getProfile().getLastSeenDate()+"}"
                        +"{"+user.getProfile().getDateOfBirth()+"}"
                        +"{"+user.getProfile().isActive()+"}"
                        +"{"+user.getProfile().isPrivateAccount()+"}"
                        +"{"+user.getProfile().getShowLastSeenDate()+"}"
                        +"{"+user.getProfile().getShowDateOfBirth()+"}"
                        +"{"+user.getProfile().getShowEmail()+"}"
                        +"{"+user.getProfile().getShowPhoneNumber()+"}";
            }
        }
        return response;
    }































    private String explorerPageController(String methodName , LinkedList<String>methodInputs , long clientId){
        String response= "";
        ExplorerPageController controller= new ExplorerPageController();

        if (methodName.equals("firstExplorerTweet")){
            Tweet tweet= controller.firstExplorerTweet(clientId);
            if (tweet==null){response= "null";}
            else {
                response= "{"+ tweet.getId()+"}"
                        +"{"+ tweet.getOwnerTweetId()+"}"
                        +"{"+ tweet.getText()+"}"
                        +"{"+ tweet.getCreatorUserId()+"}"
                        +"{"+ tweet.getCreatorUser().getUsername()+"}"
                        +"{"+ tweet.getReportNumber()+"}"
                        +"{"+ tweet.getDateTimeOfCreation()+"}";
            }
        }

        /*if (methodName.equals("getTweetImage")){
            BufferedImage image= controller.getTweetImage(Long.parseLong(methodInputs.get(0)));
            if (image==null){response="null";}
            else {
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                //ImageIO.write(image,"jpg",byteArrayOutputStream);
                response = new String(byteArrayOutputStream.toByteArray());
            }
        }*/

        /*if (methodName.equals("getProfileImage")){
            BufferedImage image= controller.getProfileImage(Long.parseLong(methodInputs.get(0)));
            if (image==null){response="null";}
            else {
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                //ImageIO.write(image,"jpg",byteArrayOutputStream);
                response = new String(byteArrayOutputStream.toByteArray());
            }
        }*/

        if (methodName.equals("getUserWithUsername")){
            User user= controller.getUserWithUsername( methodInputs.get(0) ,clientId);
            if (user==null){response= "null";}
            else {
                response= "{"+user.getId()+"}"
                        +"{"+user.getUsername()+"}"
                        +"{"+user.getProfile().getFirstName()+"}"
                        +"{"+user.getProfile().getLastName()+"}"
                        +"{"+user.getProfile().getEmail()+"}"
                        +"{"+user.getProfile().getBiography()+"}"
                        +"{"+user.getProfile().getPhoneNumber()+"}"
                        +"{"+user.getProfile().getLastSeenDate()+"}"
                        +"{"+user.getProfile().getDateOfBirth()+"}"
                        +"{"+user.getProfile().isActive()+"}"
                        +"{"+user.getProfile().isPrivateAccount()+"}"
                        +"{"+user.getProfile().getShowLastSeenDate()+"}"
                        +"{"+user.getProfile().getShowDateOfBirth()+"}"
                        +"{"+user.getProfile().getShowEmail()+"}"
                        +"{"+user.getProfile().getShowPhoneNumber()+"}";
            }
        }
        if (methodName.equals("buttonMode")){
            response= controller.buttonMode ( Long.parseLong(methodInputs.get(0)), clientId );
        }
        if (methodName.equals("showLastSeenDate")){
            response= String.valueOf(controller.showLastSeenDate(Long.parseLong(methodInputs.get(0)), clientId));
        }
        if (methodName.equals("showDateOfBirth")){
            response= String.valueOf(controller.showDateOfBirth (Long.parseLong(methodInputs.get(0)), clientId));
        }
        if (methodName.equals("showEmail")){
            response= String.valueOf(controller.showEmail( Long.parseLong(methodInputs.get(0)) , clientId ));
        }
        if (methodName.equals("showPhoneNumber")){
            response= String.valueOf(controller.showPhoneNumber(Long.parseLong(methodInputs.get(0)) , clientId));
        }
        return response;
    }































    private String forwardTweetController(String methodName , LinkedList<String>methodInputs , long myId){

        String response= "";
        ForwardTweetController controller= new ForwardTweetController();
        if (methodName.equals("sendToAllUsers")){
            controller.sendToAllUsers(Long.parseLong(methodInputs.get(0)), myId);
        }

        /*if (methodName.equals("getTweetImage")){
            BufferedImage image= controller.getTweetImage(Long.parseLong(methodInputs.get(0)));
            if (image==null){response="null";}
            else {
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                //ImageIO.write(image,"jpg",byteArrayOutputStream);
                response = new String(byteArrayOutputStream.toByteArray());
            }
        }*/

        /*if (methodName.equals("getProfileImage")){
            BufferedImage image= controller.getProfileImage(Long.parseLong(methodInputs.get(0)));
            if (image==null){response="null";}
            else {
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                //ImageIO.write(image,"jpg",byteArrayOutputStream);
                response = new String(byteArrayOutputStream.toByteArray());
            }
        }*/

        if (methodName.equals("forwardToManuallySelectedPeople")){
            controller.forwardToManuallySelectedPeople ( Integer.parseInt(methodInputs.get(0)) , methodInputs.get(1) , methodInputs.get(2) , myId );
        }
        if (methodName.equals("forwardToSelectedCategories")){
            controller.forwardToSelectedCategories(Integer.parseInt(methodInputs.get(0)), methodInputs.get(1) , methodInputs.get(2) , myId);
        }

        return response;
    }































    private String groupController(String methodName , LinkedList<String>methodInputs , long clientId , BufferedImage image){
        GroupController controller= new GroupController();
        String response= "";
        if (methodName.equals("leaveGroup")){
            controller.leaveGroup(Long.parseLong(methodInputs.get(0)), clientId);
        }
        if (methodName.equals("addMember")){
            controller.addMember( methodInputs.get(0) , Long.parseLong(methodInputs.get(1)), clientId );
        }
        if (methodName.equals("getGroup")){
            Group group= controller.getGroup(Long.parseLong(methodInputs.get(0)) ,clientId);
            if (group==null){response= "null";}
            else {
                response= "{"+ group.getId()+"}"
                        +"{"+ group.getName()+"}";
            }
        }
        if (methodName.equals("addMessage")){
            controller.addMessage( methodInputs.get(0) , Long.parseLong(methodInputs.get(1)) , image ,clientId);
        }
        if (methodName.equals("createNewGroup")){
            controller.createNewGroup( methodInputs.get(0) , clientId);
        }
        if (methodName.equals("getPreviousGroup")){
            Group group= controller.getPreviousGroup(Long.parseLong(methodInputs.get(0)) , clientId);
            if (group==null){response= "null";}
            else {
                response= "{"+ group.getId()+"}"
                        +"{"+ group.getName()+"}";
            }
        }

        if (methodName.equals("getNextGroup")){
            Group group= controller.getNextGroup(Long.parseLong(methodInputs.get(0)) , clientId);
            if (group==null){response= "null";}
            else {
                response= "{"+ group.getId()+"}"
                        +"{"+ group.getName()+"}";
            }
        }
        if (methodName.equals("getLastMessageOfGroup")){
            Message message= controller.getLastMessageOfGroup( Long.parseLong (methodInputs.get(0)) ,clientId );
            if (message==null){response= "null";}
            else {
                if (message.getRecipientUser() == null){
                    response = "{" + message.getCreatorUserId() + "}"
                            + "{" + message.getRecipientUserId() + "}"
                            + "{" + message.getCreatorUser().getUsername() + "}"
                            + "{" + "null" + "}"
                            + "{" + message.getText() + "}"
                            + "{" + message.getId() + "}"
                            + "{" + message.getDateTimeOfCreation() + "}";
                }
                else {
                    response = "{" + message.getCreatorUserId() + "}"
                            + "{" + message.getRecipientUserId() + "}"
                            + "{" + message.getCreatorUser().getUsername() + "}"
                            + "{" + message.getRecipientUser().getUsername() + "}"
                            + "{" + message.getText() + "}"
                            + "{" + message.getId() + "}"
                            + "{" + message.getDateTimeOfCreation() + "}";
                }
            }
        }

        /*if (methodName.equals("getMessageImage")){
            BufferedImage photo= controller.getMessageImage(Long.parseLong(methodInputs.get(0)));
            if (photo==null){response="null";}
            else {
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                //ImageIO.write(image,"jpg",byteArrayOutputStream);
                response = new String(byteArrayOutputStream.toByteArray());
            }
        }*/

        /*if (methodName.equals("getProfileImage")){
            BufferedImage photo= controller.getProfileImage(Long.parseLong(methodInputs.get(0)));
            if (photo==null){response="null";}
            else {
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                //ImageIO.write(image,"jpg",byteArrayOutputStream);
                response = new String(byteArrayOutputStream.toByteArray());
            }
        }*/

        if (methodName.equals("getPreviousGroupMessage")){
            Message message= controller.getPreviousGroupMessage(Long.parseLong(methodInputs.get(0)) , Long.parseLong(methodInputs.get(1)) ,clientId);
            if (message==null){response= "null";}
            else {
                if (message.getRecipientUser() == null){
                    response = "{" + message.getCreatorUserId() + "}"
                            + "{" + message.getRecipientUserId() + "}"
                            + "{" + message.getCreatorUser().getUsername() + "}"
                            + "{" + "null" + "}"
                            + "{" + message.getText() + "}"
                            + "{" + message.getId() + "}"
                            + "{" + message.getDateTimeOfCreation() + "}";
                }
                else {
                    response = "{" + message.getCreatorUserId() + "}"
                            + "{" + message.getRecipientUserId() + "}"
                            + "{" + message.getCreatorUser().getUsername() + "}"
                            + "{" + message.getRecipientUser().getUsername() + "}"
                            + "{" + message.getText() + "}"
                            + "{" + message.getId() + "}"
                            + "{" + message.getDateTimeOfCreation() + "}";
                }
            }
        }

        if (methodName.equals("getNextGroupMessage")){
            Message message= controller.getNextGroupMessage(Long.parseLong(methodInputs.get(0)) , Long.parseLong(methodInputs.get(1)) ,clientId);
            if (message==null){response= "null";}
            else {
                if (message.getRecipientUser() == null){
                    response = "{" + message.getCreatorUserId() + "}"
                            + "{" + message.getRecipientUserId() + "}"
                            + "{" + message.getCreatorUser().getUsername() + "}"
                            + "{" + "null" + "}"
                            + "{" + message.getText() + "}"
                            + "{" + message.getId() + "}"
                            + "{" + message.getDateTimeOfCreation() + "}";
                }
                else {
                    response = "{" + message.getCreatorUserId() + "}"
                            + "{" + message.getRecipientUserId() + "}"
                            + "{" + message.getCreatorUser().getUsername() + "}"
                            + "{" + message.getRecipientUser().getUsername() + "}"
                            + "{" + message.getText() + "}"
                            + "{" + message.getId() + "}"
                            + "{" + message.getDateTimeOfCreation() + "}";
                }
            }
        }

        return response;
    }































    private String messageController (String methodName , long clientId , LinkedList<String>methodInputs , BufferedImage image){
        MessageController controller= new MessageController();
        String response= "";
        if (methodName.equals("getAnotherUser")){
            User user= controller.getAnotherUser(Long.parseLong(methodInputs.get(0)), clientId);
            if (user==null){response= "null";}
            else {
                response= "{"+user.getId()+"}"
                        +"{"+user.getUsername()+"}"
                        +"{"+user.getProfile().getFirstName()+"}"
                        +"{"+user.getProfile().getLastName()+"}"
                        +"{"+user.getProfile().getEmail()+"}"
                        +"{"+user.getProfile().getBiography()+"}"
                        +"{"+user.getProfile().getPhoneNumber()+"}"
                        +"{"+user.getProfile().getLastSeenDate()+"}"
                        +"{"+user.getProfile().getDateOfBirth()+"}"
                        +"{"+user.getProfile().isActive()+"}"
                        +"{"+user.getProfile().isPrivateAccount()+"}"
                        +"{"+user.getProfile().getShowLastSeenDate()+"}"
                        +"{"+user.getProfile().getShowDateOfBirth()+"}"
                        +"{"+user.getProfile().getShowEmail()+"}"
                        +"{"+user.getProfile().getShowPhoneNumber()+"}";
            }
        }

        if (methodName.equals("nextChat")){
            Chat chat= controller.nextChat(Long.parseLong(methodInputs.get(0)), clientId);
            if (chat==null){response= "null";}
            else {
                response= "{"+chat.getUser1Id()+"}"
                        +"{"+chat.getUser2Id()+"}"
                        +"{"+chat.getId()+"}";
            }
        }


        if (methodName.equals("previousChat")){
            Chat chat= controller.previousChat(Long.parseLong(methodInputs.get(0)), clientId);
            if (chat==null){response= "null";}
            else {
                response= "{"+chat.getUser1Id()+"}"
                        +"{"+chat.getUser2Id()+"}"
                        +"{"+chat.getId()+"}";
            }
        }


        if (methodName.equals("getNumberOfUnreadMessages")){
            response= String.valueOf(controller.getNumberOfUnreadMessages(Long.parseLong(methodInputs.get(0)), clientId));
        }
        if (methodName.equals("getPreviousChatMessage")){
            Message message= controller.getPreviousChatMessage(Long.parseLong(methodInputs.get(0)) , Long.parseLong(methodInputs.get(1)) , clientId);
            if (message==null){response= "null";}
            else {
                response= "{"+ message.getCreatorUserId()+"}"
                        +"{"+ message.getRecipientUserId()+"}"
                        +"{"+ message.getCreatorUser().getUsername()+"}"
                        +"{"+ message.getRecipientUser().getUsername()+"}"
                        +"{"+ message.getText()+"}"
                        +"{"+ message.getId()+"}"
                        +"{"+ message.getDateTimeOfCreation()+"}";
            }
        }
        if (methodName.equals("getNextChatMessage")){
            Message message= controller.getNextChatMessage(Long.parseLong(methodInputs.get(0)) , Long.parseLong(methodInputs.get(1)) , clientId);
            if (message==null){response= "null";}
            else {
                response= "{"+ message.getCreatorUserId()+"}"
                        +"{"+ message.getRecipientUserId()+"}"
                        +"{"+ message.getCreatorUser().getUsername()+"}"
                        +"{"+ message.getRecipientUser().getUsername()+"}"
                        +"{"+ message.getText()+"}"
                        +"{"+ message.getId()+"}"
                        +"{"+ message.getDateTimeOfCreation()+"}";
            }
        }

        /*if (methodName.equals("getMessageImage")){
            BufferedImage photo= controller.getMessageImage(Long.parseLong(methodInputs.get(0)));
            if (photo==null){response="null";}
            else {
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                //ImageIO.write(image,"jpg",byteArrayOutputStream);
                response = new String(byteArrayOutputStream.toByteArray());
            }
        }*/

        /*if (methodName.equals("getProfileImage")){
            BufferedImage photo= controller.getProfileImage(Long.parseLong(methodInputs.get(0)));
            if (photo==null){response="null";}
            else {
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                //ImageIO.write(image,"jpg",byteArrayOutputStream);
                response = new String(byteArrayOutputStream.toByteArray());
            }
        }*/

        if (methodName.equals("deleteMessage")){
            controller.deleteMessage(Long.parseLong(methodInputs.get(0)),clientId);
        }
        if (methodName.equals("getChatWithUserId")){
            Chat chat= controller.getChatWithUserId(Long.parseLong(methodInputs.get(0)), clientId);
            if (chat==null){response= "null";}
            else {
                response= "{"+chat.getUser1Id()+"}"
                        +"{"+chat.getUser2Id()+"}"
                        +"{"+chat.getId()+"}"
                        +"{"+chat.getDateTimeOfCreation()+"}";
            }
        }

        if (methodName.equals("getNextSystemMessage")){
            SystemMessage systemMessage= controller.getNextSystemMessage(Long.parseLong(methodInputs.get(0)) , clientId);
            if (systemMessage==null){response= "null";}
            else {
                response= "{"+ systemMessage.getRecipientId()+"}"
                        +"{"+ systemMessage.getText()+"}"
                        +"{"+ systemMessage.getId()+"}"
                        +"{"+ systemMessage.getDateTimeOfCreation()+"}";
            }
        }
        if (methodName.equals("getPreviousSystemMessage")){
            SystemMessage systemMessage= controller.getPreviousSystemMessage(Long.parseLong(methodInputs.get(0)) , clientId);
            if (systemMessage==null){response= "null";}
            else {
                response= "{"+ systemMessage.getRecipientId()+"}"
                        +"{"+ systemMessage.getText()+"}"
                        +"{"+ systemMessage.getId()+"}"
                        +"{"+ systemMessage.getDateTimeOfCreation()+"}";
            }
        }
        if (methodName.equals("createNewMessage")){
            System.out.println("createNewMessage");
            Message message= controller.createNewMessage (Long.parseLong(methodInputs.get(0)) , Long.parseLong(methodInputs.get(1)), methodInputs.get(2) , image , clientId);
            if (message==null){response= "null";}
            else {
                response= "{"+ message.getCreatorUserId()+"}"
                        +"{"+ message.getRecipientUserId()+"}"
                        +"{"+ message.getCreatorUser().getUsername()+"}"
                        +"{"+ message.getRecipientUser().getUsername()+"}"
                        +"{"+ message.getText()+"}"
                        +"{"+ message.getId()+"}"
                        +"{"+ message.getDateTimeOfCreation()+"}";
            }
        }
        return response;
    }































    private String messagingPageController(String methodName , long myId , LinkedList<String> methodInputs , BufferedImage image){
        String response= "";
        MessagingPageController controller= new MessagingPageController();

        if (methodName.equals("myFirstGroup")){
            Group group= controller.myFirstGroup(myId);
            if (group==null){response= "null";}
            else {
                response= "{"+group.getId()+"}"
                        +"{"+group.getName()+"}";
            }
        }
        if (methodName.equals("getAnotherUser")){
            User user= controller.getAnotherUser(Long.parseLong(methodInputs.get(0)), myId);
            if (user==null){response= "null";}
            else {
                response= "{"+user.getId()+"}"
                        +"{"+user.getUsername()+"}"
                        +"{"+user.getProfile().getFirstName()+"}"
                        +"{"+user.getProfile().getLastName()+"}"
                        +"{"+user.getProfile().getEmail()+"}"
                        +"{"+user.getProfile().getBiography()+"}"
                        +"{"+user.getProfile().getPhoneNumber()+"}"
                        +"{"+user.getProfile().getLastSeenDate()+"}"
                        +"{"+user.getProfile().getDateOfBirth()+"}"
                        +"{"+user.getProfile().isActive()+"}"
                        +"{"+user.getProfile().isPrivateAccount()+"}"
                        +"{"+user.getProfile().getShowLastSeenDate()+"}"
                        +"{"+user.getProfile().getShowDateOfBirth()+"}"
                        +"{"+user.getProfile().getShowEmail()+"}"
                        +"{"+user.getProfile().getShowPhoneNumber()+"}";
            }
        }

        /*if (methodName.equals("getMessageImage")){
            BufferedImage photo= controller.getMessageImage(Long.parseLong(methodInputs.get(0)));
            if (photo==null){response="null";}
            else {
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                //ImageIO.write(image,"jpg",byteArrayOutputStream);
                response = new String(byteArrayOutputStream.toByteArray());
            }
        }*/

        if (methodName.equals("getPreviousSavedMessage")){
            Message message= controller.getPreviousSavedMessage(Long.parseLong(methodInputs.get(0)) ,  myId);
            if (message==null){response= "null";}
            else {
                if (message.getRecipientUser() == null){
                    response = "{" + message.getCreatorUserId() + "}"
                            + "{" + message.getRecipientUserId() + "}"
                            + "{" + message.getCreatorUser().getUsername() + "}"
                            + "{" + "null" + "}"
                            + "{" + message.getText() + "}"
                            + "{" + message.getId() + "}"
                            + "{" + message.getDateTimeOfCreation() + "}";
                }
                else {
                    response = "{" + message.getCreatorUserId() + "}"
                            + "{" + message.getRecipientUserId() + "}"
                            + "{" + message.getCreatorUser().getUsername() + "}"
                            + "{" + message.getRecipientUser().getUsername() + "}"
                            + "{" + message.getText() + "}"
                            + "{" + message.getId() + "}"
                            + "{" + message.getDateTimeOfCreation() + "}";
                }
            }
        }

        if (methodName.equals("getNextSavedMessage")){
            Message message= controller.getNextSavedMessage(Long.parseLong(methodInputs.get(0)) ,  myId);
            if (message==null){response= "null";}
            else {
                if (message.getRecipientUser() == null){
                    response = "{" + message.getCreatorUserId() + "}"
                            + "{" + message.getRecipientUserId() + "}"
                            + "{" + message.getCreatorUser().getUsername() + "}"
                            + "{" + "null" + "}"
                            + "{" + message.getText() + "}"
                            + "{" + message.getId() + "}"
                            + "{" + message.getDateTimeOfCreation() + "}";
                }
                else {
                    response = "{" + message.getCreatorUserId() + "}"
                            + "{" + message.getRecipientUserId() + "}"
                            + "{" + message.getCreatorUser().getUsername() + "}"
                            + "{" + message.getRecipientUser().getUsername() + "}"
                            + "{" + message.getText() + "}"
                            + "{" + message.getId() + "}"
                            + "{" + message.getDateTimeOfCreation() + "}";
                }
            }
        }

        if (methodName.equals("getFirstChat")){
            Chat chat= controller.getFirstChat(myId);
            if (chat==null){response= "null";}
            else {
                response= "{"+chat.getUser1Id()+"}"
                        +"{"+chat.getUser2Id()+"}"
                        +"{"+chat.getId()+"}";
            }
        }

        if (methodName.equals("getNumberOfUnreadMessages")){
            response= String.valueOf(controller.getNumberOfUnreadMessages(Long.parseLong(methodInputs.get(0)), myId));
        }
        if (methodName.equals("getFirstSavedMessages")){
            Message message= controller.getFirstSavedMessages( myId );
            if (message==null){
                response= "null";
            }
            else {
                if (message.getRecipientUser()==null){
                    response = "{" + message.getCreatorUserId() + "}"
                            + "{" + message.getRecipientUserId() + "}"
                            + "{" + message.getCreatorUser().getUsername() + "}"
                            + "{" + "null" + "}"
                            + "{" + message.getText() + "}"
                            + "{" + message.getId() + "}"
                            + "{" + message.getDateTimeOfCreation() + "}";
                }
                else {
                    response = "{" + message.getCreatorUserId() + "}"
                            + "{" + message.getRecipientUserId() + "}"
                            + "{" + message.getCreatorUser().getUsername() + "}"
                            + "{" + message.getRecipientUser().getUsername() + "}"
                            + "{" + message.getText() + "}"
                            + "{" + message.getId() + "}"
                            + "{" + message.getDateTimeOfCreation() + "}";
                }
            }
        }
        if (methodName.equals("createNewSavedMessage")){
            controller.createNewSavedMessage( methodInputs.get(0) , image ,myId);
        }
        return response;
    }































    private String postNewTweetController(String methodName , LinkedList<String> methodInputs , long myId , BufferedImage image){

        PostNewTweetController controller= new PostNewTweetController();
        if (methodName.equals("createNewTweet")){
            controller.createNewTweet(methodInputs.get(0) , image , myId);
        }
        return "";
    }































    private String viewYourTweetController(String methodName , long clientId , LinkedList<String> methodInputs){
        String response= "";
        ViewYourTweetController controller= new ViewYourTweetController();

        if (methodName.equals("getPreviousTweet")){
            Tweet tweet= controller.getPreviousTweet ( Long.parseLong(methodInputs.get(0)) , clientId );
            if (tweet==null){response="null";}
            else {
                response = "{"+tweet.getId()+"}"
                        +"{"+ tweet.getOwnerTweetId()+"}"
                        +"{"+ tweet.getText()+"}"
                        +"{"+ tweet.getCreatorUserId()+"}"
                        +"{"+ tweet.getCreatorUser().getUsername()+"}"
                        +"{"+ tweet.getReportNumber()+"}"
                        +"{"+ tweet.getDateTimeOfCreation()+"}";
            }
        }
        if (methodName.equals("getNextTweet")){
            Tweet tweet= controller.getNextTweet ( Long.parseLong(methodInputs.get(0)) , clientId );
            if (tweet==null){response="null";}
            else {
                response = "{"+tweet.getId()+"}"
                        +"{"+ tweet.getOwnerTweetId()+"}"
                        +"{"+ tweet.getText()+"}"
                        +"{"+ tweet.getCreatorUserId()+"}"
                        +"{"+ tweet.getCreatorUser().getUsername()+"}"
                        +"{"+ tweet.getReportNumber()+"}"
                        +"{"+ tweet.getDateTimeOfCreation()+"}";
            }
        }
        if (methodName.equals("getMyFirstTweet")){
            Tweet tweet= controller.getMyFirstTweet ( clientId );
            if (tweet==null){response="null";}
            else {
                response = "{"+tweet.getId()+"}"
                        +"{"+ tweet.getOwnerTweetId()+"}"
                        +"{"+ tweet.getText()+"}"
                        +"{"+ tweet.getCreatorUserId()+"}"
                        +"{"+ tweet.getCreatorUser().getUsername()+"}"
                        +"{"+ tweet.getReportNumber()+"}"
                        +"{"+ tweet.getDateTimeOfCreation()+"}";
            }
        }

        /*if (methodName.equals("getTweetImage")){
            BufferedImage image= controller.getTweetImage(Long.parseLong(methodInputs.get(0)));
            if (image==null){response="null";}
            else {
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                //ImageIO.write(image,"jpg",byteArrayOutputStream);
                response = new String(byteArrayOutputStream.toByteArray());
            }
        }*/

        /*if (methodName.equals("getProfileImage")){
            BufferedImage image= controller.getProfileImage(Long.parseLong(methodInputs.get(0)));
            if (image==null){response="null";}
            else {
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                //ImageIO.write(image,"jpg",byteArrayOutputStream);
                response = new String(byteArrayOutputStream.toByteArray());
            }
        }*/

        if (methodName.equals("getUser")){
            User user= controller.getUser(Long.parseLong(methodInputs.get(0)),clientId);
            if (user==null){response= "null";}
            else {
                response= "{"+user.getId()+"}"
                        +"{"+user.getUsername()+"}"
                        +"{"+user.getProfile().getFirstName()+"}"
                        +"{"+user.getProfile().getLastName()+"}"
                        +"{"+user.getProfile().getEmail()+"}"
                        +"{"+user.getProfile().getBiography()+"}"
                        +"{"+user.getProfile().getPhoneNumber()+"}"
                        +"{"+user.getProfile().getLastSeenDate()+"}"
                        +"{"+user.getProfile().getDateOfBirth()+"}"
                        +"{"+user.getProfile().isActive()+"}"
                        +"{"+user.getProfile().isPrivateAccount()+"}"
                        +"{"+user.getProfile().getShowLastSeenDate()+"}"
                        +"{"+user.getProfile().getShowDateOfBirth()+"}"
                        +"{"+user.getProfile().getShowEmail()+"}"
                        +"{"+user.getProfile().getShowPhoneNumber()+"}";
            }
        }
        return response;
    }































    private String privacySettingsController(String methodName , LinkedList<String> methodInputs , long myId){
        PrivacySettingsController controller= new PrivacySettingsController();

        if (methodName.equals("activeInactive")){
            controller.activeInactive( methodInputs.get(0) , myId);
        }
        if (methodName.equals("lastSeenOnline")){
            controller.lastSeenOnline( methodInputs.get(0) , myId);
        }
        if (methodName.equals("makeAccountPublic")){
            controller.makeAccountPublic(myId);
        }
        if (methodName.equals("makeAccountPrivate")){
            controller.makeAccountPrivate(myId);
        }
        if (methodName.equals("showDateOfBirth")){
            controller.showDateOfBirth( methodInputs.get(0) , myId );
        }
        if (methodName.equals("showEmail")){
            controller.showEmail(methodInputs.get(0) , myId);
        }
        if (methodName.equals("showPhoneNumber")){
            controller.showPhoneNumber( methodInputs.get(0) , myId );
        }
        return "";
    }































    private String requestController(String methodName , LinkedList<String> methodInputs , long clientId){
        String response= "";
        RequestController controller= new RequestController();
        if (methodName.equals("accept")){
            controller.accept(Long.parseLong(methodInputs.get(0)),clientId);
        }
        if (methodName.equals("getNextRequest")){
            Request request= controller.getNextRequest ( clientId );
            if (request==null){response="null";}
            else {
                response = "{"+request.getRequesterId()+"}"
                        + "{"+request.getRequestedId()+"}"
                        + "{"+request.getId()+"}"
                        + "{"+request.getText()+"}";
            }
        }
        if (methodName.equals("rejectAndLetHerHimKnow")){
            controller.rejectAndLetHerHimKnow(Long.parseLong(methodInputs.get(0)),clientId);
        }
        if (methodName.equals("rejectWithoutNotifying")){
            controller.rejectWithoutNotifying(Long.parseLong(methodInputs.get(0)),clientId);
        }
        return response;
    }































    private String tweetController( String methodName , LinkedList<String> methodInputs , long clientId){
        String response= "";
        TweetController controller= new TweetController();
        if (methodName.equals("getFirstComment")){
            if (controller.getFirstComment(Long.parseLong(methodInputs.get(0)),clientId)==null){response="null";}
            else {
                Comment comment= controller.getFirstComment(Long.parseLong(methodInputs.get(0)),clientId);
                response= "{"+comment.getId()+"}"
                        +"{"+comment.getOwnerTweetId()+"}"
                        +"{"+comment.getText()+"}"
                        +"{"+comment.getCreatorUserId()+"}"
                        +"{"+comment.getCreatorUser().getUsername()+"}"
                        +"{"+comment.getReportNumber()+"}"
                        +"{"+comment.getDateTimeOfCreation()+"}";
            }
        }
        if (methodName.equals("getPreviousTweet")){
            Tweet tweet= controller.getPreviousTweet ( Long.parseLong(methodInputs.get(0)) , Boolean.parseBoolean(methodInputs.get(0)), clientId );
            if (tweet==null){response="null";}
            else {
                response = "{"+tweet.getId()+"}"
                        +"{"+ tweet.getOwnerTweetId()+"}"
                        +"{"+ tweet.getText()+"}"
                        +"{"+ tweet.getCreatorUserId()+"}"
                        +"{"+ tweet.getCreatorUser().getUsername()+"}"
                        +"{"+ tweet.getReportNumber()+"}"
                        +"{"+ tweet.getDateTimeOfCreation()+"}";
            }
        }

        if (methodName.equals("getNextTweet")){
            Tweet tweet= controller.getNextTweet ( Long.parseLong(methodInputs.get(0)) , Boolean.parseBoolean(methodInputs.get(0)), clientId );
            if (tweet==null){response="null";}
            else {
                response = "{"+tweet.getId()+"}"
                        +"{"+ tweet.getOwnerTweetId()+"}"
                        +"{"+ tweet.getText()+"}"
                        +"{"+ tweet.getCreatorUserId()+"}"
                        +"{"+ tweet.getCreatorUser().getUsername()+"}"
                        +"{"+ tweet.getReportNumber()+"}"
                        +"{"+ tweet.getDateTimeOfCreation()+"}";
            }
        }

        /*if (methodName.equals("getTweetImage")){
            BufferedImage image= controller.getTweetImage(Long.parseLong(methodInputs.get(0)));
            if (image==null){response="null";}
            else {
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                //ImageIO.write(image,"jpg",byteArrayOutputStream);
                response = new String(byteArrayOutputStream.toByteArray());
            }
        }*/

        /*if (methodName.equals("getProfileImage")){
            BufferedImage image= controller.getProfileImage(Long.parseLong(methodInputs.get(0)));
            if (image==null){response="null";}
            else {
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                //ImageIO.write(image,"jpg",byteArrayOutputStream);
                response = new String(byteArrayOutputStream.toByteArray());
            }
        }*/

        if (methodName.equals("buttonMode")){
            response= controller.buttonMode(Long.parseLong(methodInputs.get(0)), clientId);
        }
        if (methodName.equals("showLastSeenDate")){
            response= String.valueOf(controller.showLastSeenDate(Long.parseLong(methodInputs.get(0)), clientId));
        }
        if (methodName.equals("showDateOfBirth")){
            response= String.valueOf(controller.showDateOfBirth( Long.parseLong(methodInputs.get(0)), clientId ));
        }
        if (methodName.equals("showEmail")){
            response= String.valueOf(controller.showEmail( Long.parseLong(methodInputs.get(0)), clientId ));
        }
        if (methodName.equals("showPhoneNumber")){
            response= String.valueOf(controller.showPhoneNumber( Long.parseLong(methodInputs.get(0)), clientId ));
        }
        if (methodName.equals("like")){
            controller.like( Long.parseLong(methodInputs.get(0)), clientId  );
        }
        if (methodName.equals("addTweetToSavedMessages")){
            controller.addTweetToSavedMessages(Long.parseLong(methodInputs.get(0)), clientId);
        }
        if (methodName.equals("retweet")){
            controller.retweet(Long.parseLong(methodInputs.get(0)), clientId);
        }
        if (methodName.equals("block")){
            controller.block( Long.parseLong(methodInputs.get(0)), clientId );
        }
        if (methodName.equals("mute")){
            controller.mute( Long.parseLong(methodInputs.get(0)) , clientId );
        }
        if (methodName.equals("reportSpam")){
            controller.reportSpam(Long.parseLong(methodInputs.get(0)),clientId);
        }
        if (methodName.equals("createNewComment")){
            controller.createNewComment(methodInputs.get(0), Long.parseLong(methodInputs.get(1)) , clientId);
        }
        if (methodName.equals("getTweet")){
            Tweet tweet= controller.getTweet ( Long.parseLong(methodInputs.get(0))  ,clientId);
            if (tweet==null){response="null";}
            else {
                response = "{"+tweet.getId()+"}"
                        +"{"+ tweet.getOwnerTweetId()+"}"
                        +"{"+ tweet.getText()+"}"
                        +"{"+ tweet.getCreatorUserId()+"}"
                        +"{"+ tweet.getCreatorUser().getUsername()+"}"
                        +"{"+ tweet.getReportNumber()+"}"
                        +"{"+ tweet.getDateTimeOfCreation()+"}";
            }
        }
        if (methodName.equals("getUserWithId")){
            User user= controller.getUserWithId(Long.parseLong(methodInputs.get(0)),clientId);
            if (user==null){response= "null";}
            else {
                response= "{"+user.getId()+"}"
                        +"{"+user.getUsername()+"}"
                        +"{"+user.getProfile().getFirstName()+"}"
                        +"{"+user.getProfile().getLastName()+"}"
                        +"{"+user.getProfile().getEmail()+"}"
                        +"{"+user.getProfile().getBiography()+"}"
                        +"{"+user.getProfile().getPhoneNumber()+"}"
                        +"{"+user.getProfile().getLastSeenDate()+"}"
                        +"{"+user.getProfile().getDateOfBirth()+"}"
                        +"{"+user.getProfile().isActive()+"}"
                        +"{"+user.getProfile().isPrivateAccount()+"}"
                        +"{"+user.getProfile().getShowLastSeenDate()+"}"
                        +"{"+user.getProfile().getShowDateOfBirth()+"}"
                        +"{"+user.getProfile().getShowEmail()+"}"
                        +"{"+user.getProfile().getShowPhoneNumber()+"}";
            }
        }
        return response;
    }
}
