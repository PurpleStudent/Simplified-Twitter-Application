package main;


import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {

    public static void main(String[] args) throws IOException {

        ServerSocket serverSocket= new ServerSocket(9000);

        while (true) {

            //System.out.println("waiting for a client...");
            Socket socket = serverSocket.accept();  //client
            //System.out.println("client connected.");

            Thread clientThread= new ClientThread(socket);
            clientThread.start();

            //PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            //Scanner scanner = new Scanner(System.in);
            //String message = "Hello";
            //do {
            //output.println(message);
            //message= scanner.nextLine();
            //}while (!message.equals("-1"));
            //Scanner input = new Scanner(socket.getInputStream());
            //System.out.println(input.nextLine());
        }


        //socket.close();
    }
}
