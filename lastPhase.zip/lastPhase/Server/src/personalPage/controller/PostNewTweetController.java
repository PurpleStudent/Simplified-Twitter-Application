package personalPage.controller;

import authentication.model.User;
import controller.Controller;
import database.MyLogger;
import tweet.model.Comment;
import tweet.model.Tweet;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.Collections;
import java.util.LinkedList;

public class PostNewTweetController extends Controller {



    private synchronized long createNewId (long clientId) {
        long n = 1;
        LinkedList<Long> idList=new LinkedList<>();
        for (Tweet tweet : context.tweetDataBaseSet.all()) { idList.add(tweet.getId()); }
        for (Comment comment : context.commentDataBaseSet.all()){idList.add(comment.getId());}
        if (idList.size()>0){n= Collections.max(idList)+1;}
        MyLogger myLogger = new MyLogger(
                "src/personalPage/controller/PostNewTweetController.java" ,
                "createNewId" ,
                clientId
        );
        return n;
    }
















    public void createNewTweet ( String textOfTweet , BufferedImage image   , long clientId){
        Tweet tweet= new Tweet ( clientId , textOfTweet ) ;
        tweet.setId(createNewId(clientId));
        tweet.setCreatorUser(context.userDataBaseSet.get(clientId));
        context.tweetDataBaseSet.add(tweet);
        MyLogger myLogger= new MyLogger(
                "src/personalPage/controller/PostNewTweetController.java",
                "createNewTweet",
                clientId
        );
        if ( image != null ) {
            copy ( image , tweet.getId(),clientId );
        }
    }























    private void copy ( BufferedImage image , long tweetId , long clientId) {
        try {
            if ( image != null ) {
                String path = new File("").getAbsolutePath();
                String photoPath = path + "\\" + "resources\\Tweets Photos\\" + tweetId + ".jpg";
                File photoFile = new File(photoPath);
                photoFile.getParentFile().mkdirs();
                if (!photoFile.exists()) {
                    photoFile.createNewFile();
                }
                ImageIO.write(image, "jpg", photoFile);
                MyLogger myLogger = new MyLogger(
                        "src/personalPage/controller/PostNewTweetController.java",
                        "copy" ,
                        clientId
                );
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }















    /*private static void copyFileUsingStream(File source, File dest) {
        InputStream is = null;
        OutputStream os = null;
        try {
            is = new FileInputStream(source);
            os = new FileOutputStream(dest);
            byte[] buffer = new byte[1024];
            int length;
            while ((length = is.read(buffer)) > 0) {
                os.write(buffer, 0, length);
            }
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        finally {
            try {
                is.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                os.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }*/
}
