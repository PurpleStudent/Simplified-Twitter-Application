package personalPage.controller;

import authentication.model.User;
import controller.Controller;
import database.MyLogger;
import tweet.model.Tweet;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Collections;
import java.util.LinkedList;

public class ViewYourTweetController extends Controller {


    public BufferedImage getTweetImage(long tweetId , long clientId){
        try {
            String path = new File("").getAbsolutePath();
            String photoPath = path + "\\" + "resources\\Tweets Photos\\" + tweetId+".jpg";
            MyLogger myLogger = new MyLogger(
                    "src/personalPage/controller/ViewYourTweetController.java" ,
                    "getTweetImage" ,
                    clientId
            );
            return ImageIO.read(new File(photoPath));
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }















    public BufferedImage getProfileImage(long userId , long clientId){
        try {
            String path = new File("").getAbsolutePath();
            String photoPath = path + "\\" + "resources\\Users Photos\\" + userId+".jpg";
            MyLogger myLogger = new MyLogger(
                    "src/personalPage/controller/ViewYourTweetController.java" ,
                    "getProfileImage" ,
                    clientId
            );
            return ImageIO.read(new File(photoPath));
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }





























    public User getUser(long userId , long clientId){
        MyLogger myLogger = new MyLogger(
                "src/personalPage/controller/ViewYourTweetController.java" ,
                "getUser" ,
                clientId
        );
        return context.userDataBaseSet.get(userId);
    }































    public LinkedList<Tweet> getMyTweets( long clientId){
        LinkedList<Tweet> myTweets= new LinkedList<>();
        for (Tweet tweet: context.tweetDataBaseSet.all()) {
            if (tweet.getCreatorUserId()== clientId){
                tweet.setCreatorUser(context.userDataBaseSet.get(clientId));
                myTweets.add(tweet);
            }
        }
        MyLogger myLogger = new MyLogger(
                "src/personalPage/controller/ViewYourTweetController.java" ,
                "getMyTweets" ,
                clientId
        );
        return myTweets;
    }

























    public Tweet getMyFirstTweet ( long clientId) {
        Tweet tweet= null;
        if ( !getMyTweets(clientId).isEmpty() ) {
            tweet = getMyTweets(clientId).getLast();
        }
        MyLogger myLogger = new MyLogger(
                "src/personalPage/controller/ViewYourTweetController.java" ,
                "getMyFirstTweet" ,
                clientId
        );
        return tweet;
    }



























    public Tweet getPreviousTweet(long currentTweetId  , long clientId){
        LinkedList<Long> previousTweetsId= new LinkedList<>();
        for (Tweet tweet: getMyTweets(clientId)) {
            if (tweet.getId()<currentTweetId){
                previousTweetsId.add(tweet.getId());
            }
        }
        Tweet tweet;
        if (previousTweetsId.size()==0){
            tweet=context.tweetDataBaseSet.get(currentTweetId);
        }
        else {
            long previousTweetId= Collections.max(previousTweetsId);
            tweet= context.tweetDataBaseSet.get(previousTweetId);
        }
        tweet.setCreatorUser(context.userDataBaseSet.get(clientId));
        MyLogger myLogger = new MyLogger(
                "src/personalPage/controller/ViewYourTweetController.java" ,
                "getPreviousTweet" ,
                clientId
        );
        return tweet;
    }
















    public Tweet getNextTweet(long currentTweetId  , long clientId){
        LinkedList<Long> nextTweetsId= new LinkedList<>();

        for (Tweet tweet: getMyTweets(clientId)) {
            if (tweet.getId()>currentTweetId){
                nextTweetsId.add(tweet.getId());
            }
        }
        Tweet tweet;
        if (nextTweetsId.size()==0){
            tweet=context.tweetDataBaseSet.get(currentTweetId);
        }
        else {
            long nextTweetId= Collections.min(nextTweetsId);
            tweet= context.tweetDataBaseSet.get(nextTweetId);
        }
        tweet.setCreatorUser(context.userDataBaseSet.get(clientId));
        MyLogger myLogger = new MyLogger(
                "src/personalPage/controller/ViewYourTweetController.java" ,
                "getNextTweet" ,
                clientId
        );
        return tweet;
    }













}










