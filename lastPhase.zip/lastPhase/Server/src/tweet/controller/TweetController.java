package tweet.controller;

import authentication.model.User;
import controller.Controller;
import database.MyLogger;
import message.model.Message;
import tweet.model.Comment;
import tweet.model.Tweet;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Collections;
import java.util.LinkedList;

public class TweetController extends Controller {

    public User getUserWithId(long id , long clientId){
        MyLogger myLogger = new MyLogger(
                "src/tweet/controller/TweetController.java" ,
                "getUserWithId" ,
                clientId
        );
        return context.userDataBaseSet.get(id);
    }

















    public void reportSpam(long tweetId , long clientId){
        Tweet newTweet= context.tweetDataBaseSet.get(tweetId);
        newTweet.setReportNumber(newTweet.getReportNumber()+1);
        context.tweetDataBaseSet.update(newTweet);
        MyLogger myLogger= new MyLogger(
                "src/tweet/controller/TweetController.java",
                "reportSpam",
                clientId
        );
    }


























    public BufferedImage getTweetImage(long tweetId , long clientId){
        try {
            String path = new File("").getAbsolutePath();
            String photoPath = path + "\\" + "resources\\Tweets Photos\\" + tweetId+".jpg";
            MyLogger myLogger = new MyLogger(
                    "src/tweet/controller/TweetController.java" ,
                    "getTweetImage" ,
                    clientId
            );
            return ImageIO.read(new File(photoPath));
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }






















    public BufferedImage getProfileImage(long userId , long clientId){
        try {
            String path = new File("").getAbsolutePath();
            String photoPath = path + "\\" + "resources\\Users Photos\\" + userId+".jpg";
            MyLogger myLogger = new MyLogger(
                    "src/tweet/controller/TweetController.java" ,
                    "getProfileImage" ,
                    clientId
            );
            return ImageIO.read(new File(photoPath));
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }































    public void createNewComment(String text, long ownerTweetId , long clientId){
        Comment comment= new Comment(clientId ,text,ownerTweetId);
        comment.setId(createNewCommentId(clientId));
        comment.setCreatorUser(context.userDataBaseSet.get(clientId));
        context.commentDataBaseSet.add(comment);
        MyLogger myLogger= new MyLogger(
                "src/tweet/controller/TweetController.java",
                "createNewComment",
                clientId
        );
    }
























    private synchronized long createNewCommentId (long clientId) {
        long n = 1;
        LinkedList<Long> idList=new LinkedList<>();
        for (Tweet tweet : context.tweetDataBaseSet.all()) { idList.add(tweet.getId()); }
        for (Comment comment : context.commentDataBaseSet.all()){idList.add(comment.getId());}
        if (idList.size()>0){n= Collections.max(idList)+1;}
        MyLogger myLogger = new MyLogger(
                "src/tweet/controller/TweetController.java" ,
                "createNewCommentId" ,
                clientId
        );
        return n;
    }

























    public Tweet getTweet(long id , long clientId){
        boolean isTweet=false;
        for (Tweet tweet: context.tweetDataBaseSet.all()) {
            if (tweet.getId()==id){isTweet=true; break;}
        }
        Tweet tweet= null;
        if (isTweet){tweet= context.tweetDataBaseSet.get(id);}
        if (!isTweet){tweet= context.commentDataBaseSet.get(id);}
        tweet.setCreatorUser(context.userDataBaseSet.get(tweet.getCreatorUserId()));
        MyLogger myLogger = new MyLogger(
                "src/tweet/controller/TweetController.java" ,
                "getTweet" ,
                clientId
        );
        return tweet;
    }





















    public Tweet getPreviousTweet(long currentTweetId, boolean fromExplorer  , long clientId){
        boolean isTweet=false;
        for (Tweet tweet: context.tweetDataBaseSet.all()) {
            if (tweet.getId()==currentTweetId){isTweet=true; break;}
        }
        Tweet previousTweet= null;
        if (!isTweet){
            Comment currentComment= context.commentDataBaseSet.get(currentTweetId);
            LinkedList<Long> previousTweetsId= new LinkedList<>();
            for (long tweetId: getCommentsId(currentComment.getOwnerTweetId(),clientId)) {
                if (tweetId<currentTweetId){
                    previousTweetsId.add(tweetId);
                }
            }
            if (previousTweetsId.size()==0){
                previousTweet=context.commentDataBaseSet.get(currentTweetId);
            }
            else {
                long previousTweetId= Collections.max(previousTweetsId);
                previousTweet= context.commentDataBaseSet.get(previousTweetId);
            }
            previousTweet.setCreatorUser(context.userDataBaseSet.get(previousTweet.getCreatorUserId()));
        }
        else {
            LinkedList<Long> previousTweetsId= new LinkedList<>();

            if (fromExplorer){
                for (long tweetId : randomTweetsOrPopularTweets(clientId)) {
                    if (tweetId < currentTweetId) {
                        previousTweetsId.add(tweetId);
                    }
                }
            }
            else {
                for (long tweetId : displayableTweetsId(clientId)) {
                    if (tweetId < currentTweetId) {
                        previousTweetsId.add(tweetId);
                    }
                }
            }

            if (previousTweetsId.size()==0){
                previousTweet=context.tweetDataBaseSet.get(currentTweetId);
            }
            else {
                long previousTweetId= Collections.max(previousTweetsId);
                previousTweet= context.tweetDataBaseSet.get(previousTweetId);
            }
            previousTweet.setCreatorUser(context.userDataBaseSet.get(previousTweet.getCreatorUserId()));
        }
        MyLogger myLogger = new MyLogger(
                "src/tweet/controller/TweetController.java" ,
                "getPreviousTweet" ,
                clientId
        );
        return previousTweet;
    }


























    public Tweet getNextTweet(long currentTweetId, boolean fromExplorer  , long clientId){
        boolean isTweet=false;
        for (Tweet tweet: context.tweetDataBaseSet.all()) {
            if (tweet.getId()==currentTweetId){isTweet=true; break;}
        }
        Tweet nextTweet= null;

        if (!isTweet){
            Comment currentComment= context.commentDataBaseSet.get(currentTweetId);
            LinkedList<Long> nextCommentsId= new LinkedList<>();
            for (long tweetId: getCommentsId(currentComment.getOwnerTweetId(),clientId)) {
                if (tweetId>currentTweetId){
                    nextCommentsId.add(tweetId);
                }
            }
            if (nextCommentsId.size()==0){
                nextTweet=context.commentDataBaseSet.get(currentTweetId);
            }
            else {
                long previousTweetId= Collections.min(nextCommentsId);
                nextTweet= context.commentDataBaseSet.get(previousTweetId);
            }
            nextTweet.setCreatorUser(context.userDataBaseSet.get(nextTweet.getCreatorUserId()));
        }

        else {
            LinkedList<Long> nextCommentsId= new LinkedList<>();

            if (fromExplorer){
                for (long tweetId : randomTweetsOrPopularTweets(clientId)) {
                    if (tweetId > currentTweetId) {
                        nextCommentsId.add(tweetId);
                    }
                }
            }
            else {
                for (long tweetId : displayableTweetsId(clientId)) {
                    if (tweetId > currentTweetId) {
                        nextCommentsId.add(tweetId);
                    }
                }
            }

            if (nextCommentsId.size()==0){
                nextTweet=context.tweetDataBaseSet.get(currentTweetId);
            }
            else {
                long previousTweetId= Collections.min(nextCommentsId);
                nextTweet= context.tweetDataBaseSet.get(previousTweetId);
            }
            nextTweet.setCreatorUser(context.userDataBaseSet.get(nextTweet.getCreatorUserId()));
        }
        MyLogger myLogger = new MyLogger(
                "src/tweet/controller/TweetController.java" ,
                "getNextTweet" ,
                clientId
        );
        return nextTweet;
    }


















    public void like(long tweetId ,  long clientId){
        if (!context.userDataBaseSet.getLikedTweetsId(context.userDataBaseSet.get(clientId)).contains(tweetId)) {
            context.userDataBaseSet.addLikedTweet(context.userDataBaseSet.get(clientId), tweetId);
            MyLogger myLogger= new MyLogger(
                    "src/tweet/controller/TweetController.java",
                    "like",
                    clientId
            );
        }
    }






















    public void addTweetToSavedMessages ( long tweetId ,  long clientId){
        Tweet tweet= getTweet(tweetId,clientId);
        Message message= new Message (tweet.getCreatorUserId(),tweet.getText(),0);
        message.setCreatorUser(context.userDataBaseSet.get(message.getCreatorUserId()));
        message.setId(createMessageNewId(clientId));
        context.messageDataBaseSet.add(message);
        context.userDataBaseSet.addSavedMessage(context.userDataBaseSet.get(clientId),message.getId());
        MyLogger myLogger= new MyLogger(
                "src/tweet/controller/TweetController.java",
                "addTweetToSavedMessages",
                clientId
        );
    }






















    private synchronized long createMessageNewId (long clientId) {
        long n = 1;
        LinkedList<Long> idList=new LinkedList<>();
        for (Message message : context.messageDataBaseSet.all()) { idList.add(message.getId()); }
        if (idList.size()>0){n= Collections.max(idList)+1;}
        MyLogger myLogger = new MyLogger(
                "src/tweet/controller/TweetController.java",
                "createMessageNewId" ,
                clientId
        );
        return n;
    }


























    public void retweet(long tweetId ,  long clientId){
        if (!context.userDataBaseSet.getRetweetedTweetsId(context.userDataBaseSet.get(clientId)).contains(tweetId)) {
            context.userDataBaseSet.addRetweetedTweet(context.userDataBaseSet.get(clientId), tweetId);
            MyLogger myLogger= new MyLogger(
                    "src/tweet/controller/TweetController.java",
                    "retweet",
                    clientId
            );
        }
    }






















    public void block (long creatorUserId ,  long clientId) {
        User creatorUser= getUserWithId(creatorUserId,clientId);
        context.userDataBaseSet.addBlackList(context.userDataBaseSet.get(clientId), creatorUserId);
        context.userDataBaseSet.removeFollowing(context.userDataBaseSet.get(clientId), creatorUserId);
        context.userDataBaseSet.removeFollower(context.userDataBaseSet.get(clientId), creatorUserId);
        context.userDataBaseSet.removeFollowing ( creatorUser , clientId);
        context.userDataBaseSet.removeFollower ( creatorUser , clientId);
        MyLogger myLogger= new MyLogger(
                "src/tweet/controller/TweetController.java",
                "block",
                clientId
        );
    }




















    public void mute(long creatorUserId ,  long clientId){
        context.userDataBaseSet.addMutedUser(context.userDataBaseSet.get(clientId),creatorUserId);
        MyLogger myLogger= new MyLogger(
                "src/tweet/controller/TweetController.java",
                "mute",
                clientId
        );
    }





















    private LinkedList<Long> getCommentsId (long ownerTweetId , long clientId) {
        LinkedList<Long> list= new LinkedList<>();
        for (Comment comment: context.commentDataBaseSet.all()) {
            if (comment.getOwnerTweetId()==ownerTweetId){list.add(comment.getId());}
        }
        MyLogger myLogger = new MyLogger(
                "src/tweet/controller/TweetController.java" ,
                "getCommentsId" ,
                clientId
        );
        return list;
    }
























    public Comment getFirstComment (long ownerTweetId , long clientId) {
        Comment comment= null;
        if (getCommentsId(ownerTweetId,clientId).size()>0) {
            long firstCommentId = Collections.max(getCommentsId(ownerTweetId,clientId));
            comment = context.commentDataBaseSet.get(firstCommentId);
            comment.setCreatorUser(context.userDataBaseSet.get(comment.getCreatorUserId()));
        }
        MyLogger myLogger = new MyLogger(
                "src/tweet/controller/TweetController.java" ,
                "getFirstComment" ,
                clientId
        );
        return comment;
    }



























    /*private LinkedList<Long> displayableTweetsId(){
        LinkedList<Long> displayableTweetsId= new LinkedList<>();
        LinkedList<User> myUsers= new LinkedList<>();
        for (long userId: context.userDataBaseSet.getFollowingsId(context.userDataBaseSet.get(User.currentUserId))) {
            if (!context.userDataBaseSet.getMutedUsersId(context.userDataBaseSet.get(User.currentUserId)).contains(userId)){
                myUsers.add(context.userDataBaseSet.get(userId));
            }
        }
        for (User user: myUsers){
            displayableTweetsId.addAll(getUserTweetsId(user));
            displayableTweetsId.addAll(context.userDataBaseSet.getLikedTweetsId(user));
            displayableTweetsId.addAll(context.userDataBaseSet.getRetweetedTweetsId(user));
        }
        return displayableTweetsId;
    }*/



    private LinkedList<Long> displayableTweetsId ( long clientId){
        LinkedList<Long> displayableTweetsId= new LinkedList<>();
        LinkedList<User> myUsers= new LinkedList<>();
        for (long userId: context.userDataBaseSet.getFollowingsId(context.userDataBaseSet.get(clientId))) {
            if (!context.userDataBaseSet.getMutedUsersId(context.userDataBaseSet.get(clientId)).contains(userId)){
                myUsers.add(context.userDataBaseSet.get(userId));
            }
        }
        /*for (User user: myUsers){
            displayableTweetsId.addAll(getUserTweetsId(user));
            displayableTweetsId.addAll(context.userDataBaseSet.getLikedTweetsId(user));
            displayableTweetsId.addAll(context.userDataBaseSet.getRetweetedTweetsId(user));
        }*/
        for (User user: myUsers){
            for (long id: getUserTweetsId(user,clientId)) {
                Tweet tweet= context.tweetDataBaseSet.get(id);
                if (tweet!=null) {
                    if (tweet.getReportNumber() < 5) {
                        displayableTweetsId.add(id);
                    }
                }
            }
            for (long id: context.userDataBaseSet.getLikedTweetsId(user)) {
                Tweet tweet= context.tweetDataBaseSet.get(id);
                if (tweet!=null) {
                    if (tweet.getReportNumber() < 5) {
                        displayableTweetsId.add(id);
                    }
                }
            }
            for (long id: context.userDataBaseSet.getRetweetedTweetsId(user)) {
                Tweet tweet= context.tweetDataBaseSet.get(id);
                if (tweet!=null) {
                    if (tweet.getReportNumber() < 5) {
                        displayableTweetsId.add(id);
                    }
                }
            }
        }
        MyLogger myLogger = new MyLogger(
                "src/tweet/controller/TweetController.java" ,
                "displayableTweetsId" ,
                clientId
        );
        return displayableTweetsId;
    }




































    private LinkedList<Long> getUserTweetsId(User user , long clientId){
        LinkedList<Long> userTweetsId= new LinkedList<>();
        for (Tweet tweet: context.tweetDataBaseSet.all()) {
            if (tweet.getCreatorUserId()== user.getId()){
                tweet.setCreatorUser(user);
                userTweetsId.add(tweet.getId());
            }
        }
        /*for (Comment comment: context.commentDataBaseSet.all()) {
            if (comment.getCreatorUserId()== user.getId()){
                comment.setCreatorUser(user);
                userTweetsId.add(comment.getId());
            }
        }*/
        MyLogger myLogger = new MyLogger(
                "src/tweet/controller/TweetController.java" ,
                "getUserTweetsId" ,
                clientId
        );
        return userTweetsId;
    }




















    public String buttonMode(long userId ,  long clientId){
        User user= getUserWithId(userId,clientId);
        String buttonMode= "";
        boolean b1= context.userDataBaseSet.getFollowingsId(context.userDataBaseSet.get(clientId)).contains(user.getId());
        boolean b2= context.userDataBaseSet.getBlackListsId(context.userDataBaseSet.get(clientId)).contains(user.getId());
        boolean b3= context.userDataBaseSet.getBlackListsId(user).contains (clientId);
        boolean b4= context.userDataBaseSet.getFollowersId(context.userDataBaseSet.get(clientId)).contains(user.getId());

        if (b1 && !b2 && !b3){buttonMode= "buttonMode1";}
        if (!b1 && !b2){
            if (b4){buttonMode= "buttonMode2";}
            else {buttonMode= "buttonMode3";}
        }
        if (!b1 && b2){buttonMode= "buttonMode4";}
        MyLogger myLogger = new MyLogger(
                "src/tweet/controller/TweetController.java" ,
                "buttonMode" ,
                clientId
        );
        return buttonMode;
    }
















    public boolean showLastSeenDate(long userId  , long clientId){
        User user= getUserWithId(userId,clientId);
        boolean show= false;
        if (context.userDataBaseSet.getFollowersId(user).contains(clientId)) {
            if (user.getProfile().getShowLastSeenDate().equals("everybody")) {
                show= true;
            }
            if (user.getProfile().getShowLastSeenDate().equals("nobody")) {
                show= false;
            }
            if (user.getProfile().getShowLastSeenDate().equals("followings")) {
                show= context.userDataBaseSet.getFollowingsId(user).contains(clientId);
            }
        }
        MyLogger myLogger = new MyLogger(
                "src/tweet/controller/TweetController.java" ,
                "showLastSeenDate" ,
                clientId
        );
        return show;
    }


















    public boolean showDateOfBirth(long userId ,  long clientId){
        User user= getUserWithId(userId,clientId);
        boolean show= false;
        if (user.getProfile().getShowDateOfBirth().equals("everybody")) {
            if (user.getProfile().getDateOfBirth()!=null) {
                show= true;
            }
        }
        if (user.getProfile().getShowDateOfBirth().equals("followings")) {
            if (context.userDataBaseSet.getFollowingsId(user).contains(clientId)) {
                if (user.getProfile().getDateOfBirth()!=null) {
                    show= true;
                }
            }
        }
        MyLogger myLogger = new MyLogger(
                "src/tweet/controller/TweetController.java" ,
                "showDateOfBirth" ,
                clientId
        );
        return show;
    }














    public boolean showEmail(long userId ,  long clientId){
        User user= getUserWithId(userId,clientId);
        boolean show= false;
        if (user.getProfile().getShowEmail().equals("everybody")) {
            show= true;
        }
        if (user.getProfile().getShowEmail().equals("followings")) {
            if (context.userDataBaseSet.getFollowingsId(user).contains(clientId)) {
                show= true;
            }
        }
        MyLogger myLogger = new MyLogger(
                "src/tweet/controller/TweetController.java" ,
                "showEmail" ,
                clientId
        );
        return show;
    }















    public boolean showPhoneNumber(long userId  , long clientId){
        User user= getUserWithId(userId,clientId);
        boolean show= false;
        if (user.getProfile().getShowPhoneNumber().equals("everybody")) {
            show= true;
        }
        if (user.getProfile().getShowPhoneNumber().equals("followings")) {
            if (context.userDataBaseSet.getFollowingsId(user).contains(clientId)) {
                show= true;
            }
        }
        MyLogger myLogger = new MyLogger(
                "src/tweet/controller/TweetController.java" ,
                "showPhoneNumber" ,
                clientId
        );
        return show;
    }



















    private LinkedList<Long> randomTweetsOrPopularTweets ( long clientId ){
        LinkedList<Long> randomTweetsOrPopularTweets= new LinkedList<>();
        for (Tweet tweet: context.tweetDataBaseSet.all()) {
            if (getLikeNumberOfTweet(tweet.getId(),clientId)>5 || tweet.getId()%2==0){
                tweet.setCreatorUser(context.userDataBaseSet.get(tweet.getCreatorUserId()));
                if (tweet.getCreatorUser().getProfile().isActive()) {
                    if (tweet.getReportNumber()<5) {
                        randomTweetsOrPopularTweets.add(tweet.getId());
                    }
                }
            }
        }
        /*for (Comment comment: context.commentDataBaseSet.all()) {
            if (getLikeNumberOfTweet(comment.getId())>5 || comment.getId()%2==0){
                comment.setCreatorUser(context.userDataBaseSet.get(comment.getCreatorUserId()));
                if (comment.getCreatorUser().getProfile().isActive()) {
                    randomTweetsOrPopularTweets.add(comment.getId());
                }
            }
        }*/
        MyLogger myLogger = new MyLogger(
                "src/tweet/controller/TweetController.java" ,
                "randomTweetsOrPopularTweets" ,
                clientId
        );
        return randomTweetsOrPopularTweets;
    }


































    private long getLikeNumberOfTweet(long tweetId , long clientId){
        long likeNumberOfTweet= 0;
        for (User user: context.userDataBaseSet.all()) {
            if (context.userDataBaseSet.getLikedTweetsId(user).contains(tweetId)){likeNumberOfTweet= likeNumberOfTweet+1;}
        }
        MyLogger myLogger = new MyLogger(
                "src/tweet/controller/TweetController.java" ,
                "getLikeNumberOfTweet" ,
                clientId
        );
        return likeNumberOfTweet;
    }



















}
