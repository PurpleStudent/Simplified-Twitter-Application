package tweet.model;

import model.DateTime;

public class Comment extends Tweet{


    private long ownerTweetId;


    public Comment(long creatorUserId, String text, long ownerTweetId) {
        super(creatorUserId, text);
        this.ownerTweetId= ownerTweetId;
        dateTimeOfCreation= DateTime.now();
    }


    public long getOwnerTweetId() {
        return ownerTweetId;
    }

    public void setOwnerTweetId(long ownerTweetId) {
        this.ownerTweetId = ownerTweetId;
    }
}
