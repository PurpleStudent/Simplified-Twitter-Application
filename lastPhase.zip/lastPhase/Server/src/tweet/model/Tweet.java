package tweet.model;

import authentication.model.User;
import model.DateTime;
import model.Model;

public class Tweet extends Model {


    protected final long creatorUserId;
    protected User creatorUser; //حواست به این باشه ها
    protected String text;
    protected long reportNumber;







    public Tweet(long creatorUserId, String text){
        this.creatorUserId=creatorUserId;
        this.text=text;
        //this.id=createNewId();
        dateTimeOfCreation= DateTime.now();
    }









    public String getText() {
        return text;
    }
    public void setText(String text) {
        this.text = text;
    }

    public long getCreatorUserId() {
        return creatorUserId;
    }

    public User getCreatorUser() { return creatorUser; }

    public void setCreatorUser(User creatorUser) { this.creatorUser = creatorUser; }


    public long getReportNumber() {
        return reportNumber;
    }

    public void setReportNumber(long reportNumber) {
        this.reportNumber = reportNumber;
    }

    public long getOwnerTweetId() {
        return -1;
    }
}
