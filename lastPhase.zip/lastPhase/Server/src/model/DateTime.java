package model;

import java.time.LocalDateTime;

public class DateTime extends Date{


    int hour;
    int minute;
    int second;

    DateTime(int year, int month, int day, int hour, int minute, int second) {
        super(year, month, day);
        this.hour=hour;
        this.minute=minute;
        this.second=second;
    }





    public int getHour() {return hour;}

    public int getMinute() {return minute;}

    public int getSecond() {return second;}





    public static DateTime now(){
        int hour= LocalDateTime.now().getHour();
        int minute= LocalDateTime.now().getMinute();
        int second= LocalDateTime.now().getSecond();
        int year= LocalDateTime.now().getYear();
        int month= LocalDateTime.now().getMonthValue();
        int day= LocalDateTime.now().getDayOfMonth();

        return new DateTime(year,month,day,hour,minute,second);
    }






    @Override
    public String toString() {
        return year+"-"+month+"-"+day+";"+hour+":"+minute+":"+second;
    }







    public static DateTime convertStringToDateTime(String s){
        DateTime dateTime;
        String str1= s.substring(0,s.indexOf(";"));
        String str2= s.substring(s.indexOf(";")+1);
        String year= str1.substring(0,str1.indexOf("-")); // year
        String s1= str1.substring(str1.indexOf("-")+1);
        String month= s1.substring(0,s1.indexOf("-")); // month
        String day= s1.substring(s1.indexOf("-")+1); // day
        String hour= str2.substring(0,str2.indexOf(":")); // hour
        String s3= str2.substring(str2.indexOf(":")+1);
        String minute= s3.substring(0,s3.indexOf(":")); // minute
        String s4= s3.substring(s3.indexOf(":")+1); //second
        dateTime = new DateTime(Integer.parseInt(year), Integer.parseInt(month),
                Integer.parseInt(day), Integer.parseInt(hour),
                Integer.parseInt(minute), Integer.parseInt(s4));
        return dateTime;
    }
}
