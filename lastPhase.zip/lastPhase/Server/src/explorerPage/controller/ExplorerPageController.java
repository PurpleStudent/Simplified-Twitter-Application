package explorerPage.controller;

import authentication.model.User;
import controller.Controller;
import database.MyLogger;
import tweet.model.Tweet;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Collections;
import java.util.LinkedList;

public class ExplorerPageController extends Controller {


    public Tweet firstExplorerTweet (long clientId) {
        Tweet tweet= null;
        if (randomTweetsOrPopularTweets(clientId).size()>0){
            long tweetId= Collections.max(randomTweetsOrPopularTweets(clientId));
            if (context.tweetDataBaseSet.get(tweetId)!=null){
                tweet= context.tweetDataBaseSet.get(tweetId);
                tweet.setCreatorUser(context.userDataBaseSet.get(tweet.getCreatorUserId()));
            }
            if ( context.commentDataBaseSet.get(tweetId)!=null ){
                tweet= context.commentDataBaseSet.get(tweetId);
                tweet.setCreatorUser(context.userDataBaseSet.get(tweet.getCreatorUserId()));
            }
        }
        MyLogger myLogger = new MyLogger(
                "src/explorerPage/controller/ExplorerPageController.java" ,
                "firstExplorerTweet" ,
                clientId
        );
        return tweet;
    }











    private LinkedList<Long> randomTweetsOrPopularTweets ( long clientId ) {
        LinkedList<Long> randomTweetsOrPopularTweets= new LinkedList<>();
        for (Tweet tweet: context.tweetDataBaseSet.all()) {
            if (getLikeNumberOfTweet(tweet.getId() ,clientId) >5 || tweet.getId()%2==0){
                tweet.setCreatorUser(context.userDataBaseSet.get(tweet.getCreatorUserId()));
                if (tweet.getCreatorUser().getProfile().isActive()) {
                    if (tweet.getReportNumber()<5) {
                        randomTweetsOrPopularTweets.add(tweet.getId());
                    }
                }
            }
        }
        /*for (Comment comment: context.commentDataBaseSet.all()) {
            if (getLikeNumberOfTweet(comment.getId())>5 || comment.getId()%2==0){
                comment.setCreatorUser(context.userDataBaseSet.get(comment.getCreatorUserId()));
                if (comment.getCreatorUser().getProfile().isActive()) {
                    randomTweetsOrPopularTweets.add(comment.getId());
                }
            }
        }*/
        MyLogger myLogger= new MyLogger(
                "src/explorerPage/controller/ExplorerPageController.java" ,
                "randomTweetsOrPopularTweets" ,
                clientId
        );
        return randomTweetsOrPopularTweets;
    }
























    private long getLikeNumberOfTweet (long tweetId , long clientId) {
        long likeNumberOfTweet= 0;
        for (User user: context.userDataBaseSet.all()) {
            if (context.userDataBaseSet.getLikedTweetsId(user).contains(tweetId)){likeNumberOfTweet= likeNumberOfTweet+1;}
        }
        MyLogger myLogger = new MyLogger(
                "src/explorerPage/controller/ExplorerPageController.java" ,
                "getLikeNumberOfTweet" ,
                clientId
        );
        return likeNumberOfTweet;
    }





























    public User getUserWithUsername (String username , long clientId){
        User user= null;
        for (User u: context.userDataBaseSet.all()) {
            if (u.getUsername().equals(username)){user= u; break;}
        }
        MyLogger myLogger = new MyLogger(
                "src/explorerPage/controller/ExplorerPageController.java" ,
                "getUserWithUsername" ,
                clientId
        );
        return user;
    }
























    public User getUserWithId (long id , long clientId){
        MyLogger myLogger = new MyLogger(
                "src/explorerPage/controller/ExplorerPageController.java" ,
                "getUserWithId" ,
                clientId
        );
        return context.userDataBaseSet.get(id);
    }






























    public String buttonMode (long userId  , long clientId){
        User user= getUserWithId(userId ,clientId);
        String buttonMode= "";
        boolean b1= context.userDataBaseSet.getFollowingsId(context.userDataBaseSet.get(clientId)).contains (userId);
        boolean b2= context.userDataBaseSet.getBlackListsId(context.userDataBaseSet.get(clientId)).contains (userId);
        boolean b3= context.userDataBaseSet.getBlackListsId (user).contains(clientId);
        boolean b4= context.userDataBaseSet.getFollowersId(context.userDataBaseSet.get(clientId)).contains (userId);


        if (b1 && !b2 && !b3){buttonMode= "buttonMode1";}
        if (!b1 && !b2){
            if (b4){buttonMode= "buttonMode2";}
            else {buttonMode= "buttonMode3";}
        }
        if (!b1 && b2){buttonMode= "buttonMode4";}
        MyLogger myLogger = new MyLogger(
                "src/explorerPage/controller/ExplorerPageController.java" ,
                "buttonMode" ,
                clientId
        );
        return buttonMode;
    }






















    public boolean showLastSeenDate (long userId  , long clientId){
        User user= getUserWithId(userId ,clientId);
        boolean show= false;
        if (context.userDataBaseSet.getFollowersId(user).contains(clientId)) {
            if (user.getProfile().getShowLastSeenDate().equals("everybody")) {
                show= true;
            }
            if (user.getProfile().getShowLastSeenDate().equals("nobody")) {
                show= false;
            }
            if (user.getProfile().getShowLastSeenDate().equals("followings")) {
                show= context.userDataBaseSet.getFollowingsId(user).contains(clientId);
            }
        }
        MyLogger myLogger = new MyLogger(
                "src/explorerPage/controller/ExplorerPageController.java" ,
                "showLastSeenDate" ,
                clientId
        );
        return show;
    }


















    public boolean showDateOfBirth (long userId  , long clientId){
        User user= getUserWithId(userId ,clientId);
        boolean show= false;
        if (user.getProfile().getShowDateOfBirth().equals("everybody")) {
            if (user.getProfile().getDateOfBirth()!=null) {
                show= true;
            }
        }
        if (user.getProfile().getShowDateOfBirth().equals("followings")) {
            if (context.userDataBaseSet.getFollowingsId(user).contains(clientId)) {
                if (user.getProfile().getDateOfBirth()!=null) {
                    show= true;
                }
            }
        }
        MyLogger myLogger = new MyLogger(
                "src/explorerPage/controller/ExplorerPageController.java" ,
                "showDateOfBirth" ,
                clientId
        );
        return show;
    }















    public boolean showEmail (long userId  , long clientId ){
        User user= getUserWithId(userId ,clientId);
        boolean show= false;
        if (user.getProfile().getShowEmail().equals("everybody")) {
            show= true;
        }
        if (user.getProfile().getShowEmail().equals("followings")) {
            if (context.userDataBaseSet.getFollowingsId(user).contains(clientId)) {
                show= true;
            }
        }
        MyLogger myLogger = new MyLogger(
                "src/explorerPage/controller/ExplorerPageController.java" ,
                "showEmail" ,
                clientId
        );
        return show;
    }






















    public boolean showPhoneNumber(long userId  , long clientId){
        User user= getUserWithId(userId ,clientId);
        boolean show= false;
        if (user.getProfile().getShowPhoneNumber().equals("everybody")) {
            show= true;
        }
        if (user.getProfile().getShowPhoneNumber().equals("followings")) {
            if (context.userDataBaseSet.getFollowingsId(user).contains(clientId)) {
                show= true;
            }
        }
        MyLogger myLogger = new MyLogger(
                "src/explorerPage/controller/ExplorerPageController.java" ,
                "showPhoneNumber" ,
                clientId
        );
        return show;
    }














    public BufferedImage getTweetImage(long tweetId , long clientId){
        try {
            String path = new File("").getAbsolutePath();
            String photoPath = path + "\\" + "resources\\Tweets Photos\\" + tweetId+".jpg";
            MyLogger myLogger = new MyLogger(
                    "src/explorerPage/controller/ExplorerPageController.java" ,
                    "getTweetImage" ,
                    clientId
            );
            return ImageIO.read(new File(photoPath));
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
























    public BufferedImage getProfileImage(long userId , long clientId){
        try {
            String path = new File("").getAbsolutePath();
            String photoPath = path + "\\" + "resources\\Users Photos\\" + userId+".jpg";
            MyLogger myLogger = new MyLogger(
                    "src/explorerPage/controller/ExplorerPageController.java" ,
                    "getProfileImage" ,
                    clientId
            );
            return ImageIO.read(new File(photoPath));
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}
