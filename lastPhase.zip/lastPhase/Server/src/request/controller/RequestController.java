package request.controller;

import authentication.model.User;
import controller.Controller;
import database.MyLogger;
import message.model.SystemMessage;
import request.model.Request;

import java.util.Collections;
import java.util.LinkedList;

public class RequestController extends Controller {


    private synchronized long createNewSystemMessageId ( long clientId ) {
        long n = 1;
        LinkedList<Long> idList=new LinkedList<>();
        for (SystemMessage systemMessage : context.systemMessageDataBaseSet.all()) { idList.add(systemMessage.getId()); }
        if (idList.size()>0){n= Collections.max(idList)+1;}
        MyLogger myLogger = new MyLogger(
                "src/request/controller/RequestController.java" ,
                "createNewSystemMessageId" ,
                clientId
        );
        return n;
    }



















    public void accept (long requestId , long clientId){
        Request request= getRequestWithId(requestId,clientId);
        if (!context.userDataBaseSet.getFollowersId (request.getRequested()).contains(request.getRequester().getId())) {
            context.userDataBaseSet.addFollowing (request.getRequester(), request.getRequested().getId());
            context.userDataBaseSet.addFollower (request.getRequested(), request.getRequester().getId());
            SystemMessage systemMessage = new SystemMessage (request.getRequesterId(), "Your request has been accepted by " + request.getRequested().getUsername());
            systemMessage.setId(createNewSystemMessageId(clientId));
            context.systemMessageDataBaseSet.add(systemMessage);
            context.requestDataBaseSet.remove(request);
            MyLogger myLogger = new MyLogger(
                    "src/request/controller/RequestController.java",
                    "accept",
                    clientId
            );
        }
    }


















    private Request getRequestWithId ( long requestId , long clientId ){
        Request request= context.requestDataBaseSet.get(requestId);
        request.setRequester( context.userDataBaseSet.get(request.getRequesterId()) );
        request.setRequested( context.userDataBaseSet.get(request.getRequestedId()) );
        MyLogger myLogger = new MyLogger(
                "src/request/controller/RequestController.java" ,
                "getRequestWithId" ,
                clientId
        );
        return request;
    }






























    public Request getNextRequest( long clientId){
        Request request= null;
        if (getMyRequests(clientId).size()>0){
            request= getMyRequests(clientId).get(0);
        }
        MyLogger myLogger = new MyLogger(
                "src/request/controller/RequestController.java" ,
                "getNextRequest" ,
                clientId
        );
        return request;
    }





























    private LinkedList<Request>  getMyRequests( long clientId){
        LinkedList<Request> myRequests= new LinkedList<>();
        for (Request request: context.requestDataBaseSet.all()) {
            if (request.getRequestedId()== clientId){
                request.setRequester(context.userDataBaseSet.get(request.getRequesterId()));
                request.setRequested(context.userDataBaseSet.get(request.getRequestedId()));
                myRequests.add(request);
            }
        }
        MyLogger myLogger = new MyLogger(
                "src/request/controller/RequestController.java" ,
                "getMyRequests" ,
                clientId
        );
        return myRequests;
    }





























    public void rejectAndLetHerHimKnow( long requestId , long clientId){
        Request request= getRequestWithId(requestId,clientId);
        SystemMessage systemMessage= new SystemMessage(request.getRequesterId(),"Your request was not accepted by "+request.getRequested().getUsername());
        systemMessage.setId(createNewSystemMessageId(clientId));
        context.systemMessageDataBaseSet.add(systemMessage);
        context.requestDataBaseSet.remove(request);
        MyLogger myLogger= new MyLogger(
                "src/request/controller/RequestController.java",
                "rejectAndLetHerHimKnow",
                clientId
        );
    }




















    public void rejectWithoutNotifying(long requestId , long clientId){
        Request request= getRequestWithId(requestId , clientId);
        context.requestDataBaseSet.remove(request);
        MyLogger myLogger= new MyLogger(
                "src/request/controller/RequestController.java",
                "rejectWithoutNotifying",
                clientId
        );
    }
}
