package homepage.controller;

import authentication.model.User;
import controller.Controller;
import database.MyLogger;
import tweet.model.Tweet;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Collections;
import java.util.LinkedList;

public class HomePageController extends Controller {


    public BufferedImage getTweetImage(long tweetId , long clientId){
        try {
            String path = new File("").getAbsolutePath();
            String photoPath = path + "\\" + "resources\\Tweets Photos\\" + tweetId+".jpg";
            MyLogger myLogger = new MyLogger(
                    "src/homepage/controller/HomePageController.java" ,
                    "getTweetImage" ,
                    clientId
            );
            return ImageIO.read(new File(photoPath));
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }


















    public BufferedImage getProfileImage(long userId , long clientId){
        try {
            String path = new File("").getAbsolutePath();
            String photoPath = path + "\\" + "resources\\Users Photos\\" + userId+".jpg";
            MyLogger myLogger = new MyLogger(
                    "src/homepage/controller/HomePageController.java" ,
                    "getProfileImage" ,
                    clientId
            );
            return ImageIO.read(new File(photoPath));
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

































    public Tweet firstDisplayableTweet( long clientId){
        Tweet tweet= null;
        if (displayableTweetsId(clientId).size()>0) {
            long firstDisplayableTweetId = Collections.max(displayableTweetsId(clientId));
            tweet = context.tweetDataBaseSet.get(firstDisplayableTweetId);
            tweet.setCreatorUser(context.userDataBaseSet.get(tweet.getCreatorUserId()));
        }
        MyLogger myLogger = new MyLogger(
                "src/homepage/controller/HomePageController.java" ,
                "firstDisplayableTweet" ,
                clientId
        );
        return tweet;
    }


























    private LinkedList<Long> displayableTweetsId(  long clientId){
        LinkedList<Long> displayableTweetsId= new LinkedList<>();
        LinkedList<User> myUsers= new LinkedList<>();
        for (long userId: context.userDataBaseSet.getFollowingsId(context.userDataBaseSet.get(clientId))) {
            if (!context.userDataBaseSet.getMutedUsersId(context.userDataBaseSet.get(clientId)).contains(userId)){
                myUsers.add(context.userDataBaseSet.get(userId));
            }
        }
        /*for (User user: myUsers){
            displayableTweetsId.addAll(getUserTweetsId(user));
            displayableTweetsId.addAll(context.userDataBaseSet.getLikedTweetsId(user));
            displayableTweetsId.addAll(context.userDataBaseSet.getRetweetedTweetsId(user));
        }*/
        for (User user: myUsers){
            for (long id: getUserTweetsId(user,clientId)) {
                Tweet tweet= context.tweetDataBaseSet.get(id);
                if (tweet!=null) {
                    if (tweet.getReportNumber() < 5) {
                        displayableTweetsId.add(id);
                    }
                }
            }
            for (long id: context.userDataBaseSet.getLikedTweetsId(user)) {
                Tweet tweet= context.tweetDataBaseSet.get(id);
                if (tweet!=null) {
                    if (tweet.getReportNumber() < 5) {
                        displayableTweetsId.add(id);
                    }
                }
            }
            for (long id: context.userDataBaseSet.getRetweetedTweetsId(user)) {
                Tweet tweet= context.tweetDataBaseSet.get(id);
                if (tweet!=null) {
                    if (tweet.getReportNumber() < 5) {
                        displayableTweetsId.add(id);
                    }
                }
            }
        }
        MyLogger myLogger = new MyLogger(
                "src/homepage/controller/HomePageController.java" ,
                "displayableTweetsId" ,
                clientId
        );
        return displayableTweetsId;
    }














    public LinkedList<Long> getUserTweetsId (User user , long clientId){
        LinkedList<Long> userTweetsId= new LinkedList<>();
        for (Tweet tweet: context.tweetDataBaseSet.all()) {
            if (tweet.getCreatorUserId()== user.getId()){
                tweet.setCreatorUser(user);
                userTweetsId.add(tweet.getId());
            }
        }
        /*for (Comment comment: context.commentDataBaseSet.all()) {
            if (comment.getCreatorUserId()== user.getId()){
                comment.setCreatorUser(user);
                userTweetsId.add(comment.getId());
            }
        }*/
        MyLogger myLogger = new MyLogger(
                "src/homepage/controller/HomePageController.java" ,
                "getUserTweetsId" ,
                clientId
        );
        return userTweetsId;
    }














}
