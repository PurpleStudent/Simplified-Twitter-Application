package forwardTweetToSeveralPeople.controller;

import authentication.model.User;
import category.model.Category;
import controller.Controller;
import database.MyLogger;
import message.model.Chat;
import message.model.Message;
import tweet.model.Tweet;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Collections;
import java.util.LinkedList;

public class ForwardTweetController extends Controller {







    private Tweet getTweetWithId(long tweetId , long clientId){
        Tweet tweet= context.tweetDataBaseSet.get(tweetId);
        User user= context.userDataBaseSet.get(tweet.getCreatorUserId());
        tweet.setCreatorUser(user);
        MyLogger myLogger = new MyLogger(
                "src/forwardTweetToSeveralPeople/controller/ForwardTweetController.java" ,
                "getTweetWithId" ,
                clientId
        );
        return tweet;
    }
























    public void sendToAllUsers(long tweetId   , long clientId) {
        Tweet tweet= getTweetWithId(tweetId,clientId);
        context.userDataBaseSet.getFollowingsId(context.userDataBaseSet.get(clientId));

        for (long userId: context.userDataBaseSet.getFollowingsId(context.userDataBaseSet.get(clientId))) {
            User user= context.userDataBaseSet.get(userId);
            if (user.getProfile().isActive()) {
                Message message = new Message(clientId, tweet.getText() , user.getId());
                message.setId(createNewMessageId(clientId));
                context.messageDataBaseSet.add(message);
                putMessageInChat(message,clientId);
                MyLogger myLogger= new MyLogger(
                        "src/forwardTweetToSeveralPeople/controller/ForwardTweetController.java" ,
                        "sendToAllUsers",
                        clientId
                );
            }
        }
    }


















    private synchronized long createNewMessageId (long clientId) {
        long n = 1;
        LinkedList<Long> idList=new LinkedList<>();
        for (Message message : context.messageDataBaseSet.all()) { idList.add(message.getId()); }
        if (idList.size()>0){n= Collections.max(idList)+1;}
        MyLogger myLogger = new MyLogger(
                "src/forwardTweetToSeveralPeople/controller/ForwardTweetController.java" ,
                "createNewMessageId" ,
                clientId
        );
        return n;
    }























    public BufferedImage getTweetImage(long tweetId , long clientId){
        try {
            String path = new File("").getAbsolutePath();
            String photoPath = path + "\\" + "resources\\Tweets Photos\\" + tweetId+".jpg";
            MyLogger myLogger = new MyLogger(
                    "src/forwardTweetToSeveralPeople/controller/ForwardTweetController.java",
                    "getTweetImage" ,
                    clientId
            );
            return ImageIO.read(new File(photoPath));
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }























    public BufferedImage getProfileImage(long userId , long clientId){
        try {
            String path = new File("").getAbsolutePath();
            String photoPath = path + "\\" + "resources\\Users Photos\\" + userId+".jpg";
            MyLogger myLogger = new MyLogger(
                    "src/forwardTweetToSeveralPeople/controller/ForwardTweetController.java" ,
                    "getProfileImage" ,
                    clientId
            );
            return ImageIO.read(new File(photoPath));
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }






















    public void forwardToSelectedCategories (int number, String names, String tweetText  , long clientId){
        LinkedList <String> categoryNames= new LinkedList<>();
        for (int i = 0; i < number; i++) {
            if (i==number-1){
                categoryNames.add(names);
            }
            else {
                String username = names.substring(0, names.indexOf('-'));
                categoryNames.add(username);
                names = names.substring(names.indexOf('-') + 1);
            }
        }
        for (int i = 0; i < number; i++) {
            Category category= getMyCategoryWithName(categoryNames.get(i),clientId);
            if (category!=null) {
                for (long userId : context.categoryDataBaseSet.getMembers(category)) {
                    User user= context.userDataBaseSet.get(userId);
                    if (user.getProfile().isActive()) {
                        Message message = new Message(clientId , tweetText, user.getId());
                        message.setId(createNewMessageId(clientId));
                        context.messageDataBaseSet.add(message);
                        putMessageInChat(message,clientId);
                        MyLogger myLogger= new MyLogger(
                                "src/forwardTweetToSeveralPeople/controller/ForwardTweetController.java" ,
                                "forwardToSelectedCategories",
                                clientId
                        );
                    }
                }
            }
        }
    }











    private Category getMyCategoryWithName(String name  , long clientId){
        Category myCategory=null;
        for (Category category: context.categoryDataBaseSet.all()) {
            if (category.getUserId()==clientId) {
                if (category.getCategoryName().equals(name)) {
                    myCategory = category;
                }
            }
        }
        MyLogger myLogger = new MyLogger(
                "src/forwardTweetToSeveralPeople/controller/ForwardTweetController.java" ,
                "getMyCategoryWithName" ,
                clientId
        );
        return myCategory;
    }





















    public void forwardToManuallySelectedPeople(int number, String usernames, String tweetText  , long clientId){
        LinkedList<String> myUsernames= new LinkedList<>();
        for (int i = 0; i < number; i++) {
            if (i==number-1){
                myUsernames.add(usernames);
            }
            else {
                String username = usernames.substring(0, usernames.indexOf('-'));
                myUsernames.add(username);
                usernames = usernames.substring(usernames.indexOf('-') + 1);
            }
        }
        for (int i = 0; i < number; i++) {
            if (context.userDataBaseSet.getFollowingsId(context.userDataBaseSet.get(clientId)).contains(getUserWithUsername(myUsernames.get(i) ,clientId).getId())){
                if (getUserWithUsername(myUsernames.get(i) ,clientId).getProfile().isActive()) {

                    Message message = new Message(
                            context.userDataBaseSet.get(clientId).getId(),
                            tweetText,
                            getUserWithUsername(myUsernames.get(i) ,clientId).getId()
                    );
                    message.setId(createNewMessageId(clientId));
                    context.messageDataBaseSet.add(message);
                    putMessageInChat(message ,clientId);
                    MyLogger myLogger= new MyLogger(
                            "src/forwardTweetToSeveralPeople/controller/ForwardTweetController.java" ,
                            "forwardToManuallySelectedPeople",
                            clientId
                    );
                }
            }
            else {System.out.println("Message not sent.");}
        }
    }














    private void putMessageInChat (Message message , long clientId){
        for (Chat chat: getUserChats(message.getCreatorUserId() ,clientId)) {
            if (chat.getUser1Id()==message.getRecipientUserId() || chat.getUser2Id()==message.getRecipientUserId()){
                if (chat.getUser1Id()==message.getRecipientUserId()){
                    context.chatDataBaseSet.addUser1UnreadMessages(chat,message.getId());
                    context.chatDataBaseSet.addChatGroupAllMessages(chat,message.getId());
                }
                if (chat.getUser2Id()==message.getRecipientUserId()){
                    context.chatDataBaseSet.addUser2UnreadMessages(chat,message.getId());
                    context.chatDataBaseSet.addChatGroupAllMessages(chat,message.getId());
                }
            }
        }
        MyLogger myLogger = new MyLogger(
                "src/forwardTweetToSeveralPeople/controller/ForwardTweetController.java" ,
                "putMessageInChat" ,
                clientId
        );
    }

















    private LinkedList<Chat> getUserChats(long userId , long clientId){
        LinkedList<Chat> chats= new LinkedList<>();
        for (Chat chat: context.chatDataBaseSet.all()) {
            if (chat.getUser1Id()==userId || chat.getUser2Id()==userId){
                chat.setUser1(context.userDataBaseSet.get(chat.getUser1Id()));
                chat.setUser2(context.userDataBaseSet.get(chat.getUser2Id()));
                chats.add(chat);
            }
        }
        MyLogger myLogger = new MyLogger(
                "src/forwardTweetToSeveralPeople/controller/ForwardTweetController.java" ,
                "getUserChats" ,
                clientId
        );
        return chats;
    }






















    private User getUserWithUsername(String username , long clientId){
        User user= null;
        for (User u: context.userDataBaseSet.all()) {
            if (u.getUsername().equals(username)){user= u; break;}
        }
        MyLogger myLogger = new MyLogger(
                "src/forwardTweetToSeveralPeople/controller/ForwardTweetController.java" ,
                "getUserWithUsername" ,
                clientId
        );
        return user;
    }















}
