package group.controller;

import authentication.model.User;
import controller.Controller;
import database.MyLogger;
import group.model.Group;
import message.model.Message;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.Collections;
import java.util.LinkedList;

public class GroupController extends Controller {





    public void leaveGroup(long groupId  , long clientId){
        Group group= getGroup(groupId ,clientId);
        context.groupDataBaseSet.removeMember(group , clientId);
        MyLogger myLogger = new MyLogger(
                "src/group/controller/GroupController.java" ,
                "leaveGroup" ,
                clientId
        );
    }





















    public BufferedImage getMessageImage(long messageId , long clientId){
        try {
            String path = new File("").getAbsolutePath();
            String photoPath = path + "\\" + "resources\\Messages Photos\\" + messageId+".jpg";
            return ImageIO.read(new File(photoPath));
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        MyLogger myLogger = new MyLogger(
                "src/group/controller/GroupController.java" ,
                "getMessageImage" ,
                clientId
        );
        return null;
    }





















    public BufferedImage getProfileImage (long userId , long clientId){
        try {
            String path = new File("").getAbsolutePath();
            String photoPath = path + "\\" + "resources\\Users Photos\\" + userId+".jpg";
            MyLogger myLogger = new MyLogger(
                    "src/group/controller/GroupController.java" ,
                    "getProfileImage" ,
                    clientId
            );
            return ImageIO.read(new File(photoPath));
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }






















    private synchronized long createNewGroupId ( long clientId ) {
        long n = 1;
        LinkedList<Long> idList=new LinkedList<>();
        for (Group group : context.groupDataBaseSet.all()) { idList.add(group.getId()); }
        if (idList.size()>0){n= Collections.max(idList)+1;}
        MyLogger myLogger = new MyLogger(
                "src/group/controller/GroupController.java" ,
                "createNewGroupId" ,
                clientId
        );
        return n;
    }



























    public void createNewGroup(String groupName  , long clientId){
        Group group= new Group(groupName);
        group.setId(createNewGroupId(clientId));
        context.groupDataBaseSet.add(group);
        context.groupDataBaseSet.addMember(group, clientId);
        MyLogger myLogger= new MyLogger(
                "src/group/controller/GroupController.java",
                "createNewGroup",
                clientId
        );
    }





















    public void addMember(String username, long groupId  , long clientId){
        long userId=0;
        for (User user: context.userDataBaseSet.all()) {
            if (user.getUsername().equals(username)){userId= user.getId(); break;}
        }
        if (context.userDataBaseSet.getFollowingsId(context.userDataBaseSet.get(clientId)).contains(userId)) {
            if (!context.groupDataBaseSet.getMembers(context.groupDataBaseSet.get(groupId)).contains(userId)) {
                context.groupDataBaseSet.addMember(context.groupDataBaseSet.get(groupId), userId);
                MyLogger myLogger= new MyLogger(
                        "src/group/controller/GroupController.java",
                        "addMember",
                        clientId
                );
            }
        }
    }























    public void addMessage (String text , long groupId , BufferedImage image  , long clientId){
        try {
            Message message= new Message (clientId , text , 0);
            message.setId(createNewMessageId(clientId));
            message.setCreatorUser(context.userDataBaseSet.get(clientId));
            context.messageDataBaseSet.add(message);
            context.groupDataBaseSet.addChatGroupAllMessages(context.groupDataBaseSet.get ( groupId ) , message.getId());
            if ( image != null ) {
                String path = new File("").getAbsolutePath();
                String photoPath = path + "\\" + "resources\\Messages Photos\\" + message.getId() + ".jpg";
                File photoFile = new File(photoPath);
                photoFile.getParentFile().mkdirs();
                if (!photoFile.exists()) {
                    photoFile.createNewFile();
                }
                ImageIO.write(image, "jpg", photoFile);
            }
            MyLogger myLogger = new MyLogger(
                    "src/group/controller/GroupController.java",
                    "addMessage",
                    clientId
            );
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }





















    private synchronized long createNewMessageId ( long clientId ) {
        long n = 1;
        LinkedList<Long> idList=new LinkedList<>();
        for (Message message : context.messageDataBaseSet.all()) { idList.add(message.getId()); }
        if (idList.size()>0){n= Collections.max(idList)+1;}
        MyLogger myLogger = new MyLogger(
                "src/group/controller/GroupController.java" ,
                "createNewMessageId" ,
                clientId
        );
        return n;
    }
































    public Group getGroup (long groupId , long clientId){
        MyLogger myLogger = new MyLogger(
                "src/group/controller/GroupController.java" ,
                "getGroup" ,
                clientId
        );
        return context.groupDataBaseSet.get(groupId);
    }
































    public Group getPreviousGroup ( long currentGroupId  , long clientId ){
        LinkedList<Long> myGroupsId= new LinkedList<>();
        for (Group group: context.groupDataBaseSet.all()) {
            if (context.groupDataBaseSet.getMembers(group).contains(clientId)){myGroupsId.add(group.getId());}
        }
        LinkedList<Long> previousGroupsId= new LinkedList<>();
        for (long groupId : myGroupsId) {
            if (groupId<currentGroupId){
                previousGroupsId.add(groupId);
            }
        }
        Group group;
        if (previousGroupsId.size()==0){
            group= context.groupDataBaseSet.get(currentGroupId);
        }
        else {
            long previousGroupId= Collections.max(previousGroupsId);
            group= context.groupDataBaseSet.get(previousGroupId);
        }
        MyLogger myLogger = new MyLogger(
                "src/group/controller/GroupController.java" ,
                "getPreviousGroup" ,
                clientId
        );
        return group;
    }











    public Group getNextGroup(long currentGroupId  , long clientId){
        LinkedList<Long> myGroupsId= new LinkedList<>();
        for (Group group: context.groupDataBaseSet.all()) {
            if (context.groupDataBaseSet.getMembers(group).contains(clientId)){myGroupsId.add(group.getId());}
        }
        LinkedList<Long> nextGroupsId= new LinkedList<>();
        for (long groupId: myGroupsId) {
            if (groupId>currentGroupId){
                nextGroupsId.add(groupId);
            }
        }
        Group group;
        if (nextGroupsId.size()==0){
            group= context.groupDataBaseSet.get(currentGroupId);
        }
        else {
            long nextGroupId= Collections.min(nextGroupsId);
            group= context.groupDataBaseSet.get(nextGroupId);
        }
        MyLogger myLogger = new MyLogger(
                "src/group/controller/GroupController.java" ,
                "getNextGroup" ,
                clientId
        );
        return group;
    }














    public Message getPreviousGroupMessage (long currentMessageId, long groupId , long clientId){
        LinkedList<Long> previousGroupMessagesId= new LinkedList<>();

        for (long messageId : context.groupDataBaseSet.getChatGroupAllMessages(context.groupDataBaseSet.get(groupId))) {
            if (messageId<currentMessageId){
                previousGroupMessagesId.add(messageId);
            }
        }
        Message message;
        if (previousGroupMessagesId.size()==0){
            message= context.messageDataBaseSet.get(currentMessageId);
        }
        else {
            long previousMessageId= Collections.max(previousGroupMessagesId);
            message= context.messageDataBaseSet.get(previousMessageId);
        }
        message.setCreatorUser(context.userDataBaseSet.get(message.getCreatorUserId()));
        MyLogger myLogger = new MyLogger(
                "src/group/controller/GroupController.java" ,
                "getPreviousGroupMessage" ,
                clientId
        );
        return message;
    }

















    public Message getNextGroupMessage(long currentMessageId, long groupId , long clientId){
        LinkedList<Long> nextGroupMessagesId= new LinkedList<>();

        for (long messageId: context.groupDataBaseSet.getChatGroupAllMessages(context.groupDataBaseSet.get(groupId))) {
            if (messageId>currentMessageId){
                nextGroupMessagesId.add(messageId);
            }
        }
        Message message;
        if (nextGroupMessagesId.size()==0){
            message= context.messageDataBaseSet.get(currentMessageId);
        }
        else {
            long nextMessageId= Collections.min(nextGroupMessagesId);
            message= context.messageDataBaseSet.get(nextMessageId);
        }
        message.setCreatorUser(context.userDataBaseSet.get(message.getCreatorUserId()));
        MyLogger myLogger =new MyLogger(
                "src/group/controller/GroupController.java" ,
                "getNextGroupMessage" ,
                clientId
        );
        return message;
    }























    public Message getLastMessageOfGroup(long groupId , long clientId){
        long lastMessageId = -1;
        if (context.groupDataBaseSet.getChatGroupAllMessages (context.groupDataBaseSet.get(groupId)) .size() >0 ) {
            lastMessageId = Collections.max(context.groupDataBaseSet.getChatGroupAllMessages(context.groupDataBaseSet.get(groupId)));
        }
        Message message= context.messageDataBaseSet.get(lastMessageId);
        if ( message != null ) {
            message.setCreatorUser(context.userDataBaseSet.get(message.getCreatorUserId()));
        }
        System.out.println( message == null);
        MyLogger myLogger = new MyLogger(
                "src/group/controller/GroupController.java" ,
                "getLastMessageOfGroup" ,
                clientId
        );
        return message;
    }






















    /*private void copy(String photoAddress, long messageId){
        try {
            String path = new File("").getAbsolutePath();
            String photoPath = path + "\\" + "resources\\Messages Photos\\" + messageId+".jpg";
            File photoFile= new File(photoPath);
            photoFile.getParentFile().mkdirs();
            if (!photoFile.exists()) {
                photoFile.createNewFile();
            }

            File file = new File(photoAddress);
            file.getParentFile().mkdirs();
            if (!file.exists()) {
                file.createNewFile();
            }

            copyFileUsingStream(file,photoFile);
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }*/

    /*private static void copyFileUsingStream(File source, File dest) {
        InputStream is = null;
        OutputStream os = null;
        try {
            is = new FileInputStream(source);
            os = new FileOutputStream(dest);
            byte[] buffer = new byte[1024];
            int length;
            while ((length = is.read(buffer)) > 0) {
                os.write(buffer, 0, length);
            }
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        finally {
            try {
                is.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                os.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }*/









}
