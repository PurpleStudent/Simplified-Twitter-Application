package messagingPage.controller;

import authentication.model.User;
import controller.Controller;
import database.MyLogger;
import group.model.Group;
import message.model.Chat;
import message.model.Message;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.Collections;
import java.util.LinkedList;

public class MessagingPageController extends Controller {


    public BufferedImage getMessageImage(long messageId , long clientId){
        try {
            String path = new File("").getAbsolutePath();
            String photoPath = path + "\\" + "resources\\Messages Photos\\" + messageId+".jpg";
            MyLogger myLogger = new MyLogger(
                    "src/messagingPage/controller/MessagingPageController.java" ,
                    "getMessageImage" ,
                    clientId
            );
            return ImageIO.read(new File(photoPath));
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }





















































    public int getNumberOfUnreadMessages ( long chatId  , long clientId) {
        Chat chat= getChatWithId(chatId,clientId);
        int n=0;
        if (chat!=null) {
            if (chat.getUser1Id() == clientId) {
                n = context.chatDataBaseSet.getUser1UnreadMessages(chat).size();
            }
            if (chat.getUser2Id() == clientId) {
                n = context.chatDataBaseSet.getUser2UnreadMessages(chat).size();
            }
        }
        MyLogger myLogger = new MyLogger(
                "src/messagingPage/controller/MessagingPageController.java" ,
                "getNumberOfUnreadMessages" ,
                clientId
        );
        return n;
    }




















    public User getAnotherUser(long chatId  , long clientId){
        Chat chat= getChatWithId(chatId,clientId);
        User user= null;
        if ( chat!=null ){
            if (chat.getUser1Id() == clientId) {
                user = context.userDataBaseSet.get( chat.getUser2Id() );
            }
            if (chat.getUser2Id() == clientId) {
                user = context.userDataBaseSet.get( chat.getUser1Id() );
            }
        }
        MyLogger myLogger = new MyLogger(
                "src/messagingPage/controller/MessagingPageController.java" ,
                "getAnotherUser" ,
                clientId
        );
        return user;
    }



























    private Chat getChatWithId(long chatId , long clientId){
        Chat chat= context.chatDataBaseSet.get(chatId);
        if (chat != null) {
            chat.setUser1(context.userDataBaseSet.get(chat.getUser1Id()));
            chat.setUser2(context.userDataBaseSet.get(chat.getUser2Id()));
        }
        MyLogger myLogger = new MyLogger(
                "src/messagingPage/controller/MessagingPageController.java" ,
                "getChatWithId" ,
                clientId
        );
        return chat;
    }





























    public Chat getFirstChat( long clientId){
        Chat myChat= null;
        LinkedList<Long> unreadChats= new LinkedList<>();
        LinkedList<Long> readChats= new LinkedList<>();

        for (Chat chat: getUserChats(clientId,clientId)) {
            if (chat.getUser1Id()==clientId){
                if (context.chatDataBaseSet.getUser1UnreadMessages(chat).size()!=0){
                    unreadChats.add(chat.getId());
                }
            }
            if (chat.getUser2Id()==clientId){
                if (context.chatDataBaseSet.getUser2UnreadMessages(chat).size()!=0){
                    unreadChats.add(chat.getId());
                }
            }
        }
        if (unreadChats.size()>0){
            long chatId= Collections.max(unreadChats);
            myChat= context.chatDataBaseSet.get(chatId);
        }

        else {

            for (Chat chat : getUserChats(clientId,clientId)) {
                if (chat.getUser1Id()==clientId) {
                    if (context.chatDataBaseSet.getUser1UnreadMessages(chat).size() == 0) {
                        readChats.add(chat.getId());
                    }
                }
                if (chat.getUser2Id()==clientId) {
                    if (context.chatDataBaseSet.getUser2UnreadMessages(chat).size() == 0) {
                        readChats.add(chat.getId());
                    }
                }
            }

            if (readChats.size()>0){
                long chatId= Collections.max(readChats);
                myChat= context.chatDataBaseSet.get(chatId);
            }
        }
        MyLogger myLogger = new MyLogger(
                "src/messagingPage/controller/MessagingPageController.java" ,
                "getFirstChat" ,
                clientId
        );
        return myChat;
    }




















    private LinkedList<Chat> getUserChats(long userId , long clientId){
        LinkedList<Chat> chats= new LinkedList<>();
        for (Chat chat: context.chatDataBaseSet.all()) {
            if (chat.getUser1Id()==userId || chat.getUser2Id()==userId){
                chat.setUser1(context.userDataBaseSet.get(chat.getUser1Id()));
                chat.setUser2(context.userDataBaseSet.get(chat.getUser2Id()));
                chats.add(chat);
            }
        }
        MyLogger myLogger = new MyLogger(
                "src/messagingPage/controller/MessagingPageController.java" ,
                "getUserChats" ,
                clientId
        );
        return chats;
    }






























    public Group myFirstGroup( long clientId){
        Group myGroup= null;
        LinkedList<Long> myGroupsId= new LinkedList<>();
        for (Group group: context.groupDataBaseSet.all()) {
            if (context.groupDataBaseSet.getMembers(group).contains(clientId)){myGroupsId.add(group.getId());}
        }
        if (myGroupsId.size()>0){
            myGroup= context.groupDataBaseSet.get(Collections.min(myGroupsId));
        }
        MyLogger myLogger = new MyLogger(
                "src/messagingPage/controller/MessagingPageController.java" ,
                "myFirstGroup" ,
                clientId
        );
        return myGroup;
    }






























    private synchronized long createNewId (long clientId) {
        long n = 1;
        LinkedList<Long> idList=new LinkedList<>();
        for (Message message : context.messageDataBaseSet.all()) { idList.add(message.getId()); }
        if (idList.size()>0){n= Collections.max(idList)+1;}
        MyLogger myLogger = new MyLogger(
                "src/messagingPage/controller/MessagingPageController.java" ,
                "createNewId" ,
                clientId
        );
        return n;
    }




























    public void createNewSavedMessage ( String text , BufferedImage image , long clientId){
        try {
            Message message = new Message( clientId , text, clientId);
            message.setId(createNewId(clientId));
            message.setCreatorUser(context.userDataBaseSet.get(clientId));
            message.setRecipientUser(context.userDataBaseSet.get(clientId));
            context.messageDataBaseSet.add(message);
            context.userDataBaseSet.addSavedMessage(context.userDataBaseSet.get(clientId), message.getId());
            MyLogger myLogger= new MyLogger(
                "src/messagingPage/controller/MessagingPageController.java",
                "createNewSavedMessage",
                clientId
            );

            if ( image != null ) {
                String path = new File("").getAbsolutePath();
                String photoPath = path + "\\" + "resources\\Messages Photos\\" + message.getId() + ".jpg";
                File photoFile = new File(photoPath);
                photoFile.getParentFile().mkdirs();
                if (!photoFile.exists()) {
                    photoFile.createNewFile();
                }
                ImageIO.write(image, "jpg", photoFile);
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
























    public LinkedList<Message> getMySavedMessages( long clientId){
        LinkedList<Message> mySavedMessages= new LinkedList<>();
        for (Long messageId: context.userDataBaseSet.getSavedMessages (context.userDataBaseSet.get(clientId)) ) {
            Message message= context.messageDataBaseSet.get(messageId);
            message.setCreatorUser(context.userDataBaseSet.get(message.getCreatorUserId()));
            message.setRecipientUser( context.userDataBaseSet.get ( message.getRecipientUserId() ) );
            mySavedMessages.add(message);
        }
        MyLogger myLogger = new MyLogger(
                "src/messagingPage/controller/MessagingPageController.java" ,
                "getMySavedMessages" ,
                clientId
        );
        return mySavedMessages;
    }



























    public Message getFirstSavedMessages ( long clientId) {
        Message myMessage= null;
        LinkedList<Long> myMessagesId= new LinkedList<>();
        for (Message message: getMySavedMessages(clientId)) {
            myMessagesId.add(message.getId());
        }
        if (myMessagesId.size()>0){
            myMessage= context.messageDataBaseSet.get(Collections.max(myMessagesId));
            myMessage.setCreatorUser( context.userDataBaseSet.get( myMessage.getCreatorUserId() ));
            myMessage.setRecipientUser( context.userDataBaseSet.get( myMessage.getRecipientUserId() ));
        }
        MyLogger myLogger = new MyLogger(
                "src/messagingPage/controller/MessagingPageController.java" ,
                "getFirstSavedMessages" ,
                clientId
        );
        return myMessage;
    }


















    public Message getPreviousSavedMessage (long currentMessageId  , long clientId) {
        LinkedList<Long> previousSavedMessagesId= new LinkedList<>();
        for (Message message : getMySavedMessages(clientId)) {
            if (message.getId()<currentMessageId){
                previousSavedMessagesId.add(message.getId());
            }
        }
        Message message;
        if (previousSavedMessagesId.size()==0){
            message= context.messageDataBaseSet.get(currentMessageId);
        }
        else {
            long previousMessageId= Collections.max(previousSavedMessagesId);
            message= context.messageDataBaseSet.get(previousMessageId);
        }
        message.setCreatorUser(context.userDataBaseSet.get(message.getCreatorUserId()));
        message.setRecipientUser(context.userDataBaseSet.get(message.getRecipientUserId()));
        MyLogger myLogger = new MyLogger(
                "src/messagingPage/controller/MessagingPageController.java" ,
                "getPreviousSavedMessage" ,
                clientId
        );
        return message;
    }















    public Message getNextSavedMessage( long currentMessageId   , long clientId ){
        LinkedList<Long> nextSavedMessagesId= new LinkedList<>();

        for (Message message: getMySavedMessages(clientId)) {
            if (message.getId()>currentMessageId){
                nextSavedMessagesId.add(message.getId());
            }
        }
        Message message;
        if (nextSavedMessagesId.size()==0){
            message= context.messageDataBaseSet.get(currentMessageId);
        }
        else {
            long nextMessageId= Collections.min(nextSavedMessagesId);
            message= context.messageDataBaseSet.get(nextMessageId);
        }
        message.setCreatorUser(context.userDataBaseSet.get(message.getCreatorUserId()));
        message.setRecipientUser(context.userDataBaseSet.get(message.getRecipientUserId()));
        MyLogger myLogger = new MyLogger(
                "src/messagingPage/controller/MessagingPageController.java" ,
                "getNextSavedMessage" ,
                clientId
        );
        return message;
    }









}
