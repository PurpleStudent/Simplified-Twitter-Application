package forwardTweetToSeveralPeople.view;

import forwardTweetToSeveralPeople.event.SelectCategoriesEvent;
import forwardTweetToSeveralPeople.listener.SelectCategoriesListener;
import models.Tweet;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SelectCategoriesView extends JPanel implements ActionListener {


    private final JTextField numberOfCategories= new JTextField(70);
    private final JTextField names= new JTextField(70);

    private final JButton forward= new JButton("forward");

    SelectCategoriesListener listener;

    private final Tweet tweet;
    private final boolean fromExplorer;












    public SelectCategoriesView(Tweet tweet, boolean fromExplorer){
        this.tweet = tweet;
        this.fromExplorer= fromExplorer;
        this.setBackground(new Color(70, 160, 241));
        Border innerBorder= BorderFactory.createTitledBorder("Select The Categories");
        Border outerBorder= BorderFactory.createEmptyBorder(20,20,300,20);
        this.setBorder(BorderFactory.createCompoundBorder(outerBorder,innerBorder));
        this.setLayout(new GridBagLayout());
        GridBagConstraints gridBagConstraints= new GridBagConstraints();
        gridBagConstraints.weightx= 1;
        gridBagConstraints.weighty= 1;

        //text
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.insets = new Insets(0, 0, 0, 7);
        gridBagConstraints.anchor = GridBagConstraints.LINE_END;
        this.add(new JLabel("number of Categories : "), gridBagConstraints);
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.insets = new Insets(0, 0, 0, 7);
        gridBagConstraints.anchor = GridBagConstraints.LINE_START;
        this.add(numberOfCategories, gridBagConstraints);

        //photoAddress
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.insets = new Insets(0, 0, 0, 7);
        gridBagConstraints.anchor = GridBagConstraints.LINE_END;
        this.add(new JLabel("names : "), gridBagConstraints);
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.insets = new Insets(0, 0, 0, 0);
        gridBagConstraints.anchor = GridBagConstraints.LINE_START;
        this.add(names, gridBagConstraints);

        //createNewTweetButton
        gridBagConstraints.weightx = 1;
        gridBagConstraints.weighty = 2;
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 5;
        gridBagConstraints.insets = new Insets(0, 0, 0, 0);
        gridBagConstraints.anchor = GridBagConstraints.FIRST_LINE_START;
        this.add(forward, gridBagConstraints);
        forward.addActionListener(this);
    }


    public String getNumberOfCategories() {
        return numberOfCategories.getText();
    }

    public String getNames() {
        return names.getText();
    }

    public void setListener(SelectCategoriesListener listener) {
        this.listener = listener;
    }







    @Override
    public void actionPerformed(ActionEvent e) {
        if (forward == (JButton) e.getSource()){
            SelectCategoriesEvent event= new SelectCategoriesEvent(this,Integer.parseInt(getNumberOfCategories()),getNames(),tweet,fromExplorer);
            listener.eventOccurred(event);
        }
    }
}
