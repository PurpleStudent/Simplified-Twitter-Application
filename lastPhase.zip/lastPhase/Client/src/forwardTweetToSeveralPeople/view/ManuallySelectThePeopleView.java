package forwardTweetToSeveralPeople.view;

import forwardTweetToSeveralPeople.event.ManuallySelectThePeopleEvent;
import forwardTweetToSeveralPeople.listener.ManuallySelectThePeopleListener;
import models.Tweet;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ManuallySelectThePeopleView extends JPanel implements ActionListener {


    private final JTextField numberOfPersons= new JTextField(70);
    private final JTextField usernames= new JTextField(70);

    private final JButton forward= new JButton("forward");

    ManuallySelectThePeopleListener listener;

    private final Tweet tweet;
    private final boolean fromExplorer;





















    public ManuallySelectThePeopleView(Tweet tweet, boolean fromExplorer){
        this.tweet = tweet;
        this.fromExplorer= fromExplorer;
        this.setBackground(new Color(70, 160, 241));
        Border innerBorder= BorderFactory.createTitledBorder("Manually Select The People");
        Border outerBorder= BorderFactory.createEmptyBorder(20,20,300,20);
        this.setBorder(BorderFactory.createCompoundBorder(outerBorder,innerBorder));
        this.setLayout(new GridBagLayout());
        GridBagConstraints gridBagConstraints= new GridBagConstraints();
        gridBagConstraints.weightx= 1;
        gridBagConstraints.weighty= 1;

        //text
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.insets = new Insets(0, 0, 0, 7);
        gridBagConstraints.anchor = GridBagConstraints.LINE_END;
        this.add(new JLabel("number of persons : "), gridBagConstraints);
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.insets = new Insets(0, 0, 0, 7);
        gridBagConstraints.anchor = GridBagConstraints.LINE_START;
        this.add(numberOfPersons, gridBagConstraints);

        //photoAddress
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.insets = new Insets(0, 0, 0, 7);
        gridBagConstraints.anchor = GridBagConstraints.LINE_END;
        this.add(new JLabel("usernames : "), gridBagConstraints);
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.insets = new Insets(0, 0, 0, 0);
        gridBagConstraints.anchor = GridBagConstraints.LINE_START;
        this.add(usernames, gridBagConstraints);

        //createNewTweetButton
        gridBagConstraints.weightx = 1;
        gridBagConstraints.weighty = 2;
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 5;
        gridBagConstraints.insets = new Insets(0, 0, 0, 0);
        gridBagConstraints.anchor = GridBagConstraints.FIRST_LINE_START;
        this.add(forward, gridBagConstraints);
        forward.addActionListener(this);
    }


    public String getNumberOfPersons() {
        return numberOfPersons.getText();
    }

    public String getUsernames() {
        return usernames.getText();
    }

    public void setListener(ManuallySelectThePeopleListener listener) {
        this.listener = listener;
    }







    @Override
    public void actionPerformed(ActionEvent e) {
        if (forward == (JButton) e.getSource()){
            ManuallySelectThePeopleEvent event= new ManuallySelectThePeopleEvent(this,Integer.parseInt(getNumberOfPersons()),getUsernames(),tweet,fromExplorer);
            listener.eventOccurred(event);
        }
    }
}
