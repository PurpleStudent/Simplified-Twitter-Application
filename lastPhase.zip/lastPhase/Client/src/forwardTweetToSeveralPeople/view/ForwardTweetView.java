package forwardTweetToSeveralPeople.view;

import forwardTweetToSeveralPeople.event.ForwardTweetEvent;
import forwardTweetToSeveralPeople.listener.ForwardTweetListener;
import models.Tweet;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ForwardTweetView extends JPanel implements ActionListener {


    private final JButton manuallySelectThePeopleIWant= new JButton("Manually select the people I want"+ "   ✅");
    private final JButton selectCategoryFromTheCategoriesIHaveCreated= new JButton("Select categories"+ "   ✅");
    private final JButton sendToAllUsers= new JButton("Send to all users"+ "   ✅");
    private final JButton comingBackToHomePage= new JButton("Coming back to HomePage"+"   ✅");
    private final JButton logOutButton= new JButton("Log Out"+ "   ✅");
    private final JButton exitButton= new JButton("Exit"+ "   ✅");

    private ForwardTweetListener listener;

    Tweet tweet;
    private final boolean fromExplorer;

















    public ForwardTweetView(Tweet tweet,boolean fromExplorer){
        this.tweet= tweet;
        this.fromExplorer= fromExplorer;
        this.setBackground(Color.yellow);
        this.setLayout(new GridLayout(6,1));

        this.add(manuallySelectThePeopleIWant);
        this.add(selectCategoryFromTheCategoriesIHaveCreated);
        this.add(sendToAllUsers);
        this.add(comingBackToHomePage);
        this.add(logOutButton);
        this.add(exitButton);

        manuallySelectThePeopleIWant.addActionListener(this);
        selectCategoryFromTheCategoriesIHaveCreated.addActionListener(this);
        sendToAllUsers.addActionListener(this);
        comingBackToHomePage.addActionListener(this);
        logOutButton.addActionListener(this);
        exitButton.addActionListener(this);
    }









    public void setListener(ForwardTweetListener listener) {
        this.listener = listener;
    }








    @Override
    public void actionPerformed(ActionEvent e) {
        if (manuallySelectThePeopleIWant == (JButton) e.getSource()){
            ForwardTweetEvent event= new ForwardTweetEvent(this,"manually Select The People I Want",tweet,fromExplorer);
            listener.eventOccurred(event);
        }
        if (selectCategoryFromTheCategoriesIHaveCreated == (JButton) e.getSource()){
            ForwardTweetEvent event= new ForwardTweetEvent(this,"select Category From The Categories I Have Created",tweet,fromExplorer);
            listener.eventOccurred(event);
        }
        if (sendToAllUsers == (JButton) e.getSource()){
            ForwardTweetEvent event= new ForwardTweetEvent(this,"send To All Users",tweet,fromExplorer);
            listener.eventOccurred(event);
        }
        if (comingBackToHomePage == (JButton) e.getSource()){
            ForwardTweetEvent event= new ForwardTweetEvent(this,"coming Back To HomePage",tweet,fromExplorer);
            listener.eventOccurred(event);
        }
        if (logOutButton == (JButton) e.getSource()){
            ForwardTweetEvent event= new ForwardTweetEvent(this,"log Out",tweet,fromExplorer);
            listener.eventOccurred(event);
        }
        if (exitButton == (JButton) e.getSource()){
            ForwardTweetEvent event= new ForwardTweetEvent(this,"exit",tweet,fromExplorer);
            listener.eventOccurred(event);
        }
    }
}
