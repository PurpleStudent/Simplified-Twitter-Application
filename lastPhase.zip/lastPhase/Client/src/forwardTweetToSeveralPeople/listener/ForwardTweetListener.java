package forwardTweetToSeveralPeople.listener;

import forwardTweetToSeveralPeople.event.ForwardTweetEvent;
import forwardTweetToSeveralPeople.view.ManuallySelectThePeopleView;
import forwardTweetToSeveralPeople.view.SelectCategoriesView;
import homepage.listener.HomePageListener;
import homepage.view.HomePageView;
import models.User;
import tweet.listener.TweetListener;
import tweet.view.TweetView;
import view.MainFrame;
import view.MainPanel;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.util.Scanner;

public class ForwardTweetListener {

    ManuallySelectThePeopleView manuallySelectThePeopleView;
    MainPanel mainPanel= new MainPanel();
    SelectCategoriesView selectCategoriesView;
    HomePageView homePageView= new HomePageView();
    //ForwardTweetController controller= new ForwardTweetController();

    TweetView tweetView;


















    public void eventOccurred(ForwardTweetEvent event) {

        if (event.getButton().equals("manually Select The People I Want")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            manuallySelectThePeopleView= new ManuallySelectThePeopleView(
                    event.getTweet(),
                    event.isFromExplorer()
            );
            manuallySelectThePeopleView.setListener(new ManuallySelectThePeopleListener());
            MainFrame.mainFrame.getContentPane().add(manuallySelectThePeopleView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }





        if (event.getButton().equals("select Category From The Categories I Have Created")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            selectCategoriesView= new SelectCategoriesView(
                    event.getTweet(),
                    event.isFromExplorer()
            );
            selectCategoriesView.setListener(new SelectCategoriesListener());
            MainFrame.mainFrame.getContentPane().add(selectCategoriesView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }












        if (event.getButton().equals("send To All Users")){
            sendToAllUsers (event.getTweet().getId());
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            tweetView = new TweetView(
                    event.getTweet(),
                    getTweetImage(event.getTweet().getId()),
                    getProfileImage(event.getTweet().getCreatorUserId()),
                    event.isFromExplorer()
            );
            tweetView.setListener(new TweetListener());
            MainFrame.mainFrame.getContentPane().add(tweetView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }



        if (event.getButton().equals("coming Back To HomePage")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            homePageView.setStringListener(new HomePageListener());
            MainFrame.mainFrame.getContentPane().add(homePageView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }



        if (event.getButton().equals("log Out")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            MainFrame.mainFrame.getContentPane().add(mainPanel);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }

        if (event.getButton().equals("exit")){
            System.exit(0);
        }
    }































    private void sendToAllUsers(long tweetId){
        try {
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{ForwardTweetController}"+"{sendToAllUsers}{"+tweetId+"}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response= input.nextLine();

            socket.close();
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }































    private BufferedImage getTweetImage(long tweetId){
        try {
            // first outputs
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));
            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{ForwardTweetController}"+"{getTweetImage}{"+tweetId+"}";
            output.println(message);
            //------------------------------------------------------------------------------------------------------------------------------------------------------------------
            // first inputs
            BufferedImage image= null;
            InputStream inputStream = socket.getInputStream();
            byte[] sizeAr = new byte[4];
            inputStream.read(sizeAr);
            int size = ByteBuffer.wrap(sizeAr).asIntBuffer().get();
            byte[] imageAr = new byte[size];
            inputStream.read(imageAr);
            image = ImageIO.read(new ByteArrayInputStream(imageAr));
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
            // second outputs
            PrintWriter output2 = new PrintWriter(socket.getOutputStream(), true);
            String message2 = "received.";
            output.println(message);
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------------
            // second inputs
            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();
            socket.close();
            return image;
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }































    private BufferedImage getProfileImage(long userid){
        try {
            // first outputs
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));
            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{ForwardTweetController}"+"{getProfileImage}{"+userid+"}";
            output.println(message);
            //------------------------------------------------------------------------------------------------------------------------------------------------------------------
            // first inputs
            BufferedImage image= null;
            InputStream inputStream = socket.getInputStream();
            byte[] sizeAr = new byte[4];
            inputStream.read(sizeAr);
            int size = ByteBuffer.wrap(sizeAr).asIntBuffer().get();
            byte[] imageAr = new byte[size];
            inputStream.read(imageAr);
            image = ImageIO.read(new ByteArrayInputStream(imageAr));
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
            // second outputs
            PrintWriter output2 = new PrintWriter(socket.getOutputStream(), true);
            String message2 = "received.";
            output.println(message);
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------------
            // second inputs
            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();
            socket.close();
            return image;
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}
