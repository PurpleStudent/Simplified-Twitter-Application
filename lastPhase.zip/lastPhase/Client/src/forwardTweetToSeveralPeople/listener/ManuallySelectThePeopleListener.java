package forwardTweetToSeveralPeople.listener;

import forwardTweetToSeveralPeople.event.ManuallySelectThePeopleEvent;
import models.User;
import tweet.listener.TweetListener;
import tweet.view.TweetView;
import view.MainFrame;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.util.Scanner;

public class ManuallySelectThePeopleListener {

    //ForwardTweetController controller= new ForwardTweetController();
    TweetView tweetView;







    public void eventOccurred(ManuallySelectThePeopleEvent event){
        forwardToManuallySelectedPeople(event.getNumber(),event.getUsernames(),event.getTweet().getText());
        MainFrame.mainFrame.getContentPane().removeAll();
        MainFrame.mainFrame.getContentPane().invalidate();
        tweetView= new TweetView(
                event.getTweet(),
                getTweetImage(event.getTweet().getId()),
                getProfileImage(event.getTweet().getCreatorUserId()),
                event.isFromExplorer()
        );
        tweetView.setListener(new TweetListener());
        MainFrame.mainFrame.getContentPane().add(tweetView);
        MainFrame.mainFrame.getContentPane().revalidate();
        MainFrame.mainFrame.repaint();
    }































    private void forwardToManuallySelectedPeople( int number, String usernames, String tweetText ){
        try {
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{ForwardTweetController}"+"{forwardToManuallySelectedPeople}{"+number+"}{"+usernames+"}{"+tweetText+"}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response= input.nextLine();

            socket.close();
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }































    private BufferedImage getTweetImage(long tweetId){
        try {
            // first outputs
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));
            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{ForwardTweetController}"+"{getTweetImage}{"+tweetId+"}";
            output.println(message);
            //------------------------------------------------------------------------------------------------------------------------------------------------------------------
            // first inputs
            BufferedImage image= null;
            InputStream inputStream = socket.getInputStream();
            byte[] sizeAr = new byte[4];
            inputStream.read(sizeAr);
            int size = ByteBuffer.wrap(sizeAr).asIntBuffer().get();
            byte[] imageAr = new byte[size];
            inputStream.read(imageAr);
            image = ImageIO.read(new ByteArrayInputStream(imageAr));
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
            // second outputs
            PrintWriter output2 = new PrintWriter(socket.getOutputStream(), true);
            String message2 = "received.";
            output.println(message);
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------------
            // second inputs
            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();
            socket.close();
            return image;
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }































    private BufferedImage getProfileImage(long userid){
        try {
            // first outputs
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));
            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{ForwardTweetController}"+"{getProfileImage}{"+userid+"}";
            output.println(message);
            //------------------------------------------------------------------------------------------------------------------------------------------------------------------
            // first inputs
            BufferedImage image= null;
            InputStream inputStream = socket.getInputStream();
            byte[] sizeAr = new byte[4];
            inputStream.read(sizeAr);
            int size = ByteBuffer.wrap(sizeAr).asIntBuffer().get();
            byte[] imageAr = new byte[size];
            inputStream.read(imageAr);
            image = ImageIO.read(new ByteArrayInputStream(imageAr));
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
            // second outputs
            PrintWriter output2 = new PrintWriter(socket.getOutputStream(), true);
            String message2 = "received.";
            output.println(message);
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------------
            // second inputs
            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();
            socket.close();
            return image;
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}
