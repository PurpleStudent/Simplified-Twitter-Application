package forwardTweetToSeveralPeople.event;

import models.Tweet;

import java.util.EventObject;

public class SelectCategoriesEvent extends EventObject {

    private int numberOfCategories;
    private String names;
    private final Tweet tweet;
    private final boolean fromExplorer;




    public SelectCategoriesEvent(Object source, int numberOfCategories, String names, Tweet tweet, boolean fromExplorer) {
        super(source);
        this.numberOfCategories= numberOfCategories;
        this.names= names;
        this.tweet= tweet;
        this.fromExplorer= fromExplorer;
    }


    public int getNumberOfCategories() {
        return numberOfCategories;
    }

    public String getNames() {
        return names;
    }

    public Tweet getTweet() {
        return tweet;
    }

    public boolean isFromExplorer() {
        return fromExplorer;
    }
}
