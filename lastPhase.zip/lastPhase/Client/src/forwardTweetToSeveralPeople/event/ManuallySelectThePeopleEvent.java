package forwardTweetToSeveralPeople.event;

import models.Tweet;

import java.util.EventObject;

public class ManuallySelectThePeopleEvent extends EventObject {


    private final int number;
    private final String usernames;
    private final Tweet tweet;
    private final boolean fromExplorer;



    public ManuallySelectThePeopleEvent(Object source, int number, String usernames, Tweet tweet, boolean fromExplorer) {
        super(source);
        this.number= number;
        this.usernames= usernames;
        this.tweet= tweet;
        this.fromExplorer= fromExplorer;
    }


    public int getNumber() {
        return number;
    }

    public String getUsernames() {
        return usernames;
    }

    public Tweet getTweet() {
        return tweet;
    }

    public boolean isFromExplorer() {
        return fromExplorer;
    }
}
