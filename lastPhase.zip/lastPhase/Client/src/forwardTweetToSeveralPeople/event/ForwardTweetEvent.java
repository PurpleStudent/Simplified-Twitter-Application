package forwardTweetToSeveralPeople.event;

import models.Tweet;

import java.util.EventObject;

public class ForwardTweetEvent extends EventObject {

    String button;
    Tweet tweet;
    private final boolean fromExplorer;







    public ForwardTweetEvent(Object source, String button,Tweet tweet, boolean fromExplorer) {
        super(source);
        this.button= button;
        this.tweet= tweet;
        this.fromExplorer= fromExplorer;
    }


    public String getButton() {
        return button;
    }

    public Tweet getTweet() {
        return tweet;
    }

    public boolean isFromExplorer() {
        return fromExplorer;
    }
}
