package homepage.listener;

import explorerPage.listener.ExplorerPageListener;
import explorerPage.view.ExplorerPageView;
import listener.StringListener;
import messagingPage.listener.MessagingPageListener;
import messagingPage.view.MessagingPageView;
import models.Comment;
import models.DateTime;
import models.Tweet;
import models.User;
import personalPage.listener.PersonalPageListener;
import personalPage.view.PersonalPageView;
import settingsPage.listener.SettingPageListener;
import settingsPage.view.SettingsPageView;
import tweet.listener.TweetListener;
import tweet.view.TweetView;
import view.MainFrame;
import view.MainPanel;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.util.Collections;
import java.util.LinkedList;
import java.util.Scanner;

public class HomePageListener implements StringListener {

    //HomePageController controller= new HomePageController();
    PersonalPageView personalPageView= new PersonalPageView();
    ExplorerPageView explorerPageView= new ExplorerPageView();
    MessagingPageView messagingPageView= new MessagingPageView();
    SettingsPageView settingsPageView= new SettingsPageView();
    TweetView tweetView;
    MainPanel mainPanel= new MainPanel();












    @Override
    public void stringEventOccurred(String string) {
        if (string.equals("Personal Page")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            personalPageView.setStringListener(new PersonalPageListener());
            MainFrame.mainFrame.getContentPane().add(personalPageView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }

        if (string.equals("Timeline Page")){
            if (firstDisplayableTweet()!=null) {
                MainFrame.mainFrame.getContentPane().removeAll();
                MainFrame.mainFrame.getContentPane().invalidate();
                tweetView = new TweetView(
                        firstDisplayableTweet(),
                        getTweetImage(firstDisplayableTweet().getId()),
                        getProfileImage(firstDisplayableTweet().getCreatorUserId()),
                        false
                );
                tweetView.setListener(new TweetListener());
                MainFrame.mainFrame.getContentPane().add(tweetView);
                MainFrame.mainFrame.getContentPane().revalidate();
                MainFrame.mainFrame.repaint();
            }
        }

        if (string.equals("Explorer Page")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            explorerPageView.setStringListener(new ExplorerPageListener());
            MainFrame.mainFrame.getContentPane().add(explorerPageView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }
        if (string.equals("Messaging Page")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            messagingPageView.setStringListener(new MessagingPageListener());
            MainFrame.mainFrame.getContentPane().add(messagingPageView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }
        if (string.equals("Settings Page")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            settingsPageView.setStringListener(new SettingPageListener());
            MainFrame.mainFrame.getContentPane().add(settingsPageView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }

        if (string.equals("Log Out")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            MainFrame.mainFrame.getContentPane().add(mainPanel);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }

        if (string.equals("Exit")){
            System.exit(0);
        }
    }























    private Tweet firstDisplayableTweet(){
        try {
            Tweet tweet= null;
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+User.authToken+"}{"+User.currentUserId+"}"+"{HomePageController}"+"{firstDisplayableTweet}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response= input.nextLine();

            if (!response.equals("null")) {
                String remaining = response;
                LinkedList<String> informationList = new LinkedList<>();

                while (!remaining.equals("")) {
                    String info = remaining.substring(remaining.indexOf('{') + 1, remaining.indexOf('}'));
                    informationList.add(info);  // Synchronized

                    if (remaining.indexOf('}') + 1 == remaining.length()) {
                        remaining = "";
                    } else {
                        remaining = remaining.substring(remaining.indexOf('}') + 1);
                    }
                }

                String text = informationList.get(0);
                String tweetId = informationList.get(1);
                String reportNumber = informationList.get(2);
                String dateTimeOfCreation = informationList.get(3);
                String ownerTweetId = informationList.get(4);
                String creatorUserId = informationList.get(5);
                String creatorUsername = informationList.get(6);

                if (Long.parseLong(ownerTweetId) == -1) {
                    tweet = new Tweet(Long.parseLong(creatorUserId), text);
                } else {
                    tweet = new Comment(Long.parseLong(creatorUserId), text, Long.parseLong(ownerTweetId));
                }
                tweet.setId(Long.parseLong(tweetId));
                tweet.setReportNumber(Long.parseLong(reportNumber));
                tweet.setDateTimeOfCreation(DateTime.convertStringToDateTime(dateTimeOfCreation));
                tweet.setCreatorUsername(creatorUsername);
            }

            socket.close();
            return tweet;
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }































    private BufferedImage getTweetImage(long tweetId){
        try {
            // first outputs
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));
            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{HomePageController}"+"{getTweetImage}{"+tweetId+"}";
            output.println(message);
            //------------------------------------------------------------------------------------------------------------------------------------------------------------------
            // first inputs
            BufferedImage image= null;
            InputStream inputStream = socket.getInputStream();
            byte[] sizeAr = new byte[4];
            inputStream.read(sizeAr);
            int size = ByteBuffer.wrap(sizeAr).asIntBuffer().get();
            byte[] imageAr = new byte[size];
            inputStream.read(imageAr);
            image = ImageIO.read(new ByteArrayInputStream(imageAr));
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
            // second outputs
            PrintWriter output2 = new PrintWriter(socket.getOutputStream(), true);
            String message2 = "received.";
            output.println(message);
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------------
            // second inputs
            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();
            socket.close();
            return image;
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }






























    private BufferedImage getProfileImage(long userid){
        try {
            // first outputs
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));
            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{HomePageController}"+"{getProfileImage}{"+userid+"}";
            output.println(message);
            //------------------------------------------------------------------------------------------------------------------------------------------------------------------
            // first inputs
            BufferedImage image= null;
            InputStream inputStream = socket.getInputStream();
            byte[] sizeAr = new byte[4];
            inputStream.read(sizeAr);
            int size = ByteBuffer.wrap(sizeAr).asIntBuffer().get();
            byte[] imageAr = new byte[size];
            inputStream.read(imageAr);
            image = ImageIO.read(new ByteArrayInputStream(imageAr));
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
            // second outputs
            PrintWriter output2 = new PrintWriter(socket.getOutputStream(), true);
            String message2 = "received.";
            output.println(message);
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------------
            // second inputs
            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();
            socket.close();
            return image;
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}
