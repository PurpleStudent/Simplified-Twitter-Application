package homepage.view;

import listener.StringListener;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class HomePageView extends JPanel implements ActionListener {

    private final JButton personalPageButton= new JButton("Personal Page"+ "   ✅");
    private final JButton timelinePageButton= new JButton("Timeline Page"+ "   ✅");
    private final JButton explorerPageButton= new JButton("Explorer Page"+ "   ✅");
    private final JButton messagingPageButton= new JButton("Messaging Page"+ "   ✅");
    private final JButton settingsPageButton= new JButton("Settings Page"+ "   ✅");
    private final JButton logOutButton= new JButton("Log Out"+ "   ✅");
    private final JButton exitButton= new JButton("Exit"+ "   ✅");

    private StringListener stringListener;




    public HomePageView(){
        this.setBackground(Color.yellow);
        this.setLayout(new GridLayout(7,1));

        this.add(personalPageButton);
        this.add(timelinePageButton);
        this.add(explorerPageButton);
        this.add(messagingPageButton);
        this.add(settingsPageButton);
        this.add(logOutButton);
        this.add(exitButton);

        personalPageButton.addActionListener(this);
        timelinePageButton.addActionListener(this);
        explorerPageButton.addActionListener(this);
        messagingPageButton.addActionListener(this);
        settingsPageButton.addActionListener(this);
        logOutButton.addActionListener(this);
        exitButton.addActionListener(this);
    }









    public void setStringListener(StringListener stringListener) {
        this.stringListener = stringListener;
    }








    @Override
    public void actionPerformed(ActionEvent e) {
        if (personalPageButton == (JButton) e.getSource()){
            stringListener.stringEventOccurred("Personal Page");
        }
        if (timelinePageButton == (JButton) e.getSource()){
            stringListener.stringEventOccurred("Timeline Page");
        }
        if (explorerPageButton == (JButton) e.getSource()){
            stringListener.stringEventOccurred("Explorer Page");
        }
        if (messagingPageButton == (JButton) e.getSource()){
            stringListener.stringEventOccurred("Messaging Page");
        }
        if (settingsPageButton == (JButton) e.getSource()){
            stringListener.stringEventOccurred("Settings Page");
        }
        if (logOutButton == (JButton) e.getSource()){
            stringListener.stringEventOccurred("Log Out");
        }
        if (exitButton == (JButton) e.getSource()){
            stringListener.stringEventOccurred("Exit");
        }
    }
}
