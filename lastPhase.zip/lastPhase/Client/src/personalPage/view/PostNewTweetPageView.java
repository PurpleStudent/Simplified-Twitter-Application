package personalPage.view;

import personalPage.event.PostNewTweetEvent;
import personalPage.listener.PostNewTweetListener;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PostNewTweetPageView extends JPanel implements ActionListener {


    private final JTextField text= new JTextField(70);
    private final JTextField photoAddress= new JTextField(70);

    private final JButton createNewTweetButton= new JButton("Create new tweet");

    PostNewTweetListener postNewTweetListener;





    public PostNewTweetPageView(){
        this.setBackground(new Color(70, 160, 241));
        Border innerBorder= BorderFactory.createTitledBorder("Enter the text of the tweet: ");
        Border outerBorder= BorderFactory.createEmptyBorder(20,20,300,20);
        this.setBorder(BorderFactory.createCompoundBorder(outerBorder,innerBorder));
        this.setLayout(new GridBagLayout());
        GridBagConstraints gridBagConstraints= new GridBagConstraints();
        gridBagConstraints.weightx= 1;
        gridBagConstraints.weighty= 1;

        //text
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.insets = new Insets(0, 0, 0, 7);
        gridBagConstraints.anchor = GridBagConstraints.LINE_END;
        this.add(new JLabel("text of the tweet: "), gridBagConstraints);
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.insets = new Insets(0, 0, 0, 7);
        gridBagConstraints.anchor = GridBagConstraints.LINE_START;
        this.add(text, gridBagConstraints);

        //photoAddress
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.insets = new Insets(0, 0, 0, 7);
        gridBagConstraints.anchor = GridBagConstraints.LINE_END;
        this.add(new JLabel("photo address: "), gridBagConstraints);
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.insets = new Insets(0, 0, 0, 0);
        gridBagConstraints.anchor = GridBagConstraints.LINE_START;
        this.add(photoAddress, gridBagConstraints);

        //createNewTweetButton
        gridBagConstraints.weightx = 1;
        gridBagConstraints.weighty = 2;
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 5;
        gridBagConstraints.insets = new Insets(0, 0, 0, 0);
        gridBagConstraints.anchor = GridBagConstraints.FIRST_LINE_START;
        this.add(createNewTweetButton, gridBagConstraints);
        createNewTweetButton.addActionListener(this);
    }






    @Override
    public void paint(Graphics g) {
        super.paint(g);
        Font myFont = new Font ("Bold Italic", Font.BOLD, 50);
        g.setFont (myFont);

        g.setColor(new Color(226, 25, 111));
        g.drawString("🌸"+"🌸"+"🌸"+"🌸"+"🌸"+"🌸"+"🌸"+"🌸"+"🌸"+"🌸"+"🌸"+"🌸"+"🌸"+"🌸"+"🌸" , 100 , 600);
    }







    public void setPostNewTweetListener(PostNewTweetListener postNewTweetListener) {
        this.postNewTweetListener = postNewTweetListener;
    }







    @Override
    public void actionPerformed(ActionEvent e) {
        if (createNewTweetButton == (JButton) e.getSource()){
            PostNewTweetEvent event= new PostNewTweetEvent(this,text.getText(),photoAddress.getText());
            postNewTweetListener.postNewTweetOccurred(event);
        }
    }
}
