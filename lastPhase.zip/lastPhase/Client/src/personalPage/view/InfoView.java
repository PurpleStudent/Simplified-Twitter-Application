package personalPage.view;

import listener.StringListener;
import models.User;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;

public class InfoView extends JPanel implements ActionListener {


    User user;
    BufferedImage profileImage;
    JButton returnToPersonalPage= new JButton("return To Personal Page");
    private StringListener listener;







    public InfoView(User user, BufferedImage profileImage){
        this.setBackground(new Color(180, 239, 223));
        this.user= user;
        this.profileImage= profileImage;


        //
        returnToPersonalPage.setBounds(50,600,20,100);
        this.add(returnToPersonalPage);
        returnToPersonalPage.addActionListener(this);

    }


    public void setListener(StringListener listener) {
        this.listener = listener;
    }



















    @Override
    public void paint(Graphics g) {
        super.paint(g);
        Font myFont = new Font ("Bold Italic", Font.BOLD, 30);
        g.setFont (myFont);

        g.setColor(new Color(9, 112, 239, 255));
        g.drawString("INFO", 100, 200);

        g.setColor(new Color(9, 112, 239, 255));
        g.drawString("🙂 "+user.getProfile().getFirstName()+" "+user.getProfile().getLastName(), 100, 350);

        g.setColor(new Color(126, 63, 213));
        g.drawString("😉 "+user.getUsername(), 100, 400);

        g.setColor(new Color(105, 45, 198));
        g.drawString("📚 "+"bio : "+user.getProfile().getBiography(), 100, 450);


        if (user.getProfile().getDateOfBirth()!=null) {
            g.setColor(new Color(119, 66, 199));
            g.drawString("🎂 "+"birthday : "+user.getProfile().getDateOfBirth().toString(), 100, 550);
        }


        g.setColor(new Color(130, 47, 139));
        g.drawString("📧 "+"email : "+user.getProfile().getEmail(), 100, 600);


        g.setColor(new Color(119, 71, 193));
        g.drawString("📞 "+"phone number : "+String.valueOf(user.getProfile().getPhoneNumber()), 100, 650);

        g.setColor(new Color(144, 65, 219));

        g.fillRect(10, 70, 5, 670);
        g.fillRect(10,70,950,5);
        g.fillRect(960, 70, 5, 675);
        g.fillRect(10, 740, 950, 5);

        if (profileImage!=null) {
            g.drawImage(profileImage, 650, 80, 300, 300, null);
        }

    }























    @Override
    public void actionPerformed(ActionEvent e) {
        if (returnToPersonalPage == (JButton) e.getSource()){
            listener.stringEventOccurred("returnToPersonalPage");
        }
    }
}
