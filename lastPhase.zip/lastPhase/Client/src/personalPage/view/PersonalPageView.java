package personalPage.view;

import listener.StringListener;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PersonalPageView extends JPanel implements ActionListener {


    private final JButton postNewTweetButton= new JButton("Post a new tweet"+  "   🔘");
    private final JButton viewYourTweetsButton= new JButton("View your tweets"+  "   🔘");
    private final JButton editProfileButton= new JButton("Edit Profile"+  "   🔘");
    private final JButton accessListsButton= new JButton("Access lists"+ "   🔘");
    private final JButton infoButton= new JButton("Info" + "   🔘");
    private final JButton announcementsButton= new JButton("Announcements"+ "   🔘");
    private final JButton returnToHomePageButton= new JButton("Return to Home Page" + "   🔘");
    private final JButton logOutButton= new JButton("Log out" + "   🔘");
    private final JButton exitButton= new JButton("Exit" + "   🔘");





    private StringListener stringListener;






    public PersonalPageView(){
        this.setBackground(Color.yellow);
        this.setLayout(new GridLayout(9,1));

        this.add(postNewTweetButton);
        this.add(viewYourTweetsButton);
        this.add(editProfileButton);
        this.add(accessListsButton);
        this.add(infoButton);
        this.add(announcementsButton);
        this.add(returnToHomePageButton);
        this.add(logOutButton);
        this.add(exitButton);

        postNewTweetButton.addActionListener(this);
        viewYourTweetsButton.addActionListener(this);
        editProfileButton.addActionListener(this);
        accessListsButton.addActionListener(this);
        infoButton.addActionListener(this);
        announcementsButton.addActionListener(this);
        returnToHomePageButton.addActionListener(this);
        logOutButton.addActionListener(this);
        exitButton.addActionListener(this);
    }


    public void setStringListener(StringListener stringListener) {
        this.stringListener = stringListener;
    }





    @Override
    public void actionPerformed(ActionEvent e) {
        if (postNewTweetButton == (JButton) e.getSource()){
            stringListener.stringEventOccurred("Post a new tweet");
        }
        if (viewYourTweetsButton == (JButton) e.getSource()){
            stringListener.stringEventOccurred("View your tweets");
        }
        if (editProfileButton == (JButton) e.getSource()){
            stringListener.stringEventOccurred("Edit Profile");
        }
        if (accessListsButton == (JButton) e.getSource()){
            stringListener.stringEventOccurred("Access lists");
        }
        if (infoButton == (JButton) e.getSource()){
            stringListener.stringEventOccurred("Info");
        }
        if (announcementsButton == (JButton) e.getSource()){
            stringListener.stringEventOccurred("Announcements");
        }
        if (returnToHomePageButton == (JButton) e.getSource()){
            stringListener.stringEventOccurred("Return to Home Page");
        }
        if (logOutButton == (JButton) e.getSource()){
            stringListener.stringEventOccurred("Log out");
        }
        if (exitButton == (JButton) e.getSource()){
            stringListener.stringEventOccurred("Exit");
        }
    }
}
