package personalPage.listener;

import models.DateTime;
import models.Message;
import models.User;
import personalPage.event.PostNewTweetEvent;
import personalPage.view.PersonalPageView;
import view.MainFrame;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.util.LinkedList;
import java.util.Scanner;

public class PostNewTweetListener {


    //private final PostNewTweetController postNewTweetController= new PostNewTweetController();
    PersonalPageView personalPageView= new PersonalPageView();










    public void postNewTweetOccurred(PostNewTweetEvent event){
        MainFrame.mainFrame.getContentPane().removeAll();
        MainFrame.mainFrame.getContentPane().invalidate();
        personalPageView.setStringListener(new PersonalPageListener());
        MainFrame.mainFrame.getContentPane().add(personalPageView);
        MainFrame.mainFrame.getContentPane().revalidate();
        MainFrame.mainFrame.repaint();
        createNewTweet(event.getTextOfTweet() , event.getPhotoAddress());
    }































    private void createNewTweet( String textOfTweet , String photoAddress ){
        try {
            // first outputs
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));
            OutputStream outputStream= socket.getOutputStream();
            PrintWriter output = new PrintWriter( outputStream , true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{PostNewTweetController}"+"{createNewTweet}{"+textOfTweet+"}";
            output.println(message);
            //-----------------------------------------------------------------------------------------------------------------------------------------------------------------
            // first inputs
            Scanner input1 = new Scanner(socket.getInputStream());
            String response1= input1.nextLine();
            //-----------------------------------------------------------------------------------------------------------------------------------------------------------------
            // second outputs
            File file;
            ByteArrayOutputStream byteArrayOutputStream= null;
            byteArrayOutputStream = new ByteArrayOutputStream();
            if (!photoAddress.equals("")) {
                file = new File(photoAddress);
                file.getParentFile().mkdirs();
                if (!file.exists()) {
                    file.createNewFile();
                }
                BufferedImage image = ImageIO.read(file);
                ImageIO.write(image, "jpg", byteArrayOutputStream);
            }
            if (response1.equals("Send the image.")){
                byte[] size = ByteBuffer.allocate(4).putInt(byteArrayOutputStream.size()).array();
                outputStream.write(size);
                outputStream.write(byteArrayOutputStream.toByteArray());
                outputStream.flush();
            }
            //----------------------------------------------------------------------------------------------------------------------------------------------------------------
            // second inputs
            Scanner input2 = new Scanner(socket.getInputStream());
            String response2= input2.nextLine();
            socket.close();
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
}
