package personalPage.listener;

import listener.StringListener;
import personalPage.view.PersonalPageView;
import view.MainFrame;

public class  InfoListener implements StringListener {


    PersonalPageView personalPageView= new PersonalPageView();




    @Override
    public void stringEventOccurred(String string) {
        if (string.equals("returnToPersonalPage")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            personalPageView.setStringListener(new PersonalPageListener());
            MainFrame.mainFrame.getContentPane().add(personalPageView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }
    }
}
