package personalPage.listener;

import accessListsPage.listener.AccessListListener;
import accessListsPage.view.AccessListsPageView;
import announcements.listener.AnnouncementsListener;
import announcements.view.AnnouncementsView;
import editProfilePage.listener.EditProfileListener;
import editProfilePage.view.EditProfilePageView;
import homepage.listener.HomePageListener;
import homepage.view.HomePageView;
import listener.StringListener;
import models.*;
import personalPage.view.InfoView;
import personalPage.view.PostNewTweetPageView;
import tweet.listener.MyTweetPreviousNextListener;
import tweet.view.MyTweetView;
import view.MainFrame;
import view.MainPanel;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.util.LinkedList;
import java.util.Scanner;

public class PersonalPageListener implements StringListener {


    //private final ViewYourTweetController controller= new ViewYourTweetController();
    PostNewTweetPageView postNewTweetPageView= new PostNewTweetPageView();
    EditProfilePageView editProfilePageView= new EditProfilePageView();
    AccessListsPageView accessListsPageView= new AccessListsPageView();
    HomePageView homePageView= new HomePageView();
    MyTweetView myTweetView;
    InfoView infoView;
    AnnouncementsView announcementsView= new AnnouncementsView();
    MainPanel mainPanel= new MainPanel();


















    @Override
    public void stringEventOccurred(String string) {

        if (string.equals("Post a new tweet")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            postNewTweetPageView.setPostNewTweetListener(new PostNewTweetListener());
            MainFrame.mainFrame.getContentPane().add(postNewTweetPageView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }



        if (string.equals("View your tweets")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            myTweetView= new MyTweetView(
                    getMyFirstTweet() ,
                    getTweetImage ( getMyFirstTweet().getId() ) ,
                    getProfileImage(User.currentUserId)
            );
            myTweetView.setMyTweetPreviousNextListener(new MyTweetPreviousNextListener());
            MainFrame.mainFrame.getContentPane().add(myTweetView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }


        if (string.equals("Edit Profile")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            editProfilePageView.setStringListener(new EditProfileListener());
            MainFrame.mainFrame.getContentPane().add(editProfilePageView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }

        if (string.equals("Access lists")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            accessListsPageView.setStringListener(new AccessListListener());
            MainFrame.mainFrame.getContentPane().add(accessListsPageView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }

        if (string.equals("Info")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            infoView= new InfoView ( getUser(User.currentUserId)  ,  getProfileImage(User.currentUserId) );
            infoView.setListener(new InfoListener());
            MainFrame.mainFrame.getContentPane().add(infoView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }



        if (string.equals("Announcements")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            announcementsView.setStringListener(new AnnouncementsListener());
            MainFrame.mainFrame.getContentPane().add(announcementsView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }

        if (string.equals("Return to Home Page")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            homePageView.setStringListener(new HomePageListener());
            MainFrame.mainFrame.getContentPane().add(homePageView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }

        if (string.equals("Log out")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            MainFrame.mainFrame.getContentPane().add(mainPanel);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }

        if (string.equals("Exit")){
            System.exit(0);
        }
    }































    private Tweet getMyFirstTweet () {
        try {
            Tweet tweet= null;
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{ViewYourTweetController}"+"{getMyFirstTweet}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();
            System.out.println(response);
            if (!response.equals("null")) {
                String remaining = response;
                LinkedList<String> informationList = new LinkedList<>();

                while (!remaining.equals("")) {
                    String info = remaining.substring(remaining.indexOf('{') + 1, remaining.indexOf('}'));
                    informationList.add(info);

                    if (remaining.indexOf('}') + 1 == remaining.length()) {
                        remaining = "";
                    } else {
                        remaining = remaining.substring(remaining.indexOf('}') + 1);
                    }
                }

                long id = Long.parseLong(informationList.get(0));
                long ownerTweetId = Long.parseLong(informationList.get(1));
                String text = informationList.get(2);
                long creatorUserId= Long.parseLong(informationList.get(3));
                String creatorUsername = informationList.get(4);
                long reportNumber= Long.parseLong(informationList.get(5));
                DateTime dateTimeOfCreation= DateTime.convertStringToDateTime(informationList.get(6));

                if (ownerTweetId==-1){
                    tweet = new Tweet(creatorUserId, text);
                    tweet.setId(id);
                    tweet.setReportNumber(reportNumber);
                    tweet.setDateTimeOfCreation(dateTimeOfCreation);
                    tweet.setCreatorUsername(creatorUsername);
                }
                else {
                    tweet = new Comment(creatorUserId, text, ownerTweetId);
                    tweet.setId(id);
                    tweet.setReportNumber(reportNumber);
                    tweet.setDateTimeOfCreation(dateTimeOfCreation);
                    tweet.setCreatorUsername(creatorUsername);
                }
            }
            socket.close();
            return tweet;
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }































    private BufferedImage getTweetImage(long tweetId){
        try {
            // first outputs
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));
            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{ViewYourTweetController}"+"{getTweetImage}{"+tweetId+"}";
            output.println(message);
            //------------------------------------------------------------------------------------------------------------------------------------------------------------------
            // first inputs
            BufferedImage image= null;
            InputStream inputStream = socket.getInputStream();
            byte[] sizeAr = new byte[4];
            inputStream.read(sizeAr);
            int size = ByteBuffer.wrap(sizeAr).asIntBuffer().get();
            byte[] imageAr = new byte[size];
            inputStream.read(imageAr);
            image = ImageIO.read(new ByteArrayInputStream(imageAr));
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
            // second outputs
            PrintWriter output2 = new PrintWriter(socket.getOutputStream(), true);
            String message2 = "received.";
            output.println(message);
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------------
            // second inputs
            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();
            socket.close();
            return image;
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }































    private BufferedImage getProfileImage(long userid){
        try {
            // first outputs
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));
            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{ViewYourTweetController}"+"{getProfileImage}{"+userid+"}";
            output.println(message);
            //------------------------------------------------------------------------------------------------------------------------------------------------------------------
            // first inputs
            BufferedImage image= null;
            InputStream inputStream = socket.getInputStream();
            byte[] sizeAr = new byte[4];
            inputStream.read(sizeAr);
            int size = ByteBuffer.wrap(sizeAr).asIntBuffer().get();
            byte[] imageAr = new byte[size];
            inputStream.read(imageAr);
            image = ImageIO.read(new ByteArrayInputStream(imageAr));
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
            // second outputs
            PrintWriter output2 = new PrintWriter(socket.getOutputStream(), true);
            String message2 = "received.";
            output.println(message);
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------------
            // second inputs
            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();
            socket.close();
            return image;
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }































    private User getUser (long userId) {
        try {
            User user= null;
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{ViewYourTweetController}"+"{getUser}{"+userId+"}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();

            if (!response.equals("null")) {
                String remaining = response;
                LinkedList<String> informationList = new LinkedList<>();

                while (!remaining.equals("")) {
                    String info = remaining.substring(remaining.indexOf('{') + 1, remaining.indexOf('}'));
                    informationList.add(info);

                    if (remaining.indexOf('}') + 1 == remaining.length()) {
                        remaining = "";
                    } else {
                        remaining = remaining.substring(remaining.indexOf('}') + 1);
                    }
                }

                long userid = Long.parseLong(informationList.get(0));
                String username = informationList.get(1);
                String firstname = informationList.get(2);
                String lastname = informationList.get(3);
                String email= informationList.get(4);
                String biography= informationList.get(5);
                long phoneNumber = Long.parseLong(informationList.get(6));
                DateTime lastSeenDate = DateTime.convertStringToDateTime(informationList.get(7));
                Date dateOfBirth = Date.convertStringToDate(informationList.get(8));
                boolean active=false;
                if (informationList.get(9).equals("true")){active=true;}
                boolean privateAccount = false;
                if (informationList.get(10).equals("true")){privateAccount=true;}
                String showLastSeenDate= informationList.get(11);
                String showDateOfBirth= informationList.get(12);
                String showEmail = informationList.get(13);
                String showPhoneNumber = informationList.get(14);

                Profile profile= new Profile(firstname,lastname,email);
                profile.setBiography(biography);
                profile.setPhoneNumber(phoneNumber);
                profile.setLastSeenDate(lastSeenDate);
                profile.setDateOfBirth(dateOfBirth);
                profile.setActive(active);
                profile.setPrivateAccount(privateAccount);
                profile.setShowLastSeenDate(showLastSeenDate);
                profile.setShowDateOfBirth(showDateOfBirth);
                profile.setShowEmail(showEmail);
                profile.setShowPhoneNumber(showPhoneNumber);


                user = new User(username,profile);
                user.setId(userid);
            }

            socket.close();
            return user;
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}
