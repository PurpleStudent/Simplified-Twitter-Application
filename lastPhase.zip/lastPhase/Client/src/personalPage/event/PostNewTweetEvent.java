package personalPage.event;

import java.util.EventObject;

public class PostNewTweetEvent extends EventObject {


    private final String textOfTweet;
    private final String photoAddress;





    public PostNewTweetEvent(Object source, String textOfTweet, String photoAddress) {
        super(source);
        this.textOfTweet= textOfTweet;
        this.photoAddress= photoAddress;
    }


    public String getTextOfTweet() {
        return textOfTweet;
    }

    public String getPhotoAddress() {
        return photoAddress;
    }
}
