package group.listener;

import group.event.AddMemberEvent;
import group.view.GroupView;
import models.Category;
import models.DateTime;
import models.Group;
import models.User;
import view.MainFrame;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.LinkedList;
import java.util.Scanner;

public class AddMemberListener {

    //GroupController controller= new GroupController();

    GroupView groupView;




    public void eventOccurred(AddMemberEvent event){

        if (event.getButton().equals("add member")){
            addMember ( event.getUsername() , event.getGroupId() );
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            groupView= new GroupView ( getGroup(event.getGroupId()) );
            groupView.setListener(new GroupListener());
            MainFrame.mainFrame.getContentPane().add(groupView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }
    }































    private void addMember ( String username, long groupId ){
        try {
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{GroupController}"+"{addMember}{"+username+"}{"+groupId+"}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();

            socket.close();
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }































    private Group getGroup(long groupId){
        try {
            Group group= null;
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{GroupController}"+"{getGroup}{"+groupId+"}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();


            if (!response.equals("null")) {
                String remaining = response;
                LinkedList<String> informationList = new LinkedList<>();

                while (!remaining.equals("")) {
                    String info = remaining.substring(remaining.indexOf('{') + 1, remaining.indexOf('}'));
                    informationList.add(info);

                    if (remaining.indexOf('}') + 1 == remaining.length()) {
                        remaining = "";
                    } else {
                        remaining = remaining.substring(remaining.indexOf('}') + 1);
                    }
                }

                long id= Long.parseLong(informationList.get(0));
                String name= informationList.get(1);

                group = new Group(name);
                group.setId(id);
            }

            socket.close();
            return group;
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}
