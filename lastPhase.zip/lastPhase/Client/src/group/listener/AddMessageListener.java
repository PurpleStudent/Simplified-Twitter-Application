package group.listener;

import group.event.AddMessageEvent;
import group.view.GroupView;
import models.DateTime;
import models.Group;
import models.Message;
import models.User;
import view.MainFrame;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.util.LinkedList;
import java.util.Scanner;

public class AddMessageListener {

    //GroupController controller= new GroupController();
    GroupView groupView;







    public void eventOccurred(AddMessageEvent event){

        if (event.getButton().equals("write new message")){
            addMessage(event.getText() , event.getGroupId() , event.getPhotoAddress());
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            groupView= new GroupView ( getGroup(event.getGroupId()) );
            groupView.setListener(new GroupListener());
            MainFrame.mainFrame.getContentPane().add(groupView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }
    }































    private void addMessage ( String text, long groupId, String photoAddress ){
        try {
            // first outputs
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));
            OutputStream outputStream= socket.getOutputStream();
            PrintWriter output = new PrintWriter( outputStream , true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{GroupController}"+"{addMessage}{"+text+"}{"+groupId+"}";
            output.println(message);
            //-----------------------------------------------------------------------------------------------------------------------------------------------------------------
            // first inputs
            Scanner input1 = new Scanner(socket.getInputStream());
            String response1= input1.nextLine();
            //-----------------------------------------------------------------------------------------------------------------------------------------------------------------
            // second outputs
            File file;
            ByteArrayOutputStream byteArrayOutputStream= null;
            byteArrayOutputStream = new ByteArrayOutputStream();
            if (!photoAddress.equals("")) {
                file = new File(photoAddress);
                file.getParentFile().mkdirs();
                if (!file.exists()) {
                    file.createNewFile();
                }
                BufferedImage image = ImageIO.read(file);
                ImageIO.write(image, "jpg", byteArrayOutputStream);
            }
            if (response1.equals("Send the image.")){
                byte[] size = ByteBuffer.allocate(4).putInt(byteArrayOutputStream.size()).array();
                outputStream.write(size);
                outputStream.write(byteArrayOutputStream.toByteArray());
                outputStream.flush();
            }
            //----------------------------------------------------------------------------------------------------------------------------------------------------------------
            // second inputs
            Scanner input2 = new Scanner(socket.getInputStream());
            String response2= input2.nextLine();
            socket.close();
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }































    private Group getGroup(long groupId){
        try {
            Group group= null;
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{GroupController}"+"{getGroup}{"+groupId+"}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();


            if (!response.equals("null")) {
                String remaining = response;
                LinkedList<String> informationList = new LinkedList<>();

                while (!remaining.equals("")) {
                    String info = remaining.substring(remaining.indexOf('{') + 1, remaining.indexOf('}'));
                    informationList.add(info);

                    if (remaining.indexOf('}') + 1 == remaining.length()) {
                        remaining = "";
                    } else {
                        remaining = remaining.substring(remaining.indexOf('}') + 1);
                    }
                }

                long id= Long.parseLong(informationList.get(0));
                String name= informationList.get(1);

                group = new Group(name);
                group.setId(id);
            }

            socket.close();
            return group;
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}
