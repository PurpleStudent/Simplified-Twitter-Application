package group.listener;

import group.event.CreateGroupEvent;
import messagingPage.listener.MessagingPageListener;
import messagingPage.view.MessagingPageView;
import models.User;
import view.MainFrame;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class CreateGroupListener {

    //GroupController controller= new GroupController();
    MessagingPageView messagingPageView= new MessagingPageView();









    public void eventOccurred(CreateGroupEvent event){

        if (event.getButton().equals("create group")){
            createNewGroup(event.getGroupName());
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            messagingPageView.setStringListener(new MessagingPageListener());
            MainFrame.mainFrame.getContentPane().add(messagingPageView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }

    }































    private void createNewGroup ( String groupName ){
        try {
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));
            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);

            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{GroupController}"+"{createNewGroup}"+"{"+groupName+"}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response= input.nextLine();

            socket.close();
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
}
