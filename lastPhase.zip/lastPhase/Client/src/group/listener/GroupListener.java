package group.listener;

import group.event.GroupEvent;
import group.view.AddMemberView;
import group.view.AddMessageView;
import group.view.GroupMessageView;
import group.view.GroupView;
import message.listener.MessageListener;
import message.view.MessageView;
import messagingPage.listener.MessagingPageListener;
import messagingPage.view.MessagingPageView;
import models.DateTime;
import models.Group;
import models.Message;
import models.User;
import view.MainFrame;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.util.LinkedList;
import java.util.Scanner;

public class GroupListener {


    //GroupController controller= new GroupController();

    AddMemberView addMemberView;
    AddMessageView addMessageView;
    MessagingPageView messagingPageView= new MessagingPageView();
    GroupView groupView;
    GroupMessageView groupMessageView;









    public void eventOccurred(GroupEvent event){

        if (event.getButton().equals("previous")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            groupView = new GroupView ( getPreviousGroup(event.getCurrentGroupId()) );
            groupView.setListener(new GroupListener());
            MainFrame.mainFrame.getContentPane().add(groupView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }







        if (event.getButton().equals("next")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            groupView = new GroupView(getNextGroup(event.getCurrentGroupId()));
            groupView.setListener(new GroupListener());
            MainFrame.mainFrame.getContentPane().add(groupView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }









        if (event.getButton().equals("return to messaging page")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            messagingPageView.setStringListener(new MessagingPageListener());
            MainFrame.mainFrame.getContentPane().add(messagingPageView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }

        if (event.getButton().equals("add member")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            addMemberView= new AddMemberView(event.getCurrentGroupId());
            addMemberView.setListener(new AddMemberListener());
            MainFrame.mainFrame.getContentPane().add(addMemberView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }

        if (event.getButton().equals("add message")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            addMessageView= new AddMessageView(event.getCurrentGroupId());
            addMessageView.setListener(new AddMessageListener());
            MainFrame.mainFrame.getContentPane().add(addMessageView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }



        if (event.getButton().equals("see messages")){
            if (getLastMessageOfGroup(event.getCurrentGroupId())!=null) {
                MainFrame.mainFrame.getContentPane().removeAll();
                MainFrame.mainFrame.getContentPane().invalidate();
                groupMessageView = new GroupMessageView(
                        getLastMessageOfGroup(event.getCurrentGroupId()),
                        event.getCurrentGroupId(),
                        getMessageImage(getLastMessageOfGroup(event.getCurrentGroupId()).getId()),
                        getProfileImage(getLastMessageOfGroup(event.getCurrentGroupId()).getCreatorUserId())
                );
                groupMessageView.setListener(new GroupMessageListener());
                MainFrame.mainFrame.getContentPane().add(groupMessageView);
                MainFrame.mainFrame.getContentPane().revalidate();
                MainFrame.mainFrame.repaint();
            }
        }



        if (event.getButton().equals("leave group")){
            leaveGroup (event.getCurrentGroupId());
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            if ( getPreviousGroup (event.getCurrentGroupId()) !=null) {
                groupView= new GroupView ( getPreviousGroup ( event.getCurrentGroupId() ) ) ;
            }
            else {
                groupView = new GroupView ( getNextGroup (event.getCurrentGroupId() ) );
            }
            groupView.setListener(new GroupListener());
            MainFrame.mainFrame.getContentPane().add(groupView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }
    }































    private void leaveGroup(long groupId){
        try {
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{GroupController}"+"{leaveGroup}{"+groupId+"}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();

            socket.close();
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }








































    private Group getPreviousGroup( long currentGroupId ){
        try {
            Group group= null;
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{GroupController}"+"{getPreviousGroup}{"+currentGroupId+"}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();


            if (!response.equals("null")) {
                String remaining = response;
                LinkedList<String> informationList = new LinkedList<>();

                while (!remaining.equals("")) {
                    String info = remaining.substring(remaining.indexOf('{') + 1, remaining.indexOf('}'));
                    informationList.add(info);

                    if (remaining.indexOf('}') + 1 == remaining.length()) {
                        remaining = "";
                    } else {
                        remaining = remaining.substring(remaining.indexOf('}') + 1);
                    }
                }

                long id= Long.parseLong(informationList.get(0));
                String name= informationList.get(1);

                group = new Group(name);
                group.setId(id);
            }

            socket.close();
            return group;
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }































    private Group getNextGroup( long currentGroupId ){
        try {
            Group group= null;
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{GroupController}"+"{getNextGroup}{"+currentGroupId+"}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();


            if (!response.equals("null")) {
                String remaining = response;
                LinkedList<String> informationList = new LinkedList<>();

                while (!remaining.equals("")) {
                    String info = remaining.substring(remaining.indexOf('{') + 1, remaining.indexOf('}'));
                    informationList.add(info);

                    if (remaining.indexOf('}') + 1 == remaining.length()) {
                        remaining = "";
                    } else {
                        remaining = remaining.substring(remaining.indexOf('}') + 1);
                    }
                }

                long id= Long.parseLong(informationList.get(0));
                String name= informationList.get(1);

                group = new Group(name);
                group.setId(id);
            }

            socket.close();
            return group;
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }































    private Message getLastMessageOfGroup(long groupId){
        try {
            Message myMessage= null;
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{GroupController}"+"{getLastMessageOfGroup}{"+groupId+"}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();

            if (!response.equals("null")) {
                String remaining = response;
                LinkedList<String> informationList = new LinkedList<>();

                while (!remaining.equals("")) {
                    String info = remaining.substring(remaining.indexOf('{') + 1, remaining.indexOf('}'));
                    informationList.add(info);

                    if (remaining.indexOf('}') + 1 == remaining.length()) {
                        remaining = "";
                    } else {
                        remaining = remaining.substring(remaining.indexOf('}') + 1);
                    }
                }

                long creatorUserId = Long.parseLong(informationList.get(0));
                long recipientUserId = Long.parseLong(informationList.get(1));
                String creatorUsername = informationList.get(2);
                String recipientUsername = informationList.get(3);
                String text= informationList.get(4);
                long id= Long.parseLong(informationList.get(5));
                DateTime dateTimeOfCreation= DateTime.convertStringToDateTime(informationList.get(6));

                myMessage = new Message(creatorUserId, text, recipientUserId);
                myMessage.setId(id);
                myMessage.setCreatorUsername(creatorUsername);
                myMessage.setRecipientUsername(recipientUsername);
                myMessage.setDateTimeOfCreation(dateTimeOfCreation);

            }

            socket.close();
            return myMessage;
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }































    private BufferedImage getMessageImage(long messageId){
        try {
            // first outputs
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));
            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{GroupController}"+"{getMessageImage}{"+messageId+"}";
            output.println(message);
            //------------------------------------------------------------------------------------------------------------------------------------------------------------------
            // first inputs
            BufferedImage image= null;
            InputStream inputStream = socket.getInputStream();
            byte[] sizeAr = new byte[4];
            inputStream.read(sizeAr);
            int size = ByteBuffer.wrap(sizeAr).asIntBuffer().get();
            byte[] imageAr = new byte[size];
            inputStream.read(imageAr);
            image = ImageIO.read(new ByteArrayInputStream(imageAr));
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
            // second outputs
            PrintWriter output2 = new PrintWriter(socket.getOutputStream(), true);
            String message2 = "received.";
            output.println(message);
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------------
            // second inputs
            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();
            socket.close();
            return image;
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }































    private BufferedImage getProfileImage(long userid){
        try {
            // first outputs
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));
            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{GroupController}"+"{getProfileImage}{"+userid+"}";
            output.println(message);
            //------------------------------------------------------------------------------------------------------------------------------------------------------------------
            // first inputs
            BufferedImage image= null;
            InputStream inputStream = socket.getInputStream();
            byte[] sizeAr = new byte[4];
            inputStream.read(sizeAr);
            int size = ByteBuffer.wrap(sizeAr).asIntBuffer().get();
            byte[] imageAr = new byte[size];
            inputStream.read(imageAr);
            image = ImageIO.read(new ByteArrayInputStream(imageAr));
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
            // second outputs
            PrintWriter output2 = new PrintWriter(socket.getOutputStream(), true);
            String message2 = "received.";
            output.println(message);
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------------
            // second inputs
            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();
            socket.close();
            return image;
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}
