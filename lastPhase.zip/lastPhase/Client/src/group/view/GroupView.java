package group.view;

import group.event.GroupEvent;
import group.listener.GroupListener;
import models.Group;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GroupView extends JPanel implements ActionListener {


    Group group;

    JButton nextButton= new JButton("next");
    JButton previousButton= new JButton("previous");
    JButton returnToMessagingPage= new JButton("return to messaging page");
    JButton addMember= new JButton("add member");
    JButton addMessage= new JButton("add message");
    JButton seeMessages= new JButton("see messages");
    JButton leaveGroup= new JButton("leave group");

    private GroupListener listener;






















    public GroupView(Group group){
        this.setBackground(new Color(122, 229, 208));

        if (group!=null) {
            //
            previousButton.setBounds(10, 600, 20, 100);
            this.add(previousButton);
            previousButton.addActionListener(this);

            //
            nextButton.setBounds(50, 600, 20, 100);
            this.add(nextButton);
            nextButton.addActionListener(this);

            //
            addMember.setBounds(130,600,20,100);
            this.add(addMember);
            addMember.addActionListener(this);

            //
            addMessage.setBounds(130,600,20,100);
            this.add(addMessage);
            addMessage.addActionListener(this);

            //
            seeMessages.setBounds(130,600,20,100);
            this.add(seeMessages);
            seeMessages.addActionListener(this);

            //
            leaveGroup.setBounds(130,600,20,100);
            this.add(leaveGroup);
            leaveGroup.addActionListener(this);
        }

        //
        returnToMessagingPage.setBounds(90,600,20,100);
        this.add(returnToMessagingPage);
        returnToMessagingPage.addActionListener(this);

        this.group= group;
    }


















    public void setListener(GroupListener listener) {
        this.listener = listener;
    }








    @Override
    public void paint(Graphics g) {
        super.paint(g);
        Font myFont = new Font ("Bold Italic", Font.BOLD, 50);
        g.setFont (myFont);

        if (group!=null) {

            g.setColor(new Color(170, 51, 239));
            g.drawString("👥 " + "GROUP", 200, 300);


            g.setColor(new Color(236, 12, 135));
            g.drawString(group.getId() + ". " + group.getName(), 200, 400);

            g.setColor(new Color(8, 113, 241));

            g.fillRect(10, 10, 5, 730);
            g.fillRect(10, 10, 80, 5);
            g.fillRect(890, 10, 70, 5);
            g.fillRect(960, 10, 5, 735);
            g.fillRect(10, 740, 950, 5);
        }

        else {
            g.setColor(new Color(173, 29, 104));
            g.drawString("There are no groups", 250, 300);

            g.setColor(new Color(107, 18, 229));

            g.fillRect(10, 70, 5, 670);
            g.fillRect(10,70,950,5);
            g.fillRect(960, 70, 5, 675);
            g.fillRect(10, 740, 950, 5);
        }
    }










    @Override
    public void actionPerformed(ActionEvent e) {
        if (previousButton == (JButton) e.getSource()){
            GroupEvent event = new GroupEvent(this,"previous",group.getId());
            listener.eventOccurred(event);
            //ترای کچ بزنیم برای تکراری بودن اطلاعات
        }
        if (nextButton == (JButton) e.getSource()){
            GroupEvent event= new GroupEvent(this,"next",group.getId());
            listener.eventOccurred(event);
        }
        if (returnToMessagingPage == (JButton) e.getSource()){
            GroupEvent event;
            if (group==null){event= new GroupEvent(this,"return to messaging page",0);}
            else {event= new GroupEvent(this,"return to messaging page",group.getId());}
            listener.eventOccurred(event);
        }
        if (addMember == (JButton) e.getSource()){
            GroupEvent event;
            if (group==null){event= new GroupEvent(this,"add member",0);}
            else {event= new GroupEvent(this,"add member",group.getId());}
            listener.eventOccurred(event);
        }
        if (addMessage == (JButton) e.getSource()){
            GroupEvent event= new GroupEvent(this,"add message",group.getId());
            listener.eventOccurred(event);
        }
        if (seeMessages == (JButton) e.getSource()){
            GroupEvent event= new GroupEvent(this,"see messages",group.getId());
            listener.eventOccurred(event);
        }
        if ( leaveGroup == (JButton)e.getSource() ) {
            GroupEvent event= new GroupEvent(this,"leave group",group.getId());
            listener.eventOccurred(event);
        }
    }
}
