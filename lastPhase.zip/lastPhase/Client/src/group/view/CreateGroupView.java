package group.view;

import group.event.CreateGroupEvent;
import group.listener.CreateGroupListener;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CreateGroupView extends JPanel implements ActionListener {


    private final JTextField jTextField= new JTextField(70);
    private final JButton createGroup= new JButton("Create New Group");

    CreateGroupListener listener;


















    public CreateGroupView(){
        this.setBackground(new Color(52, 232, 226));
        Border innerBorder= BorderFactory.createTitledBorder("Enter the name of the new group: ");
        Border outerBorder= BorderFactory.createEmptyBorder(20,20,300,20);
        this.setBorder(BorderFactory.createCompoundBorder(outerBorder,innerBorder));
        this.setLayout(new GridBagLayout());
        GridBagConstraints gridBagConstraints= new GridBagConstraints();
        gridBagConstraints.weightx= 1;
        gridBagConstraints.weighty= 1;
        //jTextField
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.insets = new Insets(0, 0, 0, 5);
        gridBagConstraints.anchor = GridBagConstraints.LINE_END;
        this.add(new JLabel("name : "), gridBagConstraints);
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.insets = new Insets(0, 0, 0, 0);
        gridBagConstraints.anchor = GridBagConstraints.LINE_START;
        this.add(jTextField, gridBagConstraints);
        //createNewTweetButton
        gridBagConstraints.weightx = 1;
        gridBagConstraints.weighty = 2;
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 8;
        gridBagConstraints.insets = new Insets(0, 0, 0, 0);
        gridBagConstraints.anchor = GridBagConstraints.FIRST_LINE_START;
        this.add(createGroup, gridBagConstraints);
        createGroup.addActionListener(this);
    }


    public void setListener(CreateGroupListener listener) {
        this.listener = listener;
    }
    public String getTextField() {
        return jTextField.getText();
    }










    @Override
    public void paint(Graphics g) {
        super.paint(g);
        Font myFont = new Font ("Bold Italic", Font.BOLD, 50);
        g.setFont (myFont);

        g.setColor(new Color(241, 136, 8));
        g.drawString("🎀", 20, 600);

        g.setColor(new Color(241, 229, 8));
        g.drawString("🎀", 80, 600);

        g.setColor(new Color(152, 241, 8));
        g.drawString("🎀", 140, 600);

        g.setColor(new Color(8, 241, 31));
        g.drawString("🎀", 200, 600);

        g.setColor(new Color(8, 167, 241));
        g.drawString("🎀", 260, 600);

        g.setColor(new Color(8, 12, 241));
        g.drawString("🎀", 320, 600);

        g.setColor(new Color(241, 8, 218));
        g.drawString("🎀", 380, 600);

        g.setColor(new Color(241, 136, 8));
        g.drawString("🎀", 440, 600);

        g.setColor(new Color(241, 229, 8));
        g.drawString("🎀", 500, 600);

        g.setColor(new Color(152, 241, 8));
        g.drawString("🎀", 560, 600);

        g.setColor(new Color(8, 241, 31));
        g.drawString("🎀", 620, 600);

        g.setColor(new Color(8, 167, 241));
        g.drawString("🎀", 680, 600);

        g.setColor(new Color(8, 12, 241));
        g.drawString("🎀", 740, 600);

        g.setColor(new Color(241, 8, 218));
        g.drawString("🎀", 800, 600);

        g.setColor(new Color(241, 136, 8));
        g.drawString("🎀", 860, 600);
    }
























    @Override
    public void actionPerformed(ActionEvent e) {
        if (createGroup == (JButton) e.getSource()){
            CreateGroupEvent event= new CreateGroupEvent(this,"create group",getTextField());
            listener.eventOccurred(event);
        }
    }
}
