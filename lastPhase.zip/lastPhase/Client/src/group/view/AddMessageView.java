package group.view;

import group.event.AddMessageEvent;
import group.listener.AddMessageListener;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AddMessageView extends JPanel implements ActionListener {


    private final JTextField text= new JTextField(70);
    private final JTextField photoAddress= new JTextField(70);

    private final JButton writeNewMessage= new JButton("Add New Message");

    AddMessageListener listener;

    private long groupId;



















    public AddMessageView(long groupId){
        this.groupId= groupId;
        this.setBackground(new Color(215, 145, 234));
        Border innerBorder= BorderFactory.createTitledBorder("Enter the text of the new message: ");
        Border outerBorder= BorderFactory.createEmptyBorder(20,20,300,20);
        this.setBorder(BorderFactory.createCompoundBorder(outerBorder,innerBorder));
        this.setLayout(new GridBagLayout());
        GridBagConstraints gridBagConstraints= new GridBagConstraints();
        gridBagConstraints.weightx= 1;
        gridBagConstraints.weighty= 1;

        //1
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.insets = new Insets(0, 0, 0, 5);
        gridBagConstraints.anchor = GridBagConstraints.LINE_END;
        this.add(new JLabel("text : "), gridBagConstraints);
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.insets = new Insets(0, 0, 0, 0);
        gridBagConstraints.anchor = GridBagConstraints.LINE_START;
        this.add(text , gridBagConstraints);

        //2
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.insets = new Insets(0, 0, 0, 5);
        gridBagConstraints.anchor = GridBagConstraints.LINE_END;
        this.add(new JLabel("photo address : "), gridBagConstraints);
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.insets = new Insets(0, 0, 0, 0);
        gridBagConstraints.anchor = GridBagConstraints.LINE_START;
        this.add(photoAddress, gridBagConstraints);

        //3
        gridBagConstraints.weightx = 1;
        gridBagConstraints.weighty = 2;
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 5;
        gridBagConstraints.insets = new Insets(0, 0, 0, 0);
        gridBagConstraints.anchor = GridBagConstraints.FIRST_LINE_START;
        this.add(writeNewMessage, gridBagConstraints);
        writeNewMessage.addActionListener(this);
    }


























    public void setListener(AddMessageListener listener) {
        this.listener = listener;
    }


    public String getTextField() {
        return text.getText();
    }

    public String getPhotoAddress() {
        return photoAddress.getText();
    }












    @Override
    public void actionPerformed(ActionEvent e) {
        if (writeNewMessage == (JButton) e.getSource()){
            AddMessageEvent event= new AddMessageEvent(this,"write new message",getTextField(),groupId,getPhotoAddress());
            listener.eventOccurred(event);
        }
    }
}
