package group.view;

import group.event.GroupMessageEvent;
import group.listener.GroupMessageListener;
import models.Message;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;

public class GroupMessageView extends JPanel implements ActionListener {


    Message message;
    long groupId;

    BufferedImage messageImage;
    BufferedImage profileImage;

    JButton nextButton= new JButton("next");
    JButton previousButton= new JButton("previous");
    JButton returnToGroup= new JButton("return to group");
    //JButton writeNewMessage= new JButton("write new message");

    private GroupMessageListener listener;



















    public GroupMessageView(Message message, long groupId, BufferedImage messageImage, BufferedImage profileImage){
        this.setBackground(new Color(157, 234, 212));

        if (message!=null) {
            //
            previousButton.setBounds(10, 600, 20, 100);
            this.add(previousButton);
            previousButton.addActionListener(this);

            //
            nextButton.setBounds(50, 600, 20, 100);
            this.add(nextButton);
            nextButton.addActionListener(this);
        }

        //
        returnToGroup.setBounds(90,600,20,100);
        this.add(returnToGroup);
        returnToGroup.addActionListener(this);

        this.message= message;
        this.groupId= groupId;
        this.messageImage= messageImage;
        this.profileImage= profileImage;
    }





















    public void setListener(GroupMessageListener listener) {
        this.listener = listener;
    }















    @Override
    public void paint(Graphics g) {
        super.paint(g);
        Font myFont = new Font ("Bold Italic", Font.BOLD, 30);
        g.setFont (myFont);

        if (message!=null) {
            g.setColor(new Color(9, 112, 239, 255));
            g.drawString("🌼"+" GROUP MESSAGE", 100, 100);


            g.setColor(new Color(9, 112, 239, 255));
            g.drawString("sender : " + message.getCreatorUsername(), 180, 200);



            if (message.getRecipientUsername().equals("")) {
                g.setColor(new Color(126, 63, 213));
                g.drawString("recipient : null", 180, 250);
            }
            else {
                g.setColor(new Color(126, 63, 213));
                g.drawString("recipient : " + message.getRecipientUsername(), 180, 250);
            }





            g.setColor(new Color(51, 198, 18));
            g.drawString(message.getDateTimeOfCreation().toString(), 100, 350);




            g.setColor(new Color(18, 154, 123));
            g.drawString(message.getId() + ". " + message.getText(), 100, 400);

            g.setColor(new Color(220, 50, 75));

            g.fillRect(10, 10, 5, 730);
            g.fillRect(10, 10, 250, 5);
            g.fillRect(720, 10, 240, 5);
            g.fillRect(960, 10, 5, 735);
            g.fillRect(10, 740, 950, 5);
        }

        else {
            g.setColor(new Color(173, 29, 104));
            g.drawString("There are no messages", 300, 300);

            g.setColor(new Color(107, 18, 229));
            g.fillRect(10, 70, 5, 670);
            g.fillRect(10,70,950,5);
            g.fillRect(960, 70, 5, 675);
            g.fillRect(10, 740, 950, 5);
        }



        //image
        if (messageImage!=null) {
            g.drawImage(messageImage, 750, 530, 200, 200, null);
        }
        if (profileImage!=null) {
            g.drawImage(profileImage, 20, 150, 150, 150, null);
        }
    }



























    @Override
    public void actionPerformed(ActionEvent e) {
        if (previousButton == (JButton) e.getSource()){
            GroupMessageEvent event = new GroupMessageEvent(this,"previous",message.getId(),groupId);
            listener.eventOccurred(event);
            //ترای کچ بزنیم برای تکراری بودن اطلاعات
        }
        if (nextButton == (JButton) e.getSource()){
            GroupMessageEvent event= new GroupMessageEvent(this,"next",message.getId(),groupId);
            listener.eventOccurred(event);
        }
        if (returnToGroup == (JButton) e.getSource()){
            GroupMessageEvent event= new GroupMessageEvent(this,"return to group",message.getId(),groupId);
            listener.eventOccurred(event);
        }
    }
}
