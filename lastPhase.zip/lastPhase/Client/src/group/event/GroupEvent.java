package group.event;

import java.util.EventObject;

public class GroupEvent extends EventObject {

    String button;
    long currentGroupId;



    public GroupEvent(Object source, String button, long currentGroupId) {
        super(source);
        this.button= button;
        this.currentGroupId= currentGroupId;
    }

    public String getButton() {
        return button;
    }

    public long getCurrentGroupId() {
        return currentGroupId;
    }
}
