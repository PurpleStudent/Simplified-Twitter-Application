package group.event;

import java.util.EventObject;

public class AddMemberEvent extends EventObject {

    String button;
    String username;
    long groupId;



    public AddMemberEvent(Object source, String button, String username, long groupId) {
        super(source);
        this.button= button;
        this.username= username;
        this.groupId= groupId;
    }


    public String getButton() {
        return button;
    }

    public String getUsername() {
        return username;
    }

    public long getGroupId() {
        return groupId;
    }
}
