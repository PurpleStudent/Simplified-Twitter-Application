package group.event;

import java.util.EventObject;

public class CreateGroupEvent extends EventObject {


    String button;
    String groupName;


    public CreateGroupEvent(Object source, String button, String groupName) {
        super(source);
        this.button= button;
        this.groupName= groupName;
    }

    public String getButton() {
        return button;
    }

    public String getGroupName() {
        return groupName;
    }
}
