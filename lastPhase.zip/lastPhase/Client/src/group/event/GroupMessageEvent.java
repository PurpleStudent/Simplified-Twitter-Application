package group.event;

import java.util.EventObject;

public class GroupMessageEvent extends EventObject {


    String button;
    long currentMessageId;
    long groupId;


    public GroupMessageEvent(Object source, String button, long currentMessageId, long groupId) {
        super(source);
        this.button= button;
        this.currentMessageId= currentMessageId;
        this.groupId= groupId;
    }


    public String getButton() {
        return button;
    }

    public long getCurrentMessageId() {
        return currentMessageId;
    }

    public long getGroupId() {
        return groupId;
    }
}
