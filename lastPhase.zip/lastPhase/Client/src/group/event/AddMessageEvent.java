package group.event;

import java.util.EventObject;

public class AddMessageEvent extends EventObject {


    String button;
    String text;
    long groupId;
    String photoAddress;


    public AddMessageEvent(Object source, String button, String text, long groupId, String photoAddress) {
        super(source);
        this.button= button;
        this.text= text;
        this.groupId= groupId;
        this.photoAddress= photoAddress;
    }


    public String getButton() {
        return button;
    }

    public String getText() {
        return text;
    }

    public long getGroupId() {
        return groupId;
    }

    public String getPhotoAddress() {
        return photoAddress;
    }
}
