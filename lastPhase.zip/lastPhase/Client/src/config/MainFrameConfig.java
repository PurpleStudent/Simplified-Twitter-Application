package config;

public class MainFrameConfig {

    private int width;
    private int height;

    MainFrameConfig(){

    }


    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }
}
