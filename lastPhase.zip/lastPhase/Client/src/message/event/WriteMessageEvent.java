package message.event;

import models.Chat;

import java.util.EventObject;

public class WriteMessageEvent extends EventObject {

    private final long chatId;
    private final String text;
    private final long userId;
    private final String photoAddress;


    public WriteMessageEvent(Object source , long chatId , String text, long userId, String photoAddress) {
        super(source);
        this.chatId= chatId;
        this.text= text;
        this.userId = userId;
        this.photoAddress= photoAddress;
    }


    public long getChatId() {
        return chatId;
    }

    public String getText() {
        return text;
    }

    public long getUserId() {
        return userId;
    }

    public String getPhotoAddress() {
        return photoAddress;
    }
}
