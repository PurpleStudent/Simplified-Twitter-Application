package message.event;


import models.Chat;
import models.User;

import java.util.EventObject;

public class ChatEvent extends EventObject {


    String button;
    Chat chat;
    User user;

    public ChatEvent(Object source, String button, User user, Chat chat) {
        super(source);
        this.button= button;
        this.user= user;
        this.chat= chat;
    }


    public User getUser() {
        return user;
    }

    public String getButton() {
        return button;
    }

    public Chat getChat() {
        return chat;
    }
}
