package message.event;

import models.SystemMessage;

import java.util.EventObject;

public class SystemMessageEvent extends EventObject {

    String button;
    SystemMessage systemMessage;



    public SystemMessageEvent(Object source, String button,SystemMessage systemMessage) {
        super(source);
        this.button= button;
        this.systemMessage= systemMessage;
    }


    public String getButton() {
        return button;
    }

    public SystemMessage getSystemMessage() {
        return systemMessage;
    }
}
