package message.event;

import java.util.EventObject;

public class MessageEvent extends EventObject {


    long currentMessageId;
    long userId;
    String stringButton;


    public MessageEvent(Object source, long currentMessageId, long userId, String stringButton) {
        super(source);
        this.currentMessageId= currentMessageId;
        this.userId= userId;
        this.stringButton= stringButton;
    }

    public long getCurrentMessageId() {
        return currentMessageId;
    }

    public long getUserId() {
        return userId;
    }

    public String getStringButton() {
        return stringButton;
    }
}
