package message.event;

import java.util.EventObject;

public class SavedMessagePreviousNextEvent extends EventObject {


    long currentSavedMessageId;
    String stringButton;

    public SavedMessagePreviousNextEvent(Object source, long currentSavedMessageId, String stringButton) {
        super(source);
        this.currentSavedMessageId= currentSavedMessageId;
        this.stringButton= stringButton;
    }

    public long getCurrentSavedMessageId() {
        return currentSavedMessageId;
    }

    public String getStringButton() {
        return stringButton;
    }
}
