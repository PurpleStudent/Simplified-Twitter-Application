package message.view;

import message.event.MessageEvent;
import message.listener.MessageListener;
import models.Message;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;

public class MessageView extends JPanel implements ActionListener {


    Message message;

    BufferedImage messageImage;
    BufferedImage profileImage;

    long userId;

    JButton nextButton= new JButton("next");
    JButton previousButton= new JButton("previous");
    JButton returnToHomePage= new JButton("return to home page");
    JButton writeNewMessage= new JButton("write new message");
    JButton deleteMessage= new JButton("delete message");

    private MessageListener listener;



















    public MessageView(Message message, long userId, BufferedImage messageImage, BufferedImage profileImage){
        this.setBackground(new Color(157, 234, 212));

        if (message!=null) {
            //
            previousButton.setBounds(10, 600, 20, 100);
            this.add(previousButton);
            previousButton.addActionListener(this);

            //
            nextButton.setBounds(50, 600, 20, 100);
            this.add(nextButton);
            nextButton.addActionListener(this);

            //
            deleteMessage.setBounds(70, 600, 20, 100);
            this.add(deleteMessage);
            deleteMessage.addActionListener(this);
        }

        //
        returnToHomePage.setBounds(90,600,20,100);
        this.add(returnToHomePage);
        returnToHomePage.addActionListener(this);

        //
        writeNewMessage.setBounds(130,600,20,100);
        this.add(writeNewMessage);
        writeNewMessage.addActionListener(this);

        this.message= message;
        this.userId= userId;
        this.messageImage= messageImage;
        this.profileImage= profileImage;
    }





















    public void setListener(MessageListener listener) {
        this.listener = listener;
    }










    @Override
    public void paint(Graphics g) {
        super.paint(g);
        Font myFont = new Font ("Bold Italic", Font.BOLD, 30);
        g.setFont (myFont);

        if (message!=null) {
            g.setColor(new Color(234, 12, 180, 255));
            g.drawString( "💬 " +"MESSAGE", 100, 100);

            g.setColor(new Color(9, 112, 239, 255));
            g.drawString("sender : " + message.getCreatorUsername(), 180, 200);

            if (message.getRecipientUsername().equals("")) {    //important
                g.setColor(new Color(126, 63, 213));
                g.drawString("recipient : null", 180, 250);
            }
            else {
                g.setColor(new Color(126, 63, 213));
                g.drawString("recipient : " + message.getRecipientUsername(), 180, 250);
            }

            g.setColor(new Color(51, 198, 18));
            g.drawString(message.getDateTimeOfCreation().toString(), 100, 400);

            g.setColor(new Color(18, 154, 123));
            g.drawString(message.getId() + ". " + message.getText(), 100, 500);

            g.setColor(new Color(220, 50, 75));

            g.fillRect(10, 10, 5, 730);
            g.fillRect(10, 10, 150, 5);
            g.fillRect(820, 10, 140, 5);
            g.fillRect(960, 10, 5, 735);
            g.fillRect(10, 740, 950, 5);
        }

        else {
            g.setColor(new Color(173, 29, 104));
            g.drawString("There are no messages", 300, 300);

            g.setColor(new Color(107, 18, 229));

            g.fillRect(10, 70, 5, 670);
            g.fillRect(10,70,950,5);
            g.fillRect(960, 70, 5, 675);
            g.fillRect(10, 740, 950, 5);
        }

        //image
        if (messageImage!=null) {
            g.drawImage(messageImage, 750, 530, 200, 200, null);
        }
        if (profileImage!=null) {
            g.drawImage(profileImage, 20, 150, 150, 150, null);
        }
    }
























    @Override
    public void actionPerformed(ActionEvent e) {
        if (previousButton == (JButton) e.getSource()){
            MessageEvent event = new MessageEvent(this, message.getId(),userId,"previous");
            listener.eventOccurred(event);
            //ترای کچ بزنیم برای تکراری بودن اطلاعات
        }
        if (nextButton == (JButton) e.getSource()){
            MessageEvent event= new MessageEvent(this,message.getId(),userId,"next");
            listener.eventOccurred(event);
        }
        if (returnToHomePage == (JButton) e.getSource()){
            MessageEvent event= new MessageEvent(this,message.getId(),userId,"return to home page");
            listener.eventOccurred(event);
        }
        if (writeNewMessage == (JButton) e.getSource()){
            MessageEvent event;
            if (message==null){event= new MessageEvent(this,0,userId,"write new message");} //message id
            else {event= new MessageEvent(this,message.getId(),userId,"write new message");}
            listener.eventOccurred(event);
        }
        if (deleteMessage == (JButton) e.getSource()){
            MessageEvent event= new MessageEvent(this,message.getId(),userId,"delete message");
            listener.eventOccurred(event);
        }
    }
}
