package message.view;

import message.event.WriteMessageEvent;
import message.listener.WriteMessageListener;
import models.Chat;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class WriteNewMessageView extends JPanel implements ActionListener {


    private final JTextField text= new JTextField(70);
    private final JTextField photoAddress= new JTextField(70);

    private final JButton writeNewMessage= new JButton("Write New Message");

    WriteMessageListener listener;

    private final long chatId;
    private final long userId;



















    public WriteNewMessageView ( long chatId , long userId ){
        this.chatId= chatId;
        this.userId = userId;
        this.setBackground(new Color(245, 7, 233));
        Border innerBorder= BorderFactory.createTitledBorder("Enter the text of the new message: ");
        Border outerBorder= BorderFactory.createEmptyBorder(20,20,300,20);
        this.setBorder(BorderFactory.createCompoundBorder(outerBorder,innerBorder));
        this.setLayout(new GridBagLayout());
        GridBagConstraints gridBagConstraints= new GridBagConstraints();
        gridBagConstraints.weightx= 1;
        gridBagConstraints.weighty= 1;

        //1
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.insets = new Insets(0, 0, 0, 5);
        gridBagConstraints.anchor = GridBagConstraints.LINE_END;
        this.add(new JLabel("text : "), gridBagConstraints);
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.insets = new Insets(0, 0, 0, 0);
        gridBagConstraints.anchor = GridBagConstraints.LINE_START;
        this.add(text , gridBagConstraints);

        //2
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.insets = new Insets(0, 0, 0, 5);
        gridBagConstraints.anchor = GridBagConstraints.LINE_END;
        this.add(new JLabel("photo address : "), gridBagConstraints);
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.insets = new Insets(0, 0, 0, 0);
        gridBagConstraints.anchor = GridBagConstraints.LINE_START;
        this.add(photoAddress, gridBagConstraints);

        //3
        gridBagConstraints.weightx = 1;
        gridBagConstraints.weighty = 2;
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 5;
        gridBagConstraints.insets = new Insets(0, 0, 0, 0);
        gridBagConstraints.anchor = GridBagConstraints.FIRST_LINE_START;
        this.add(writeNewMessage, gridBagConstraints);
        writeNewMessage.addActionListener(this);
    }





























    public void setListener(WriteMessageListener listener) {
        this.listener = listener;
    }


    public String getTextField() {
        return text.getText();
    }

    public String getPhotoAddress() {
        return photoAddress.getText();
    }




    @Override
    public void actionPerformed(ActionEvent e) {
        if (writeNewMessage == (JButton) e.getSource()){
            WriteMessageEvent event= new WriteMessageEvent (this , chatId , getTextField() ,userId , getPhotoAddress() );
            listener.eventOccurred(event);
        }
    }
}
