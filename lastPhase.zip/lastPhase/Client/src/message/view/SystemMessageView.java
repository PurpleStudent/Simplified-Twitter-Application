package message.view;

import message.event.SystemMessageEvent;
import message.listener.SystemMessageListener;
import models.SystemMessage;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SystemMessageView extends JPanel implements ActionListener {


    SystemMessage systemMessage;


    JButton returnToAnnouncements= new JButton("return to announcements");
    JButton nextButton= new JButton("next");
    JButton previousButton= new JButton("previous");
    JButton logOut= new JButton("log out");
    JButton exit= new JButton("exit");

    private SystemMessageListener listener;
















    public SystemMessageView(SystemMessage systemMessage){
        this.setBackground(new Color(226, 214, 99));
        this.systemMessage= systemMessage;


        if (systemMessage!=null) {

            //
            previousButton.setBounds(50, 600, 20, 100);
            this.add(previousButton);
            previousButton.addActionListener(this);

            //
            nextButton.setBounds(50, 600, 20, 100);
            this.add(nextButton);
            nextButton.addActionListener(this);

        }

        //
        returnToAnnouncements.setBounds(90,600,20,100);
        this.add(returnToAnnouncements);
        returnToAnnouncements.addActionListener(this);

        //
        logOut.setBounds(90,600,20,100);
        this.add(logOut);
        logOut.addActionListener(this);

        //
        exit.setBounds(90,600,20,100);
        this.add(exit);
        exit.addActionListener(this);
    }


    public void setListener(SystemMessageListener listener) {
        this.listener = listener;
    }
















    @Override
    public void paint(Graphics g) {
        super.paint(g);
        Font myFont = new Font ("Bold Italic", Font.BOLD, 30);
        g.setFont (myFont);

        if (systemMessage!=null) {
            g.setColor(new Color(245, 36, 7));
            g.drawString("SYSTEM MESSAGE", 100, 200);

            g.setColor(new Color(126, 63, 213));
            g.drawString(systemMessage.getText(), 100, 300);

            g.setColor(new Color(126, 63, 213));
            g.drawString(systemMessage.getDateTimeOfCreation().toString(), 100, 400);
        }
        else {
            g.setColor(new Color(126, 63, 213));
            g.drawString("The list is empty", 100, 300);
        }

        g.setColor(new Color(144, 65, 219));

        g.fillRect(10, 70, 5, 670);
        g.fillRect(10,70,950,5);
        g.fillRect(960, 70, 5, 675);
        g.fillRect(10, 740, 950, 5);

    }























    @Override
    public void actionPerformed(ActionEvent e) {
        if (returnToAnnouncements == (JButton) e.getSource()){
            SystemMessageEvent event= new SystemMessageEvent(this,"returnToAnnouncements",systemMessage);
            listener.eventOccurred(event);
        }

        if (nextButton == (JButton) e.getSource()){
            SystemMessageEvent event= new SystemMessageEvent(this,"next",systemMessage);
            listener.eventOccurred(event);
        }
        if (previousButton == (JButton) e.getSource()){
            SystemMessageEvent event= new SystemMessageEvent(this,"previous",systemMessage);
            listener.eventOccurred(event);
        }
        if (logOut == (JButton) e.getSource()){
            SystemMessageEvent event= new SystemMessageEvent(this,"logOut",systemMessage);
            listener.eventOccurred(event);
        }
        if (exit == (JButton) e.getSource()){
            SystemMessageEvent event= new SystemMessageEvent(this,"exit",systemMessage);
            listener.eventOccurred(event);
        }
    }
}
