package message.view;

import message.event.ChatEvent;
import message.listener.ChatListener;
import models.Chat;
import models.User;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ChatView extends JPanel implements ActionListener {


    User user;

    /*String username;
    long userid;*/

    Chat chat;
    int numberOfUnreadMessages;

    JButton viewProfile= new JButton("view the profile");
    JButton returnToMessagingPage= new JButton("Return to messaging page");
    JButton nextButton= new JButton("next");
    JButton previousButton= new JButton("previous");
    JButton seeMessages= new JButton("see messages");
    JButton logOut= new JButton("log out");
    JButton exit= new JButton("exit");

    private ChatListener listener;
























    public ChatView(User user, Chat chat, int numberOfUnreadMessages){
        this.setBackground(new Color(226, 214, 99));
        this.user= user;
        /*this.username= username;
        this.userid= userid;*/

        this.chat= chat;
        this.numberOfUnreadMessages= numberOfUnreadMessages;

        if (user!=null) {
            //
            viewProfile.setBounds(50, 600, 20, 100);
            this.add(viewProfile);
            viewProfile.addActionListener(this);

            //
            previousButton.setBounds(50, 600, 20, 100);
            this.add(previousButton);
            previousButton.addActionListener(this);

            //
            nextButton.setBounds(50, 600, 20, 100);
            this.add(nextButton);
            nextButton.addActionListener(this);

            //
            seeMessages.setBounds(50, 600, 20, 100);
            this.add(seeMessages);
            seeMessages.addActionListener(this);
        }

        //
        returnToMessagingPage.setBounds(90,600,20,100);
        this.add(returnToMessagingPage);
        returnToMessagingPage.addActionListener(this);

        //
        logOut.setBounds(90,600,20,100);
        this.add(logOut);
        logOut.addActionListener(this);

        //
        exit.setBounds(90,600,20,100);
        this.add(exit);
        exit.addActionListener(this);
    }


    public void setListener(ChatListener listener) {
        this.listener = listener;
    }
















    @Override
    public void paint(Graphics g) {
        super.paint(g);
        Font myFont = new Font ("Bold Italic", Font.BOLD, 30);
        g.setFont (myFont);

        if (chat!=null) {
            g.setColor(new Color(245, 36, 7));
            g.drawString("💬 " +"CHAT", 100, 200);

            g.setColor(new Color(126, 63, 213));
            g.drawString (user.getUsername(), 100, 300);

            g.setColor(new Color(195, 11, 245));
            g.drawString("number of unread messages : "+numberOfUnreadMessages, 100, 400);
        }
        else {
            g.setColor(new Color(126, 63, 213));
            g.drawString("The list is empty", 100, 300);
        }

        g.setColor(new Color(144, 65, 219));

        g.fillRect(10, 70, 5, 670);
        g.fillRect(10,70,950,5);
        g.fillRect(960, 70, 5, 675);
        g.fillRect(10, 740, 950, 5);

    }























    @Override
    public void actionPerformed(ActionEvent e) {
        if (viewProfile == (JButton) e.getSource()){
            ChatEvent event= new ChatEvent(this,"view profile",user,chat);
            listener.eventOccurred(event);
        }
        if (returnToMessagingPage == (JButton) e.getSource()){
            ChatEvent event= new ChatEvent(this,"return to messaging page",user,chat);
            listener.eventOccurred(event);
        }
        if (nextButton == (JButton) e.getSource()){
            ChatEvent event= new ChatEvent(this,"next",user,chat);
            listener.eventOccurred(event);
        }
        if (previousButton == (JButton) e.getSource()){
            ChatEvent event= new ChatEvent(this,"previous",user,chat);
            listener.eventOccurred(event);
        }
        if (seeMessages == (JButton) e.getSource()){
            ChatEvent event= new ChatEvent(this,"see messages",user,chat);
            listener.eventOccurred(event);
        }
        if (logOut == (JButton) e.getSource()){
            ChatEvent event= new ChatEvent(this,"log out",user,chat);
            listener.eventOccurred(event);
        }
        if (exit == (JButton) e.getSource()){
            ChatEvent event= new ChatEvent(this,"exit",user,chat);
            listener.eventOccurred(event);
        }
    }
}
