package message.view;

import message.event.SavedMessagePreviousNextEvent;
import message.listener.SavedMessagePreviousNextListener;
import models.Message;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;

public class SavedMessageView extends JPanel implements ActionListener {


    Message message;
    BufferedImage image;

    JButton nextButton= new JButton("next");
    JButton previousButton= new JButton("previous");
    JButton returnToMessagingPage= new JButton("return to messaging page");

    private SavedMessagePreviousNextListener savedMessagePreviousNextListener;






















    public SavedMessageView(Message message, BufferedImage image){
        this.setBackground(new Color(180, 239, 223));

        //
        previousButton.setBounds(10,600,20,100);
        this.add(previousButton);
        previousButton.addActionListener(this);

        //
        nextButton.setBounds(50,600,20,100);
        this.add(nextButton);
        nextButton.addActionListener(this);

        //
        returnToMessagingPage.setBounds(90,600,20,100);
        this.add(returnToMessagingPage);
        returnToMessagingPage.addActionListener(this);

        this.message= message;
        this.image= image;
    }


    public void setSavedMessagePreviousNextListener(SavedMessagePreviousNextListener savedMessagePreviousNextListener) {
        this.savedMessagePreviousNextListener = savedMessagePreviousNextListener;
    }






















    @Override
    public void paint(Graphics g) {
        super.paint(g);
        Font myFont = new Font ("Bold Italic", Font.BOLD, 30);
        g.setFont (myFont);

        g.setColor(new Color(9, 112, 239, 255));
        g.drawString("✉"+"  SAVED MESSAGE", 100, 100);


        g.setColor(new Color(9, 112, 239, 255));
        g.drawString("sender : "+message.getCreatorUsername() , 100, 200);



        if (message.getRecipientUsername().equals("")) {
            g.setColor(new Color(126, 63, 213));
            g.drawString("recipient : null", 100, 250);
        }

        else {
            g.setColor(new Color(126, 63, 213));
            g.drawString("recipient : "+message.getRecipientUsername(), 100, 250);
        }




        g.setColor(new Color(51, 198, 18));
        g.drawString(message.getDateTimeOfCreation().toString(), 100, 300);





        g.setColor(new Color(18, 154, 123));
        g.drawString(message.getId()+". "+message.getText(), 100, 400);




        g.setColor(new Color(220, 50, 75));
        g.fillRect(10, 10, 5, 730);
        g.fillRect(10, 10, 310, 5);
        g.fillRect(660, 10, 300, 5);
        g.fillRect(960, 10, 5, 735);
        g.fillRect(10, 740, 950, 5);


        //image
        if (image!=null) {
            g.drawImage(image, 750, 530, 200, 200, null);
        }
    }















    @Override
    public void actionPerformed(ActionEvent e) {
        if (previousButton == (JButton) e.getSource()){
            SavedMessagePreviousNextEvent event = new SavedMessagePreviousNextEvent(this, message.getId(),"previous");
            savedMessagePreviousNextListener.eventOccurred(event);
            //ترای کچ بزنیم برای تکراری بودن اطلاعات
        }
        if (nextButton == (JButton) e.getSource()){
            SavedMessagePreviousNextEvent event= new SavedMessagePreviousNextEvent(this,message.getId(),"next");
            savedMessagePreviousNextListener.eventOccurred(event);
        }
        if (returnToMessagingPage == (JButton) e.getSource()){
            SavedMessagePreviousNextEvent event= new SavedMessagePreviousNextEvent(this,message.getId(),"return to messaging page");
            savedMessagePreviousNextListener.eventOccurred(event);
        }
    }
}
