package message.listener;

import message.event.WriteMessageEvent;
import message.view.MessageView;
import models.DateTime;
import models.Message;
import models.User;
import view.MainFrame;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.util.LinkedList;
import java.util.Scanner;

public class WriteMessageListener {

    //MessageController controller= new MessageController();
    MessageView messageView;






    public void eventOccurred(WriteMessageEvent event){

        MainFrame.mainFrame.getContentPane().removeAll();
        MainFrame.mainFrame.getContentPane().invalidate();
        Message message = createNewMessage ( event.getChatId() , event.getUserId() , event.getText(), event.getPhotoAddress() );
        messageView= new MessageView(
                message ,
                event.getUserId(),
                getMessageImage(message.getId()),
                getProfileImage(message.getCreatorUserId())
        );
        messageView.setListener(new MessageListener());
        MainFrame.mainFrame.getContentPane().add(messageView);
        MainFrame.mainFrame.getContentPane().revalidate();
        MainFrame.mainFrame.repaint();
    }































    private Message createNewMessage ( long chatId , long userId, String text, String photoAddress ) {
        try {
            Message myMessage= null;
            //----------------------------------------------------------------------------------------------------------------------------------------------------------------
            // first outputs
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));
            OutputStream outputStream= socket.getOutputStream();
            PrintWriter output = new PrintWriter( outputStream , true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{MessageController}"+"{createNewMessage}{"+chatId+"}{"+userId+"}{"+text+"}";
            output.println(message);
            //-----------------------------------------------------------------------------------------------------------------------------------------------------------------
            // first inputs
            Scanner input1 = new Scanner(socket.getInputStream());
            String response1= input1.nextLine();
            //-----------------------------------------------------------------------------------------------------------------------------------------------------------------
            // second outputs
            File file;
            ByteArrayOutputStream byteArrayOutputStream= null;
            byteArrayOutputStream = new ByteArrayOutputStream();
            if (!photoAddress.equals("")) {
                file = new File(photoAddress);
                file.getParentFile().mkdirs();
                if (!file.exists()) {
                    file.createNewFile();
                }
                BufferedImage image = ImageIO.read(file);
                ImageIO.write(image, "jpg", byteArrayOutputStream);
            }
            if (response1.equals("Send the image.")){
                byte[] size = ByteBuffer.allocate(4).putInt(byteArrayOutputStream.size()).array();
                outputStream.write(size);
                outputStream.write(byteArrayOutputStream.toByteArray());
                outputStream.flush();
            }
            //----------------------------------------------------------------------------------------------------------------------------------------------------------------
            // second inputs
            Scanner input2 = new Scanner(socket.getInputStream());
            String response2= input2.nextLine();
            System.out.println(response2);
            if (!response2.equals("null")) {
                String remaining = response2;
                LinkedList<String> informationList = new LinkedList<>();

                while (!remaining.equals("")) {
                    String info = remaining.substring(remaining.indexOf('{') + 1, remaining.indexOf('}'));
                    informationList.add(info);

                    if (remaining.indexOf('}') + 1 == remaining.length()) {
                        remaining = "";
                    } else {
                        remaining = remaining.substring(remaining.indexOf('}') + 1);
                    }
                }

                long creatorUserId = Long.parseLong(informationList.get(0));
                long recipientUserId = Long.parseLong(informationList.get(1));
                String creatorUsername = informationList.get(2);
                String recipientUsername = informationList.get(3);
                String myText= informationList.get(4);
                long id= Long.parseLong(informationList.get(5));
                DateTime dateTimeOfCreation= DateTime.convertStringToDateTime(informationList.get(6));

                myMessage = new Message(creatorUserId, myText, recipientUserId);
                myMessage.setId(id);
                myMessage.setCreatorUsername(creatorUsername);
                myMessage.setRecipientUsername(recipientUsername);
                myMessage.setDateTimeOfCreation(dateTimeOfCreation);

            }
            socket.close();
            return myMessage;
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }































    private BufferedImage getMessageImage(long messageId){
        try {
            // first outputs
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));
            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{MessageController}"+"{getMessageImage}{"+messageId+"}";
            output.println(message);
            //------------------------------------------------------------------------------------------------------------------------------------------------------------------
            // first inputs
            BufferedImage image= null;
            InputStream inputStream = socket.getInputStream();
            byte[] sizeAr = new byte[4];
            inputStream.read(sizeAr);
            int size = ByteBuffer.wrap(sizeAr).asIntBuffer().get();
            byte[] imageAr = new byte[size];
            inputStream.read(imageAr);
            image = ImageIO.read(new ByteArrayInputStream(imageAr));
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
            // second outputs
            PrintWriter output2 = new PrintWriter(socket.getOutputStream(), true);
            String message2 = "received.";
            output.println(message);
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------------
            // second inputs
            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();
            socket.close();
            return image;
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }































    private BufferedImage getProfileImage(long userid){
        try {
            // first outputs
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));
            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{MessageController}"+"{getProfileImage}{"+userid+"}";
            output.println(message);
            //------------------------------------------------------------------------------------------------------------------------------------------------------------------
            // first inputs
            BufferedImage image= null;
            InputStream inputStream = socket.getInputStream();
            byte[] sizeAr = new byte[4];
            inputStream.read(sizeAr);
            int size = ByteBuffer.wrap(sizeAr).asIntBuffer().get();
            byte[] imageAr = new byte[size];
            inputStream.read(imageAr);
            image = ImageIO.read(new ByteArrayInputStream(imageAr));
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
            // second outputs
            PrintWriter output2 = new PrintWriter(socket.getOutputStream(), true);
            String message2 = "received.";
            output.println(message);
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------------
            // second inputs
            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();
            socket.close();
            return image;
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}
