package message.listener;

import announcements.listener.AnnouncementsListener;
import announcements.view.AnnouncementsView;
import message.event.SystemMessageEvent;
import message.view.SystemMessageView;
import models.DateTime;
import models.Message;
import models.SystemMessage;
import models.User;
import view.MainFrame;
import view.MainPanel;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.LinkedList;
import java.util.Scanner;

public class SystemMessageListener {


    //MessageController controller= new MessageController();

    SystemMessageView systemMessageView;
    AnnouncementsView announcementsView= new AnnouncementsView();
    MainPanel mainPanel= new MainPanel();












    public void eventOccurred(SystemMessageEvent event){

        if (event.getButton().equals("next")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            systemMessageView= new SystemMessageView ( getNextSystemMessage (event.getSystemMessage().getId()) );
            systemMessageView.setListener(new SystemMessageListener());
            MainFrame.mainFrame.getContentPane().add(systemMessageView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }


        if (event.getButton().equals("previous")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            systemMessageView= new SystemMessageView ( getPreviousSystemMessage(event.getSystemMessage().getId()) );
            systemMessageView.setListener(new SystemMessageListener());
            MainFrame.mainFrame.getContentPane().add(systemMessageView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }


        if (event.getButton().equals("returnToAnnouncements")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            announcementsView.setStringListener(new AnnouncementsListener());
            MainFrame.mainFrame.getContentPane().add(announcementsView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }

        if (event.getButton().equals("logOut")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            MainFrame.mainFrame.getContentPane().add(mainPanel);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }

        if (event.getButton().equals("exit")){
            System.exit(0);
        }
    }































    private SystemMessage getNextSystemMessage( long currentSystemMessageId ) {
        try {
            SystemMessage systemMessage= null;
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{MessageController}"+"{getNextSystemMessage}{"+currentSystemMessageId+"}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();

            if (!response.equals("null")) {
                String remaining = response;
                LinkedList<String> informationList = new LinkedList<>();

                while (!remaining.equals("")) {
                    String info = remaining.substring(remaining.indexOf('{') + 1, remaining.indexOf('}'));
                    informationList.add(info);

                    if (remaining.indexOf('}') + 1 == remaining.length()) {
                        remaining = "";
                    } else {
                        remaining = remaining.substring(remaining.indexOf('}') + 1);
                    }
                }

                long recipientId = Long.parseLong(informationList.get(1));
                String text= informationList.get(4);
                long id= Long.parseLong(informationList.get(5));
                DateTime dateTimeOfCreation= DateTime.convertStringToDateTime(informationList.get(6));

                systemMessage = new SystemMessage(recipientId , text);
                systemMessage.setId(id);
                systemMessage.setDateTimeOfCreation(dateTimeOfCreation);
            }

            socket.close();
            return systemMessage;
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }































    private SystemMessage getPreviousSystemMessage( long currentSystemMessageId ) {
        try {
            SystemMessage systemMessage= null;
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{MessageController}"+"{getPreviousSystemMessage}{"+currentSystemMessageId+"}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();

            if (!response.equals("null")) {
                String remaining = response;
                LinkedList<String> informationList = new LinkedList<>();

                while (!remaining.equals("")) {
                    String info = remaining.substring(remaining.indexOf('{') + 1, remaining.indexOf('}'));
                    informationList.add(info);

                    if (remaining.indexOf('}') + 1 == remaining.length()) {
                        remaining = "";
                    } else {
                        remaining = remaining.substring(remaining.indexOf('}') + 1);
                    }
                }

                long recipientId = Long.parseLong(informationList.get(1));
                String text= informationList.get(4);
                long id= Long.parseLong(informationList.get(5));
                DateTime dateTimeOfCreation= DateTime.convertStringToDateTime(informationList.get(6));

                systemMessage = new SystemMessage(recipientId , text);
                systemMessage.setId(id);
                systemMessage.setDateTimeOfCreation(dateTimeOfCreation);
            }

            socket.close();
            return systemMessage;
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}
