package message.listener;

import homepage.listener.HomePageListener;
import homepage.view.HomePageView;
import message.event.MessageEvent;
import message.view.MessageView;
import message.view.WriteNewMessageView;
import models.Chat;
import models.DateTime;
import models.Message;
import models.User;
import view.MainFrame;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.util.LinkedList;
import java.util.Scanner;

public class MessageListener {


    //MessageController controller= new MessageController();
    HomePageView homePageView= new HomePageView();
    WriteNewMessageView writeNewMessageView;
    MessageView messageView;















    public void eventOccurred(MessageEvent event){

        if (event.getStringButton().equals("previous")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            messageView= new MessageView(
                    getPreviousChatMessage(event.getUserId(), event.getCurrentMessageId()),
                    event.getUserId(),
                    getMessageImage (getPreviousChatMessage(event.getUserId(), event.getCurrentMessageId()).getId()),
                    getProfileImage (getPreviousChatMessage(event.getUserId(), event.getCurrentMessageId()).getCreatorUserId())
            );
            messageView.setListener(new MessageListener());
            MainFrame.mainFrame.getContentPane().add(messageView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }




        if (event.getStringButton().equals("next")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            messageView= new MessageView(
                    getNextChatMessage(event.getUserId(),event.getCurrentMessageId()),
                    event.getUserId(),
                    getMessageImage(getNextChatMessage(event.getUserId(),event.getCurrentMessageId()).getId()),
                    getProfileImage(getNextChatMessage(event.getUserId(),event.getCurrentMessageId()).getCreatorUserId())
            );
            messageView.setListener(new MessageListener());
            MainFrame.mainFrame.getContentPane().add(messageView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }




        if (event.getStringButton().equals("return to home page")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            homePageView.setStringListener(new HomePageListener());
            MainFrame.mainFrame.getContentPane().add(homePageView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }



        if (event.getStringButton().equals("write new message")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            writeNewMessageView= new WriteNewMessageView ( getChatIdWithUserId(event.getUserId()) , event.getUserId() );
            writeNewMessageView.setListener(new WriteMessageListener());
            MainFrame.mainFrame.getContentPane().add(writeNewMessageView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }





        if (event.getStringButton().equals("delete message")){
            deleteMessage(event.getCurrentMessageId());
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            if (getPreviousChatMessage(event.getUserId(),event.getCurrentMessageId())!=null){
                messageView= new MessageView(
                        getPreviousChatMessage(event.getUserId(), event.getCurrentMessageId()),
                        event.getUserId(),
                        getMessageImage (getPreviousChatMessage(event.getUserId(), event.getCurrentMessageId()).getId()),
                        getProfileImage (getPreviousChatMessage(event.getUserId(), event.getCurrentMessageId()).getCreatorUserId())
                );
            }
            else {
                messageView = new MessageView(
                        getNextChatMessage(event.getUserId(), event.getCurrentMessageId()),
                        event.getUserId(),
                        getMessageImage (getNextChatMessage(event.getUserId(), event.getCurrentMessageId()).getId()),
                        getProfileImage (getNextChatMessage(event.getUserId(), event.getCurrentMessageId()).getCreatorUserId())
                );
            }
            messageView.setListener(new MessageListener());
            MainFrame.mainFrame.getContentPane().add(messageView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }
    }































    private Message getPreviousChatMessage( long userId, long currentMessageId ){
        try {
            Message myMessage= null;
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{MessageController}"+"{getPreviousChatMessage}{"+userId+"}{"+currentMessageId+"}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();

            if (!response.equals("null")) {
                String remaining = response;
                LinkedList<String> informationList = new LinkedList<>();

                while (!remaining.equals("")) {
                    String info = remaining.substring(remaining.indexOf('{') + 1, remaining.indexOf('}'));
                    informationList.add(info);

                    if (remaining.indexOf('}') + 1 == remaining.length()) {
                        remaining = "";
                    } else {
                        remaining = remaining.substring(remaining.indexOf('}') + 1);
                    }
                }

                long creatorUserId = Long.parseLong(informationList.get(0));
                long recipientUserId = Long.parseLong(informationList.get(1));
                String creatorUsername = informationList.get(2);
                String recipientUsername = informationList.get(3);
                String text= informationList.get(4);
                long id= Long.parseLong(informationList.get(5));
                DateTime dateTimeOfCreation= DateTime.convertStringToDateTime(informationList.get(6));

                myMessage = new Message(creatorUserId, text, recipientUserId);
                myMessage.setId(id);
                myMessage.setCreatorUsername(creatorUsername);
                myMessage.setRecipientUsername(recipientUsername);
                myMessage.setDateTimeOfCreation(dateTimeOfCreation);

            }

            socket.close();
            return myMessage;
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }































    private Message getNextChatMessage( long userId, long currentMessageId ){
        try {
            Message myMessage= null;
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{MessageController}"+"{getNextChatMessage}{"+userId+"}{"+currentMessageId+"}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();

            if (!response.equals("null")) {
                String remaining = response;
                LinkedList<String> informationList = new LinkedList<>();

                while (!remaining.equals("")) {
                    String info = remaining.substring(remaining.indexOf('{') + 1, remaining.indexOf('}'));
                    informationList.add(info);

                    if (remaining.indexOf('}') + 1 == remaining.length()) {
                        remaining = "";
                    } else {
                        remaining = remaining.substring(remaining.indexOf('}') + 1);
                    }
                }

                long creatorUserId = Long.parseLong(informationList.get(0));
                long recipientUserId = Long.parseLong(informationList.get(1));
                String creatorUsername = informationList.get(2);
                String recipientUsername = informationList.get(3);
                String text= informationList.get(4);
                long id= Long.parseLong(informationList.get(5));
                DateTime dateTimeOfCreation= DateTime.convertStringToDateTime(informationList.get(6));

                myMessage = new Message(creatorUserId, text, recipientUserId);
                myMessage.setId(id);
                myMessage.setCreatorUsername(creatorUsername);
                myMessage.setRecipientUsername(recipientUsername);
                myMessage.setDateTimeOfCreation(dateTimeOfCreation);

            }

            socket.close();
            return myMessage;
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }































    private BufferedImage getMessageImage(long messageId){
        try {
            // first outputs
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));
            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{MessageController}"+"{getMessageImage}{"+messageId+"}";
            output.println(message);
            //------------------------------------------------------------------------------------------------------------------------------------------------------------------
            // first inputs
            BufferedImage image= null;
            InputStream inputStream = socket.getInputStream();
            byte[] sizeAr = new byte[4];
            inputStream.read(sizeAr);
            int size = ByteBuffer.wrap(sizeAr).asIntBuffer().get();
            byte[] imageAr = new byte[size];
            inputStream.read(imageAr);
            image = ImageIO.read(new ByteArrayInputStream(imageAr));
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
            // second outputs
            PrintWriter output2 = new PrintWriter(socket.getOutputStream(), true);
            String message2 = "received.";
            output.println(message);
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------------
            // second inputs
            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();
            socket.close();
            return image;
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }































    private BufferedImage getProfileImage(long userid){
        try {
            // first outputs
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));
            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{MessageController}"+"{getProfileImage}{"+userid+"}";
            output.println(message);
            //------------------------------------------------------------------------------------------------------------------------------------------------------------------
            // first inputs
            BufferedImage image= null;
            InputStream inputStream = socket.getInputStream();
            byte[] sizeAr = new byte[4];
            inputStream.read(sizeAr);
            int size = ByteBuffer.wrap(sizeAr).asIntBuffer().get();
            byte[] imageAr = new byte[size];
            inputStream.read(imageAr);
            image = ImageIO.read(new ByteArrayInputStream(imageAr));
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
            // second outputs
            PrintWriter output2 = new PrintWriter(socket.getOutputStream(), true);
            String message2 = "received.";
            output.println(message);
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------------
            // second inputs
            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();
            socket.close();
            return image;
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }































    private void deleteMessage(long messageId){
        try {
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{MessageController}"+"{deleteMessage}{"+messageId+"}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();

            socket.close();
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }































    private long getChatIdWithUserId(long userId){
        try {
            long chatId= 0;
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{MessageController}"+"{getChatWithUserId}{"+userId+"}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();

            if (!response.equals("null")) {
                String remaining = response;
                LinkedList<String> informationList = new LinkedList<>();

                while (!remaining.equals("")) {
                    String info = remaining.substring(remaining.indexOf('{') + 1, remaining.indexOf('}'));
                    informationList.add(info);

                    if (remaining.indexOf('}') + 1 == remaining.length()) {
                        remaining = "";
                    } else {
                        remaining = remaining.substring(remaining.indexOf('}') + 1);
                    }
                }

                long user1id = Long.parseLong(informationList.get(0));
                long user2id = Long.parseLong(informationList.get(1));
                //DateTime dateTimeOfCreation= DateTime.convertStringToDateTime(informationList.get(3));

                //chat = new Chat(user1id,user2id);
                //chat.setId(id);
                //chat.setDateTimeOfCreation(dateTimeOfCreation);
                chatId= Long.parseLong(informationList.get(2));
            }

            socket.close();
            return chatId;
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return -1;
    }
}
