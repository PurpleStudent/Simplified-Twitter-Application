package view;

import authentication.event.LoginFormEvent;
import authentication.listener.LoginFormListener;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ConnectToServerView extends JPanel implements ActionListener {

    private final JTextField port= new JTextField(20);
    private final JTextField address= new JTextField(20);

    private final JButton connect= new JButton("Connect To Server");

    private ConnectToServerListener listener;












    public ConnectToServerView(){
        Border innerBorder = BorderFactory.createTitledBorder("Connect To Server");
        Border outerBoarder = BorderFactory.createEmptyBorder(30, 30, 50, 30);
        this.setBorder(BorderFactory.createCompoundBorder(outerBoarder, innerBorder));
        this.setLayout(new GridBagLayout());
        GridBagConstraints gridBagConstraints = new GridBagConstraints();
        gridBagConstraints.weightx = 1;
        gridBagConstraints.weighty = 0.5;

        //1
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.insets = new Insets(0, 0, 0, 7);
        gridBagConstraints.anchor = GridBagConstraints.LINE_END;
        this.add(new JLabel("port: "), gridBagConstraints);
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.insets = new Insets(0, 0, 0, 7);
        gridBagConstraints.anchor = GridBagConstraints.LINE_START;
        this.add(port, gridBagConstraints);

        //2
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.insets = new Insets(0, 0, 0, 7);
        gridBagConstraints.anchor = GridBagConstraints.LINE_END;
        this.add(new JLabel("address: "), gridBagConstraints);
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.insets = new Insets(0, 0, 0, 0);
        gridBagConstraints.anchor = GridBagConstraints.LINE_START;
        this.add(address, gridBagConstraints);

        //3
        gridBagConstraints.weightx = 1;
        gridBagConstraints.weighty = 2;
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 5;
        gridBagConstraints.insets = new Insets(0, 0, 0, 0);
        gridBagConstraints.anchor = GridBagConstraints.FIRST_LINE_START;
        this.add(connect, gridBagConstraints);
        connect.addActionListener(this);
    }





    public String getPort() { return port.getText(); }
    public String getAddress() { return address.getText(); }


    public void setListener(ConnectToServerListener listener) {
        this.listener = listener;
    }






    @Override
    public void actionPerformed(ActionEvent e) {
        if (connect == (JButton) e.getSource()){
            ConnectToServerEvent event= new ConnectToServerEvent(this,getPort(),getAddress());
            listener.eventOccurred(event);
            //ترای کچ بزنیم برای تکراری بودن اطلاعات
        }
    }
}
