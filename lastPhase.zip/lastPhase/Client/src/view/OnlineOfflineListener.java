package view;

import listener.StringListener;

import java.net.Socket;

public class OnlineOfflineListener implements StringListener {

    ConnectToServerView connectToServerView= new ConnectToServerView();



    @Override
    public void stringEventOccurred(String string) {
        if (string.equals("online")){

            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            connectToServerView.setListener(new ConnectToServerListener());
            MainFrame.mainFrame.getContentPane().add(connectToServerView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }

        if (string.equals("offline")){

        }
    }
}
