package view;

import config.MainFrameConfig;

import javax.swing.*;

public class MainFrame extends JFrame {



    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new MainFrame();
            }
        });
    }






    public static MainFrame mainFrame= null; //پرایوت را برداشتم و پابلیک کردم
    private MainPanel mainPanel= new MainPanel();
    private OnlineOfflinePanel onlineOfflinePanel= new OnlineOfflinePanel();
    private MainFrameConfig mainFrameConfig;





    public MainFrame(){
        super("social network");
        this.setVisible(true);
        //this.setSize(mainFrameConfig.getWidth(),mainFrameConfig.getHeight()); //1000 800
        this.setSize(1000,800);
        this.setResizable(false);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        mainFrame= this;

        /*this.getContentPane().add(mainPanel);
        this.getContentPane().revalidate();*/
        this.getContentPane().invalidate();
        onlineOfflinePanel.setStringListener(new OnlineOfflineListener());
        MainFrame.mainFrame.getContentPane().add(onlineOfflinePanel);
        MainFrame.mainFrame.getContentPane().revalidate();
        MainFrame.mainFrame.repaint();
    }







    public static void refreshFrame(){
        SwingUtilities.updateComponentTreeUI(mainFrame);
    }
}
