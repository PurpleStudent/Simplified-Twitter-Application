package view;

import listener.StringListener;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class OnlineOfflinePanel extends JPanel implements ActionListener {

    private final JButton online= new JButton("online"+ "   ✅");
    private final JButton offline= new JButton("offline"+ "   ✅");

    private StringListener stringListener;




    public OnlineOfflinePanel(){
        this.setBackground(Color.yellow);
        this.setLayout(new GridLayout(2,1));

        this.add(online);
        this.add(offline);

        online.addActionListener(this);
        offline.addActionListener(this);
    }









    public void setStringListener(StringListener stringListener) {
        this.stringListener = stringListener;
    }








    @Override
    public void actionPerformed(ActionEvent e) {
        if (online == (JButton) e.getSource()){
            stringListener.stringEventOccurred("online");
        }
        if (offline == (JButton) e.getSource()){
            stringListener.stringEventOccurred("offline");
        }
    }
}
