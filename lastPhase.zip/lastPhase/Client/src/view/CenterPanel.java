package view;

import javax.swing.*;
import java.awt.*;

public class CenterPanel extends JPanel {
    public CenterPanel(){
        this.setLayout(new BorderLayout());
    }
}
