package view;

import authentication.listener.LoginFormListener;
import authentication.listener.RegistrationFormListener;
import authentication.view.LoginView;
import authentication.view.RegistrationView;
import listener.StringListener;

public class CenterToToolbarStringListener implements StringListener {

    CenterPanel centerPanel;
    RegistrationView registrationView= new RegistrationView();
    LoginView loginView= new LoginView();



    CenterToToolbarStringListener(CenterPanel centerPanel){
        this.centerPanel= centerPanel;
    }



    @Override
    public void stringEventOccurred(String string) {
        if (string.equals("registration")){
            centerPanel.removeAll();
            registrationView.setFormListener(new RegistrationFormListener());
            centerPanel.add(registrationView);
        }
        if (string.equals("login")){
            centerPanel.removeAll();
            loginView.setLoginFormListener(new LoginFormListener());
            centerPanel.add(loginView);
        }
    }


}
