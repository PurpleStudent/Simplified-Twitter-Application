package view;

import java.util.EventObject;

public class ConnectToServerEvent extends EventObject {


    private String port;
    private String address;





    public ConnectToServerEvent(Object source, String port, String address) {
        super(source);
        this.port= port;
        this.address= address;
    }


    public String getPort() {
        return port;
    }

    public String getAddress() {
        return address;
    }
}
