package view;

import authentication.event.LoginFormEvent;
import homepage.view.HomePageView;
import models.User;

import javax.jws.soap.SOAPBinding;

public class ConnectToServerListener {

    MainPanel mainPanel= new MainPanel();



    public void eventOccurred(ConnectToServerEvent event){
        User.port= event.getPort();
        User.ipAddress= event.getAddress();

        MainFrame.mainFrame.getContentPane().removeAll();
        MainFrame.mainFrame.getContentPane().invalidate();
        MainFrame.mainFrame.getContentPane().add(mainPanel);
        MainFrame.mainFrame.getContentPane().revalidate();
        MainFrame.mainFrame.repaint();

    }
}
