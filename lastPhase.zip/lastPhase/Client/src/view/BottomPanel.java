package view;

import javax.swing.*;
import java.awt.*;

public class BottomPanel extends JPanel {

    private JLabel label= new JLabel();

    public BottomPanel(){
        this.setBackground(new Color(241, 47, 232, 203));
        this.add(label);
    }

    public void setText(String text){
        label.setText(text);
    }
}
