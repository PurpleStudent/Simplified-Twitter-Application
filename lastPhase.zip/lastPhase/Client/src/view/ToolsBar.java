package view;

import listener.StringListener;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.LinkedList;

public class ToolsBar extends JPanel implements ActionListener {

    private JButton registrationButton;
    private JButton loginButton;

    private LinkedList<StringListener> stringListeners = new LinkedList<>();

    ToolsBar(){
        this.setBackground(new Color(238, 6, 188));
        this.setLayout(new FlowLayout(FlowLayout.LEFT)); //میتونی لی اوت نال بدی و خودت مختصات اجزا رو مشخص کنی

        registrationButton= new JButton("register");
        registrationButton.setPreferredSize(new Dimension(85,35));
        this.add(registrationButton);
        registrationButton.addActionListener(this);

        loginButton= new JButton("log in");
        loginButton.setPreferredSize(new Dimension(85,35));
        this.add(loginButton);
        loginButton.addActionListener(this);

    }

    public void addListener(StringListener stringListener){
        stringListeners.add(stringListener);
    }





    @Override
    public void actionPerformed(ActionEvent e) {
        for (StringListener stringListener : stringListeners) {
            if (registrationButton == (JButton) e.getSource()){
                stringListener.stringEventOccurred("registration");
            }
            if (loginButton == (JButton) e.getSource()){
                stringListener.stringEventOccurred("login");
            }
        }
    }
}
