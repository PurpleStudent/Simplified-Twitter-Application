package editProfilePage.view;

import editProfilePage.event.ChangeEvent;
import editProfilePage.listener.ChangeListener;
import models.Date;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ChangeDateOfBirthView extends JPanel implements ActionListener {

    private final JTextField dayField= new JTextField(5);
    private final JTextField monthField= new JTextField(5);
    private final JTextField yearField= new JTextField(5);


    private final JButton change= new JButton("Change");

    private ChangeListener listener;








    public ChangeDateOfBirthView(){
        this.setBackground(new Color(255, 225, 127));
        Border innerBorder= BorderFactory.createTitledBorder("Change Date Of Birth");
        Border outerBorder= BorderFactory.createEmptyBorder(20,20,20,20);
        this.setBorder(BorderFactory.createCompoundBorder(outerBorder,innerBorder));

        this.setLayout(new GridBagLayout());
        GridBagConstraints gridBagConstraints= new GridBagConstraints();

        gridBagConstraints.weightx= 0.5;
        gridBagConstraints.weighty= 1;


        //6
        gridBagConstraints.gridx = 3;
        gridBagConstraints.gridy = 5;
        gridBagConstraints.insets = new Insets(0, 0, 0, 5);
        gridBagConstraints.anchor = GridBagConstraints.LINE_END;
        this.add(new JLabel("day: "), gridBagConstraints);

        gridBagConstraints.gridx = 4;
        gridBagConstraints.gridy = 5;
        gridBagConstraints.insets = new Insets(0, 0, 0, 0);
        gridBagConstraints.anchor = GridBagConstraints.LINE_START;
        this.add(dayField, gridBagConstraints);

        //7
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 5;
        gridBagConstraints.insets = new Insets(0, 0, 0, 5);
        gridBagConstraints.anchor = GridBagConstraints.LINE_END;
        this.add(new JLabel("month: "), gridBagConstraints);

        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 5;
        gridBagConstraints.insets = new Insets(0, 0, 0, 0);
        gridBagConstraints.anchor = GridBagConstraints.LINE_START;
        this.add(monthField, gridBagConstraints);

        //8
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 5;
        gridBagConstraints.insets = new Insets(0, 0, 0, 5);
        gridBagConstraints.anchor = GridBagConstraints.LINE_END;
        this.add(new JLabel("date of birth:    year: "), gridBagConstraints);

        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 5;
        gridBagConstraints.insets = new Insets(0, 0, 0, 0);
        gridBagConstraints.anchor = GridBagConstraints.LINE_START;
        this.add(yearField, gridBagConstraints);

        //11
        gridBagConstraints.weightx = 1;
        gridBagConstraints.weighty = 2;

        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 8;
        gridBagConstraints.insets = new Insets(0, 0, 0, 0);
        gridBagConstraints.anchor = GridBagConstraints.FIRST_LINE_START;
        this.add(change, gridBagConstraints);

        change.addActionListener(this);
    }











    public String getDayField() {
        return dayField.getText();
    }

    public String getMonthField() {
        return monthField.getText();
    }

    public String getYearField() {
        return yearField.getText();
    }


    public void setListener(ChangeListener listener) {
        this.listener = listener;
    }








    @Override
    public void actionPerformed(ActionEvent e) {
        if (change == (JButton) e.getSource()){
            Date date= new Date(Integer.parseInt(getYearField()),Integer.parseInt(getMonthField()),Integer.parseInt(getDayField()));
            ChangeEvent event= new ChangeEvent(this,"date of birth","",date);
            listener.changeOccurred(event);
            //ترای کچ بزنیم برای تکراری بودن اطلاعات
        }
    }
}
