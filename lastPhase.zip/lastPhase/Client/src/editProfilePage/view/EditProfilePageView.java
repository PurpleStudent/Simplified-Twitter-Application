package editProfilePage.view;

import listener.StringListener;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class EditProfilePageView extends JPanel implements ActionListener {


    private final JButton changeFirstNameButton= new JButton("Change my first name");
    private final JButton changeLastNameButton= new JButton("Change my last name");
    private final JButton changeUsernameButton= new JButton("Change my username");
    private final JButton changeDateOfBirthButton= new JButton("Change my date of birth");
    private final JButton changeEmailButton= new JButton("Change my email");
    private final JButton changePhoneNumberButton= new JButton("Change my phone number");
    private final JButton changeBiographyButton= new JButton("Change my biography");
    private final JButton selectAndChangeProfilePicture= new JButton("Select and change profile picture");
    private final JButton backToPersonalPageButton= new JButton("Back to personal page");


    private StringListener stringListener;





    public EditProfilePageView(){
        this.setBackground(Color.yellow);
        this.setLayout(new GridLayout(9,1));

        this.add(changeFirstNameButton);
        this.add(changeLastNameButton);
        this.add(changeUsernameButton);
        this.add(changeDateOfBirthButton);
        this.add(changeEmailButton);
        this.add(changePhoneNumberButton);
        this.add(changeBiographyButton);
        this.add(selectAndChangeProfilePicture);
        this.add(backToPersonalPageButton);

        changeFirstNameButton.addActionListener(this);
        changeLastNameButton.addActionListener(this);
        changeUsernameButton.addActionListener(this);
        changeDateOfBirthButton.addActionListener(this);
        changeEmailButton.addActionListener(this);
        changePhoneNumberButton.addActionListener(this);
        changeBiographyButton.addActionListener(this);
        selectAndChangeProfilePicture.addActionListener(this);
        backToPersonalPageButton.addActionListener(this);
    }


    public void setStringListener(StringListener stringListener) {
        this.stringListener = stringListener;
    }













    @Override
    public void actionPerformed(ActionEvent e) {
        if (changeFirstNameButton == (JButton) e.getSource()){
            stringListener.stringEventOccurred("Change my first name");
        }
        if (changeLastNameButton == (JButton) e.getSource()){
            stringListener.stringEventOccurred("Change my last name");
        }
        if (changeUsernameButton == (JButton) e.getSource()){
            stringListener.stringEventOccurred("Change my username");
        }
        if (changeDateOfBirthButton == (JButton) e.getSource()){
            stringListener.stringEventOccurred("Change my date of birth");
        }
        if (changeEmailButton == (JButton) e.getSource()){
            stringListener.stringEventOccurred("Change my email");
        }
        if (changePhoneNumberButton == (JButton) e.getSource()){
            stringListener.stringEventOccurred("Change my phone number");
        }
        if (changeBiographyButton == (JButton) e.getSource()){
            stringListener.stringEventOccurred("Change my biography");
        }
        if (selectAndChangeProfilePicture == (JButton) e.getSource()){
            stringListener.stringEventOccurred("select And Change Profile Picture");
        }
        if (backToPersonalPageButton == (JButton) e.getSource()){
            stringListener.stringEventOccurred("Back to personal page");
        }
    }
}
