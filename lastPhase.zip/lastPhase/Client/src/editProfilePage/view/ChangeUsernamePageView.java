package editProfilePage.view;

import editProfilePage.event.ChangeEvent;
import editProfilePage.listener.ChangeListener;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ChangeUsernamePageView extends JPanel implements ActionListener {

    private final JTextField jTextField= new JTextField(70);
    private final JButton changeUsernameButton= new JButton("change username");

    ChangeListener changeListener;




    public ChangeUsernamePageView(){
        this.setBackground(new Color(164, 142, 243));
        Border innerBorder= BorderFactory.createTitledBorder("Enter new username: ");
        Border outerBorder= BorderFactory.createEmptyBorder(20,20,300,20);
        this.setBorder(BorderFactory.createCompoundBorder(outerBorder,innerBorder));
        this.setLayout(new GridBagLayout());
        GridBagConstraints gridBagConstraints= new GridBagConstraints();
        gridBagConstraints.weightx= 1;
        gridBagConstraints.weighty= 1;
        //jTextField
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.insets = new Insets(0, 0, 0, 5);
        gridBagConstraints.anchor = GridBagConstraints.LINE_END;
        this.add(new JLabel("new username: "), gridBagConstraints);
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.insets = new Insets(0, 0, 0, 0);
        gridBagConstraints.anchor = GridBagConstraints.LINE_START;
        this.add(jTextField, gridBagConstraints);
        //createNewTweetButton
        gridBagConstraints.weightx = 1;
        gridBagConstraints.weighty = 2;
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 8;
        gridBagConstraints.insets = new Insets(0, 0, 0, 0);
        gridBagConstraints.anchor = GridBagConstraints.FIRST_LINE_START;
        this.add(changeUsernameButton, gridBagConstraints);
        changeUsernameButton.addActionListener(this);
    }


    public void setChangeListener(ChangeListener changeListener) {
        this.changeListener = changeListener;
    }

    public String getTextField() {
        return jTextField.getText();
    }




    @Override
    public void actionPerformed(ActionEvent e) {
        if (changeUsernameButton == (JButton) e.getSource()){
            ChangeEvent changeEvent= new ChangeEvent(this, "username", getTextField(),null);
            changeListener.changeOccurred(changeEvent);
        }
    }
}
