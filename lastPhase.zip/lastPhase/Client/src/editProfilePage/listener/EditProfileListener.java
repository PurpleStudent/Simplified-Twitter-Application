package editProfilePage.listener;

import editProfilePage.view.*;
import listener.StringListener;
import personalPage.listener.PersonalPageListener;
import personalPage.view.PersonalPageView;
import view.MainFrame;

public class EditProfileListener implements StringListener {


    ChangeFirstNamePageView changeFirstNamePageView= new ChangeFirstNamePageView();
    ChangeLastNamePageView changeLastNamePageView= new ChangeLastNamePageView();
    ChangeUsernamePageView changeUsernamePageView= new ChangeUsernamePageView();
    ChangeEmailPageView changeEmailPageView= new ChangeEmailPageView();
    ChangePhoneNumberPageView changePhoneNumberPageView= new ChangePhoneNumberPageView();
    ChangeBiographyPageView changeBiographyPageView= new ChangeBiographyPageView();
    ChangeDateOfBirthView changeDateOfBirthView= new ChangeDateOfBirthView();
    PersonalPageView personalPageView= new PersonalPageView();
    SelectProfilePictureView selectProfilePictureView= new SelectProfilePictureView();





    @Override
    public void stringEventOccurred(String string) {

        if (string.equals("Change my first name")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            changeFirstNamePageView.setChangeListener(new ChangeListener());
            MainFrame.mainFrame.getContentPane().add(changeFirstNamePageView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }

        if (string.equals("Change my last name")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            changeLastNamePageView.setChangeListener(new ChangeListener());
            MainFrame.mainFrame.getContentPane().add(changeLastNamePageView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }

        if (string.equals("Change my username")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            changeUsernamePageView.setChangeListener(new ChangeListener());
            MainFrame.mainFrame.getContentPane().add(changeUsernamePageView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }

        if (string.equals("Change my date of birth")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            changeDateOfBirthView.setListener(new ChangeListener());
            MainFrame.mainFrame.getContentPane().add(changeDateOfBirthView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }

        if (string.equals("Change my email")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            changeEmailPageView.setChangeListener(new ChangeListener());
            MainFrame.mainFrame.getContentPane().add(changeEmailPageView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }

        if (string.equals("Change my phone number")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            changePhoneNumberPageView.setChangeListener(new ChangeListener());
            MainFrame.mainFrame.getContentPane().add(changePhoneNumberPageView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }

        if (string.equals("Change my biography")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            changeBiographyPageView.setChangeListener(new ChangeListener());
            MainFrame.mainFrame.getContentPane().add(changeBiographyPageView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }

        if (string.equals("select And Change Profile Picture")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            selectProfilePictureView.setChangeListener(new ChangeListener());
            MainFrame.mainFrame.getContentPane().add(selectProfilePictureView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }

        if (string.equals("Back to personal page")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            personalPageView.setStringListener(new PersonalPageListener());
            MainFrame.mainFrame.getContentPane().add(personalPageView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }
    }
}
