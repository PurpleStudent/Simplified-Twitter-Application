package editProfilePage.listener;

import editProfilePage.event.ChangeEvent;
import editProfilePage.view.EditProfilePageView;
import homepage.listener.HomePageListener;
import homepage.view.HomePageView;
import models.Date;
import models.DateTime;
import models.Message;
import models.User;
import view.MainFrame;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.util.LinkedList;
import java.util.Scanner;

public class ChangeListener {


    //EditProfileController controller= new EditProfileController();
    EditProfilePageView editProfilePageView= new EditProfilePageView();
    HomePageView homePageView= new HomePageView();








    public void changeOccurred(ChangeEvent changeEvent){

        if (changeEvent.getChanged().equals("first name")) {
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            editProfilePageView.setStringListener(new EditProfileListener());
            MainFrame.mainFrame.getContentPane().add(editProfilePageView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
            changeFirstName(changeEvent.getNewString());
        }

        if (changeEvent.getChanged().equals("last name")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            editProfilePageView.setStringListener(new EditProfileListener());
            MainFrame.mainFrame.getContentPane().add(editProfilePageView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
            changeLastName(changeEvent.getNewString());
        }

        if (changeEvent.getChanged().equals("username")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            editProfilePageView.setStringListener(new EditProfileListener());
            MainFrame.mainFrame.getContentPane().add(editProfilePageView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
            changeUsername(changeEvent.getNewString());
        }


        if (changeEvent.getChanged().equals("date of birth")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            editProfilePageView.setStringListener(new EditProfileListener());
            MainFrame.mainFrame.getContentPane().add(editProfilePageView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
            changeDateOfBirth(changeEvent.getDate());
        }

        if (changeEvent.getChanged().equals("email")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            editProfilePageView.setStringListener(new EditProfileListener());
            MainFrame.mainFrame.getContentPane().add(editProfilePageView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
            changeEmail(changeEvent.getNewString());
        }

        if (changeEvent.getChanged().equals("phone number")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            editProfilePageView.setStringListener(new EditProfileListener());
            MainFrame.mainFrame.getContentPane().add(editProfilePageView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
            changePhoneNumber(changeEvent.getNewString());
        }

        if (changeEvent.getChanged().equals("biography")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            editProfilePageView.setStringListener(new EditProfileListener());
            MainFrame.mainFrame.getContentPane().add(editProfilePageView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
            changeBiography(changeEvent.getNewString());
        }

        if (changeEvent.getChanged().equals("password")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            homePageView.setStringListener(new HomePageListener());
            MainFrame.mainFrame.getContentPane().add(homePageView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
            changePassword(changeEvent.getNewString());
        }

        if (changeEvent.getChanged().equals("photo address")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            editProfilePageView.setStringListener(new EditProfileListener());
            MainFrame.mainFrame.getContentPane().add(editProfilePageView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
            copy ( changeEvent.getNewString() , User.currentUserId );
        }

    }































    private void changeFirstName(String newString){
        try {
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{EditProfileController}"+"{changeFirstName}{"+newString+"}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response= input.nextLine();

            socket.close();
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }































    private void changeLastName(String newString){
        try {
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{EditProfileController}"+"{changeLastName}{"+newString+"}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response= input.nextLine();

            socket.close();
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }































    private void changeUsername(String newString){
        try {
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{EditProfileController}"+"{changeUsername}{"+newString+"}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response= input.nextLine();

            socket.close();
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }































    private void changeDateOfBirth(Date date){
        try {
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{EditProfileController}"+"{changeDateOfBirth}{"+date.toString()+"}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response= input.nextLine();

            socket.close();
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }































    private void changeEmail(String newString){
        try {
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{EditProfileController}"+"{changeEmail}{"+newString+"}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response= input.nextLine();

            socket.close();
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }































    private void changePhoneNumber(String newString){
        try {
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{EditProfileController}"+"{changePhoneNumber}{"+newString+"}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response= input.nextLine();

            socket.close();
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }































    private void changeBiography(String newString){
        try {
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{EditProfileController}"+"{changeBiography}{"+newString+"}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response= input.nextLine();

            socket.close();
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }































    private void changePassword(String newString){
        try {
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{EditProfileController}"+"{changePassword}{"+newString+"}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response= input.nextLine();

            socket.close();
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }































    private void copy( String photoAddress , long userId ){
        try {
            // first outputs
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));
            OutputStream outputStream= socket.getOutputStream();
            PrintWriter output = new PrintWriter( outputStream , true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{EditProfileController}"+"{copy}{"+userId+"}";
            output.println(message);
            //-----------------------------------------------------------------------------------------------------------------------------------------------------------------
            // first inputs
            Scanner input1 = new Scanner(socket.getInputStream());
            String response1= input1.nextLine();
            //-----------------------------------------------------------------------------------------------------------------------------------------------------------------
            // second outputs
            File file;
            ByteArrayOutputStream byteArrayOutputStream;
            byteArrayOutputStream = new ByteArrayOutputStream();
            if (!photoAddress.equals("")) {
                file = new File(photoAddress);
                file.getParentFile().mkdirs();
                if (!file.exists()) {
                    file.createNewFile();
                }
                BufferedImage image = ImageIO.read(file);
                ImageIO.write(image, "jpg", byteArrayOutputStream);
            }
            if (response1.equals("Send the image.")){
                byte[] size = ByteBuffer.allocate(4).putInt(byteArrayOutputStream.size()).array();
                outputStream.write(size);
                outputStream.write(byteArrayOutputStream.toByteArray());
                outputStream.flush();
            }
            //----------------------------------------------------------------------------------------------------------------------------------------------------------------
            // second inputs
            Scanner input2 = new Scanner(socket.getInputStream());
            String response2= input2.nextLine();
            socket.close();
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
}
