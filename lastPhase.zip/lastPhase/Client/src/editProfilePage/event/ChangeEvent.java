package editProfilePage.event;

import models.Date;

import java.util.EventObject;

public class ChangeEvent extends EventObject {

    String changed;
    String newString;
    Date date;



    public ChangeEvent(Object source, String changed, String newString, Date date) {
        super(source);
        this.changed= changed;
        this.newString= newString;
        this.date= date;
    }


    public String getChanged() {
        return changed;
    }

    public String getNewString() {
        return newString;
    }

    public Date getDate() {
        return date;
    }
}
