package accessListsPage.listener;

import accessListsPage.event.CreateNewCategoryEvent;
import accessListsPage.view.CategoriesAndSettingsView;
import models.Category;
import models.User;
import view.MainFrame;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.LinkedList;
import java.util.Scanner;

public class CreateNewCategoryListener {

    //AccessListController controller= new AccessListController();
    CategoriesAndSettingsView categoriesAndSettingsView= new CategoriesAndSettingsView();








    public void eventOccurred(CreateNewCategoryEvent event){

        if (event.getButton().equals("create new category")){
            createNewCategory(event.getCategoryName());
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            categoriesAndSettingsView.setListener(new CategoriesAndSettingsListener());
            MainFrame.mainFrame.getContentPane().add(categoriesAndSettingsView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }
    }


















    private void createNewCategory(String name){
        try {
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{AccessListController}"+"{createNewCategory}{"+name+"}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();

            socket.close();
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
}
