package accessListsPage.listener;

import accessListsPage.event.SeeMemberOfListEvent;
import accessListsPage.view.AccessListsPageView;
import accessListsPage.view.MemberOfListView;
import anotherUserPersonalPage.listener.AnotherUserPersonalPageListener;
import anotherUserPersonalPage.view.AnotherUserPersonalPageView;
import models.*;
import view.MainFrame;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.util.LinkedList;
import java.util.Scanner;

public class SeeMemberOfListListener {

    //AccessListController controller= new AccessListController();
    AnotherUserPersonalPageView anotherUserPersonalPageView;
    AccessListsPageView accessListsPageView= new AccessListsPageView();
    MemberOfListView memberOfListView;
















    public void eventOccurred(SeeMemberOfListEvent event){


        if (event.getButton().equals("view profile")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            anotherUserPersonalPageView= new AnotherUserPersonalPageView(
                    getUserWithId(event.getCurrentUserId()),
                    buttonMode(event.getCurrentUserId()),
                    showLastSeenDate(event.getCurrentUserId()),
                    showDateOfBirth(event.getCurrentUserId()),
                    showEmail(event.getCurrentUserId()),
                    showPhoneNumber(event.getCurrentUserId()),
                    getProfileImage(event.getCurrentUserId())
            );
            anotherUserPersonalPageView.setListener(new AnotherUserPersonalPageListener());
            MainFrame.mainFrame.getContentPane().add(anotherUserPersonalPageView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }





        if (event.getButton().equals("return to access lists page")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            accessListsPageView.setStringListener(new AccessListListener());
            MainFrame.mainFrame.getContentPane().add(accessListsPageView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }





        if (event.getButton().equals("next")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            memberOfListView = new MemberOfListView (
                    nextUsername (event.getList() , event.getCurrentUserId()) ,
                    nextUserid (event.getList() , event.getCurrentUserId()) ,
                    event.getList()
            );
            memberOfListView.setListener(new SeeMemberOfListListener());
            MainFrame.mainFrame.getContentPane().add(memberOfListView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }






        if (event.getButton().equals("previous")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            memberOfListView = new MemberOfListView (
                    previousUsername ( event.getList() ,  event.getCurrentUserId() ) ,
                    previousUserid ( event.getList() , event.getCurrentUserId() ) ,
                    event.getList()
            );
            memberOfListView.setListener(new SeeMemberOfListListener());
            MainFrame.mainFrame.getContentPane().add(memberOfListView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }


    }































    private User getUserWithId(long id){
        try {
            User user= null;
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{AccessListController}"+"{getUserWithId}{"+id+"}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();

            if (!response.equals("null")) {
                String remaining = response;
                LinkedList<String> informationList = new LinkedList<>();

                while (!remaining.equals("")) {
                    String info = remaining.substring(remaining.indexOf('{') + 1, remaining.indexOf('}'));
                    informationList.add(info);

                    if (remaining.indexOf('}') + 1 == remaining.length()) {
                        remaining = "";
                    } else {
                        remaining = remaining.substring(remaining.indexOf('}') + 1);
                    }
                }

                long userid = Long.parseLong(informationList.get(0));
                String username = informationList.get(1);
                String firstname = informationList.get(2);
                String lastname = informationList.get(3);
                String email= informationList.get(4);
                String biography= informationList.get(5);
                long phoneNumber = Long.parseLong(informationList.get(6));
                DateTime lastSeenDate = DateTime.convertStringToDateTime(informationList.get(7));
                Date dateOfBirth = Date.convertStringToDate(informationList.get(8));
                boolean active=false;
                if (informationList.get(9).equals("true")){active=true;}
                boolean privateAccount = false;
                if (informationList.get(10).equals("true")){privateAccount=true;}
                String showLastSeenDate= informationList.get(11);
                String showDateOfBirth= informationList.get(12);
                String showEmail = informationList.get(13);
                String showPhoneNumber = informationList.get(14);

                Profile profile= new Profile(firstname,lastname,email);
                profile.setBiography(biography);
                profile.setPhoneNumber(phoneNumber);
                profile.setLastSeenDate(lastSeenDate);
                profile.setDateOfBirth(dateOfBirth);
                profile.setActive(active);
                profile.setPrivateAccount(privateAccount);
                profile.setShowLastSeenDate(showLastSeenDate);
                profile.setShowDateOfBirth(showDateOfBirth);
                profile.setShowEmail(showEmail);
                profile.setShowPhoneNumber(showPhoneNumber);


                user = new User(username,profile);
                user.setId(userid);
            }

            socket.close();
            return user;
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }




































    private String buttonMode(long userid){
        try {
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{AccessListController}"+"{buttonMode}{"+userid+"}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();

            socket.close();
            return response;
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return "";
    }





























    private boolean showLastSeenDate(long userid){
        try {
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{AccessListController}"+"{showLastSeenDate}{"+userid+"}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();

            socket.close();
            return Boolean.parseBoolean(response);
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }





















    private boolean showDateOfBirth(long userid){
        try {
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{AccessListController}"+"{showDateOfBirth}{"+userid+"}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();

            socket.close();
            return Boolean.parseBoolean(response);
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }



















    private boolean showEmail(long userid){
        try {
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{AccessListController}"+"{showEmail}{"+userid+"}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();

            socket.close();
            return Boolean.parseBoolean(response);
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }














    private boolean showPhoneNumber(long userid){
        try {
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{AccessListController}"+"{showPhoneNumber}{"+userid+"}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();

            socket.close();
            return Boolean.parseBoolean(response);
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }











    private String nextUsername ( String list , long userid ) {
        try {
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{AccessListController}"+"{nextUsername}{"+list+"}{"+userid+"}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();

            socket.close();
            return response;
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return "";
    }











    private long nextUserid ( String list , long userid ) {
        try {
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{AccessListController}"+"{nextUserid}{"+list+"}{"+userid+"}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();

            socket.close();
            return Long.parseLong(response);
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return -1;
    }













    private String previousUsername(String list ,  long  userid){
        try {
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{AccessListController}"+"{previousUsername}{"+list+"}{"+userid+"}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();

            socket.close();
            return response;
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return "";
    }













    private long previousUserid ( String list , long userid ) {
        try {
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{AccessListController}"+"{previousUserid}{"+list+"}{"+userid+"}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();

            socket.close();
            return Long.parseLong(response);
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return -1;
    }

























    private BufferedImage getProfileImage(long userid){
        try {
            // first outputs
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));
            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{AccessListController}"+"{getProfileImage}{"+userid+"}";
            output.println(message);
            //------------------------------------------------------------------------------------------------------------------------------------------------------------------
            // first inputs
            BufferedImage image= null;
            InputStream inputStream = socket.getInputStream();
            byte[] sizeAr = new byte[4];
            inputStream.read(sizeAr);
            int size = ByteBuffer.wrap(sizeAr).asIntBuffer().get();
            byte[] imageAr = new byte[size];
            inputStream.read(imageAr);
            image = ImageIO.read(new ByteArrayInputStream(imageAr));
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
            // second outputs
            PrintWriter output2 = new PrintWriter(socket.getOutputStream(), true);
            String message2 = "received.";
            output.println(message);
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------------
            // second inputs
            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();
            socket.close();
            return image;
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}
