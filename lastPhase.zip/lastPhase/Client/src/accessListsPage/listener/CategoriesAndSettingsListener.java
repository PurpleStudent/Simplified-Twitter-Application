package accessListsPage.listener;

import accessListsPage.view.AccessListsPageView;
import accessListsPage.view.CreateNewCategoryView;
import category.listener.CategoryListener;
import category.view.CategoryView;
import listener.StringListener;
import models.Category;
import models.User;
import view.MainFrame;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.LinkedList;
import java.util.Scanner;

public class CategoriesAndSettingsListener implements StringListener {

    //AccessListController controller= new AccessListController();
    CreateNewCategoryView createNewCategoryView= new CreateNewCategoryView();
    AccessListsPageView accessListsPageView= new AccessListsPageView();
    CategoryView categoryView;












    @Override
    public void stringEventOccurred(String string) {

        if (string.equals("see Categories")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            categoryView= new CategoryView(firstCategory());
            categoryView.setListener(new CategoryListener());
            MainFrame.mainFrame.getContentPane().add(categoryView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }




        if (string.equals("create New Category")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            createNewCategoryView.setListener(new CreateNewCategoryListener());
            MainFrame.mainFrame.getContentPane().add(createNewCategoryView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }





        if (string.equals("delete Category")){}



        if (string.equals("return To Access Lists Page")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            accessListsPageView.setStringListener(new AccessListListener());
            MainFrame.mainFrame.getContentPane().add(accessListsPageView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }

    }





































    private Category firstCategory(){
        try {
            Category category= null;
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{AccessListController}"+"{firstCategory}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();

            if (!response.equals("null")) {
                String remaining = response;
                LinkedList<String> informationList = new LinkedList<>();

                while (!remaining.equals("")) {
                    String info = remaining.substring(remaining.indexOf('{') + 1, remaining.indexOf('}'));
                    informationList.add(info);

                    if (remaining.indexOf('}') + 1 == remaining.length()) {
                        remaining = "";
                    } else {
                        remaining = remaining.substring(remaining.indexOf('}') + 1);
                    }
                }

                String categoryName = informationList.get(0);
                long id = Long.parseLong(informationList.get(1));
                long userId = Long.parseLong(informationList.get(2));

                category = new Category(categoryName, userId);
                category.setId(id);
            }

            socket.close();
            return category;
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}
