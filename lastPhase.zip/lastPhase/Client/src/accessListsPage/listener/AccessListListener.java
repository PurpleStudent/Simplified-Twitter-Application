package accessListsPage.listener;

import accessListsPage.view.CategoriesAndSettingsView;
import accessListsPage.view.MemberOfListView;
import listener.StringListener;
import models.*;
import personalPage.listener.PersonalPageListener;
import personalPage.view.PersonalPageView;
import view.MainFrame;
import view.MainPanel;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.LinkedList;
import java.util.Scanner;

public class AccessListListener implements StringListener {

    //AccessListController controller= new AccessListController();
    PersonalPageView personalPageView= new PersonalPageView();
    MemberOfListView memberOfListView;
    CategoriesAndSettingsView categoriesAndSettingsView= new CategoriesAndSettingsView();
    MainPanel mainPanel= new MainPanel();







    @Override
    public void stringEventOccurred(String string) {

        if (string.equals("See the followers list")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            memberOfListView = new MemberOfListView ( getFollowerUsername() , getFollowerId() , "followers" );
            memberOfListView.setListener(new SeeMemberOfListListener());
            MainFrame.mainFrame.getContentPane().add(memberOfListView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }


        if (string.equals("See the followings list")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            memberOfListView = new MemberOfListView ( getFollowingUsername() , getFollowingId() , "followings" );
            memberOfListView.setListener(new SeeMemberOfListListener());
            MainFrame.mainFrame.getContentPane().add(memberOfListView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }

        if (string.equals("See the black list")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            memberOfListView = new MemberOfListView ( getBlockedUsername() , getBlockedId() , "black list");
            memberOfListView.setListener(new SeeMemberOfListListener());
            MainFrame.mainFrame.getContentPane().add(memberOfListView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }





        if (string.equals("Categories")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            categoriesAndSettingsView.setListener(new CategoriesAndSettingsListener());
            MainFrame.mainFrame.getContentPane().add(categoriesAndSettingsView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }






        if (string.equals("Return to personal page")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            personalPageView.setStringListener(new PersonalPageListener());
            MainFrame.mainFrame.getContentPane().add(personalPageView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }





        if (string.equals("Log out")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            MainFrame.mainFrame.getContentPane().add(mainPanel);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }




        if (string.equals("Exit")){
            System.exit(0);
        }
    }

































    private String getFollowerUsername(){
        try {
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{AccessListController}"+"{getFollowerUsername}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response= input.nextLine();

            socket.close();
            return response;
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return "";
    }










































    private String getFollowingUsername(){
        try {
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{AccessListController}"+"{getFollowingUsername}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response= input.nextLine();

            socket.close();
            return response;
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return "";
    }











    private String getBlockedUsername(){
        try {
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{AccessListController}"+"{getBlockedUsername}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response= input.nextLine();

            socket.close();
            return response;
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return "";
    }





















    private long getFollowerId(){
        try {
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{AccessListController}"+"{getFollowerId}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response= input.nextLine();

            socket.close();
            return Long.parseLong(response);
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return -1;
    }
























    private long getFollowingId(){
        try {
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{AccessListController}"+"{getFollowingId}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response= input.nextLine();

            socket.close();
            return Long.parseLong(response);
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return -1;
    }













    private long getBlockedId(){
        try {
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{AccessListController}"+"{getBlockedId}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response= input.nextLine();

            socket.close();
            return Long.parseLong(response);
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return -1;
    }

}
