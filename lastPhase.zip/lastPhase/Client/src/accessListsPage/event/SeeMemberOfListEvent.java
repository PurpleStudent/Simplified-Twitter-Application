package accessListsPage.event;

import models.User;

import java.util.EventObject;

public class SeeMemberOfListEvent extends EventObject {

    private final String button;
    private final long currentUserId;
    private final String list;


    public SeeMemberOfListEvent(Object source, String button, long currentUserId, String list) {
        super(source);
        this.button= button;
        this.currentUserId= currentUserId;
        this.list= list;
    }

    public String getButton() {
        return button;
    }

    public long getCurrentUserId() {
        return currentUserId;
    }

    public String getList() {
        return list;
    }
}
