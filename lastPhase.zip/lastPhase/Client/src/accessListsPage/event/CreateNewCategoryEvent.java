package accessListsPage.event;

import java.util.EventObject;

public class CreateNewCategoryEvent extends EventObject {

    String button;
    String categoryName;


    public CreateNewCategoryEvent(Object source, String button, String categoryName) {
        super(source);
        this.button= button;
        this.categoryName= categoryName;
    }

    public String getButton() {
        return button;
    }

    public String getCategoryName() {
        return categoryName;
    }
}
