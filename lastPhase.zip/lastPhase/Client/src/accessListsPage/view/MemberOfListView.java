package accessListsPage.view;

import accessListsPage.event.SeeMemberOfListEvent;
import accessListsPage.listener.SeeMemberOfListListener;
import models.User;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MemberOfListView extends JPanel implements ActionListener {


    String username;
    long userId;
    String list;

    JButton viewProfile= new JButton("view the profile");
    JButton returnToAccessListsPage= new JButton("Return to access lists page");
    JButton nextButton= new JButton("next");
    JButton previousButton= new JButton("previous");

    private SeeMemberOfListListener listener;



    public MemberOfListView ( String username , long userId , String list){
        this.setBackground(new Color(180, 239, 223));
        this.username= username;
        this.userId= userId;
        this.list= list;

        if (!username.equals("")) {
            //
            viewProfile.setBounds(50, 600, 20, 100);
            this.add(viewProfile);
            viewProfile.addActionListener(this);

            //
            previousButton.setBounds(50, 600, 20, 100);
            this.add(previousButton);
            previousButton.addActionListener(this);

            //
            nextButton.setBounds(50, 600, 20, 100);
            this.add(nextButton);
            nextButton.addActionListener(this);
        }

        //
        returnToAccessListsPage.setBounds(90,600,20,100);
        this.add(returnToAccessListsPage);
        returnToAccessListsPage.addActionListener(this);
    }




    public void setListener(SeeMemberOfListListener listener) {
        this.listener = listener;
    }




    @Override
    public void paint(Graphics g) {
        super.paint(g);
        Font myFont = new Font ("Bold Italic", Font.BOLD, 30);
        g.setFont (myFont);

        if (!username.equals("")) {
            g.setColor(new Color(126, 63, 213));
            g.drawString(username, 100, 300);
        }
        else {
            g.setColor(new Color(126, 63, 213));
            g.drawString("The list is empty", 100, 300);
        }

        g.setColor(new Color(198, 241, 8));
        g.drawString(
                "❤"+"❤"+"❤"+"❤"+"❤"+"❤"+"❤"+"❤"+"❤"+"❤"+"❤"+"❤"+"❤"+"❤"+"❤"+"❤"+"❤"+"❤"+"❤"+"❤"+"❤"+"❤"+"❤"+"❤"+"❤"+"❤"+"❤"+"❤"+"❤"+"❤"+"❤",
                30, 700
        );

        g.setColor(new Color(144, 65, 219));

        g.fillRect(10, 70, 5, 670);
        g.fillRect(10,70,950,5);
        g.fillRect(960, 70, 5, 675);
        g.fillRect(10, 740, 950, 5);

    }






    @Override
    public void actionPerformed(ActionEvent e) {
        if (viewProfile == (JButton) e.getSource()){
            SeeMemberOfListEvent event= new SeeMemberOfListEvent(this,"view profile",userId,list);
            listener.eventOccurred(event);
        }

        if (returnToAccessListsPage == (JButton) e.getSource()){
            SeeMemberOfListEvent event= new SeeMemberOfListEvent(this,"return to access lists page",userId,list);
            listener.eventOccurred(event);
        }

        if (nextButton == (JButton) e.getSource()){
            SeeMemberOfListEvent event= new SeeMemberOfListEvent(this,"next",userId,list);
            listener.eventOccurred(event);
        }

        if (previousButton == (JButton) e.getSource()){
            SeeMemberOfListEvent event= new SeeMemberOfListEvent(this,"previous",userId,list);
            listener.eventOccurred(event);
        }
    }
}
