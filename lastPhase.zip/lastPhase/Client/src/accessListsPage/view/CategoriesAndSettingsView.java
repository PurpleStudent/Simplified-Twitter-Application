package accessListsPage.view;

import listener.StringListener;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CategoriesAndSettingsView extends JPanel implements ActionListener {

    private final JButton seeCategories= new JButton("See Categories");
    private final JButton createNewCategory= new JButton("Create New Category");
    private final JButton deleteCategory= new JButton("Delete Category");
    private final JButton returnToAccessListsPage= new JButton("Return To Access Lists Page");

    private StringListener listener;














    public CategoriesAndSettingsView(){
        this.setBackground(Color.yellow);
        this.setLayout(new GridLayout(4,1));

        this.add(seeCategories);
        this.add(createNewCategory);
        this.add(deleteCategory);
        this.add(returnToAccessListsPage);

        seeCategories.addActionListener(this);
        createNewCategory.addActionListener(this);
        deleteCategory.addActionListener(this);
        returnToAccessListsPage.addActionListener(this);
    }

    public void setListener(StringListener listener) {
        this.listener = listener;
    }





    @Override
    public void actionPerformed(ActionEvent e) {
        if (seeCategories == (JButton) e.getSource()){
            listener.stringEventOccurred("see Categories");
        }
        if (createNewCategory == (JButton) e.getSource()){
            listener.stringEventOccurred("create New Category");
        }
        if (deleteCategory == (JButton) e.getSource()){
            listener.stringEventOccurred("delete Category");
        }
        if (returnToAccessListsPage == (JButton) e.getSource()){
            listener.stringEventOccurred("return To Access Lists Page");
        }
    }
}
