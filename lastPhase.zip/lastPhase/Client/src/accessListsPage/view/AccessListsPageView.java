package accessListsPage.view;

import listener.StringListener;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AccessListsPageView extends JPanel implements ActionListener {

    private final JButton seeFollowersListButton= new JButton("See the followers list");
    private final JButton seeFollowingsListButton= new JButton("See the followings list");
    private final JButton seeBlackListButton= new JButton("See the black list");
    private final JButton categoriesButton= new JButton("Categories");
    private final JButton returnToPersonalPageButton= new JButton("Return to personal page");
    private final JButton logOutButton= new JButton("Log out");
    private final JButton exitButton= new JButton("Exit");

    private StringListener stringListener;


















    public AccessListsPageView(){
        this.setBackground(Color.yellow);
        this.setLayout(new GridLayout(7,1));

        this.add(seeFollowersListButton);
        this.add(seeFollowingsListButton);
        this.add(seeBlackListButton);
        this.add(categoriesButton);
        this.add(returnToPersonalPageButton);
        this.add(logOutButton);
        this.add(exitButton);

        seeFollowersListButton.addActionListener(this);
        seeFollowingsListButton.addActionListener(this);
        seeBlackListButton.addActionListener(this);
        categoriesButton.addActionListener(this);
        returnToPersonalPageButton.addActionListener(this);
        logOutButton.addActionListener(this);
        exitButton.addActionListener(this);
    }


    public void setStringListener(StringListener stringListener) {
        this.stringListener = stringListener;
    }








    @Override
    public void actionPerformed(ActionEvent e) {
        if (seeFollowersListButton == (JButton) e.getSource()){
            stringListener.stringEventOccurred("See the followers list");
        }
        if (seeFollowingsListButton == (JButton) e.getSource()){
            stringListener.stringEventOccurred("See the followings list");
        }
        if (seeBlackListButton == (JButton) e.getSource()){
            stringListener.stringEventOccurred("See the black list");
        }
        if (categoriesButton == (JButton) e.getSource()){
            stringListener.stringEventOccurred("Categories");
        }
        if (returnToPersonalPageButton == (JButton) e.getSource()){
            stringListener.stringEventOccurred("Return to personal page");
        }
        if (logOutButton == (JButton) e.getSource()){
            stringListener.stringEventOccurred("Log out");
        }
        if (exitButton == (JButton) e.getSource()){
            stringListener.stringEventOccurred("Exit");
        }
    }
}
