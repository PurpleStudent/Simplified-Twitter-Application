package settingsPage.listener;

import homepage.listener.HomePageListener;
import homepage.view.HomePageView;
import listener.StringListener;
import privacySettingsPage.listener.PrivacySettingsListener;
import privacySettingsPage.view.PrivacySettingsPageView;
import view.MainFrame;
import view.MainPanel;

public class SettingPageListener implements StringListener {


    HomePageView homePageView= new HomePageView();
    PrivacySettingsPageView privacySettingsPageView= new PrivacySettingsPageView();
    MainPanel mainPanel= new MainPanel();








    @Override
    public void stringEventOccurred(String string) {

        if (string.equals("Privacy settings")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            privacySettingsPageView.setStringListener(new PrivacySettingsListener());
            MainFrame.mainFrame.getContentPane().add(privacySettingsPageView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }

        if (string.equals("delete account")){}

        if (string.equals("Return to home page")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            homePageView.setStringListener(new HomePageListener());
            MainFrame.mainFrame.getContentPane().add(homePageView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }

        if (string.equals("log out")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            MainFrame.mainFrame.getContentPane().add(mainPanel);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }

        if (string.equals("exit")){
            System.exit(0);
        }
    }
}
