package authentication.listener;

import authentication.event.RegistrationFormEvent;
import homepage.listener.HomePageListener;
import homepage.view.HomePageView;
import listener.FormListener;
import models.User;
import view.MainFrame;
import view.MainPanel;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class RegistrationFormListener implements FormListener {

    //private final Controller controller= new Controller();

    HomePageView homePageView= new HomePageView();
    MainPanel mainPanel= new MainPanel();


    @Override
    public void eventOccurred(RegistrationFormEvent event) {
        if (isDuplicateUser(event.getUsername(),event.getEmail(),Long.parseLong(event.getPhoneNumber()))){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            MainFrame.mainFrame.getContentPane().add(mainPanel);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }
        else {
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            homePageView.setStringListener(new HomePageListener());
            MainFrame.mainFrame.getContentPane().add(homePageView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
            register(event);
        }
    }

































    private void register(RegistrationFormEvent event){
        try {
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message =
                    "{0}" +
                    "{0}"+
                    "{AuthenticationController}"+
                    "{register}"+
                    "{"+event.getFirstName()+"}" +
                    "{"+event.getLastName()+"}" +
                    "{"+event.getEmail()+"}"+
                    "{"+event.getPhoneNumber()+"}" +
                    "{"+event.getBiography()+"}" +
                    "{"+event.getYear()+"}"+
                    "{"+event.getMonth()+"}" +
                    "{"+event.getDay()+"}" +
                    "{"+event.getUsername()+"}"+
                    "{"+event.getPassword()+"}" ;
            output.println(message);


            Scanner input = new Scanner(socket.getInputStream());
            String response= input.nextLine();

            String authToken= response.substring(0, response.indexOf(' '));
            String id= response.substring( response.indexOf(' ')+1 );

            User.currentUserId= Long.parseLong(id);
            User.authToken= Long.parseLong(authToken);

            socket.close();
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }






    // auth token + userid + class name + method name + methods inputs
    // *****************************************************************





























    private boolean isDuplicateUser(String username , String email , long phoneNumber ) {
        try {
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message =
                    "{0}" +
                    "{0}"+
                    "{AuthenticationController}"+
                    "{isDuplicateUser}"+
                    "{"+username+"}" +
                    "{"+email+"}" +
                    "{"+phoneNumber+"}" ;
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response= input.nextLine();

            boolean myResponse= false;
            if (response.equals("true")){myResponse=true;}
            socket.close();
            return myResponse;
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }
}
