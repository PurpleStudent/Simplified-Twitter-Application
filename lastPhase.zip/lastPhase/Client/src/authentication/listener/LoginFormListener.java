package authentication.listener;

import authentication.event.LoginFormEvent;
import homepage.listener.HomePageListener;
import homepage.view.HomePageView;
import models.Date;
import models.DateTime;
import models.Profile;
import models.User;
import view.MainFrame;
import view.MainPanel;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.LinkedList;
import java.util.Scanner;

public class LoginFormListener {


    //private final Controller controller= new Controller();
    HomePageView homePageView= new HomePageView();
    MainPanel mainPanel= new MainPanel();










    public void eventOccurred (LoginFormEvent event) {

        if (!userFound(event.getUsername(), event.getPassword())){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            MainFrame.mainFrame.getContentPane().add(mainPanel);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }

        else {
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            homePageView.setStringListener(new HomePageListener());
            MainFrame.mainFrame.getContentPane().add(homePageView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
            login(event.getUsername() , event.getPassword());
        }
    }

































    private boolean userFound( String  userName, String  password ){
        try {
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{AuthenticationController}"+"{userFound}{"+userName+"}{"+password+"}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();

            socket.close();
            return Boolean.parseBoolean(response);
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }































    private void login ( String username, String password ){
        try {
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{AuthenticationController}"+"{login}{"+username+"}{"+password+"}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();

            String authToken= response.substring(0, response.indexOf(' '));
            String id= response.substring( response.indexOf(' ')+1 );

            User.currentUserId= Long.parseLong(id);
            User.authToken= Long.parseLong(authToken);

            socket.close();
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
}
