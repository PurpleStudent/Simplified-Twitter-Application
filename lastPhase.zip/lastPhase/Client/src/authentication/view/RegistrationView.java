package authentication.view;

import authentication.event.RegistrationFormEvent;
import listener.FormListener;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class RegistrationView extends JPanel implements ActionListener {

    private final JTextField userNameField= new JTextField(10);
    private final JTextField emailField= new JTextField(30);
    private final JTextField passwordField= new JTextField(10);
    private final JTextField firstNameField= new JTextField(10);
    private final JTextField lastNameField= new JTextField(10);
    private final JTextField phoneNumberField= new JTextField(10);
    private final JTextField biographyField= new JTextField(30);

    private final JTextField dayField= new JTextField(5);
    private final JTextField monthField= new JTextField(5);
    private final JTextField yearField= new JTextField(5);


    private final JButton registerButton= new JButton("register");

    private FormListener formListener;



    public RegistrationView(){
        this.setBackground(new Color(255, 225, 127));
        Border innerBorder= BorderFactory.createTitledBorder("registration form");
        Border outerBorder= BorderFactory.createEmptyBorder(20,20,20,20);
        this.setBorder(BorderFactory.createCompoundBorder(outerBorder,innerBorder));

        this.setLayout(new GridBagLayout());
        GridBagConstraints gridBagConstraints= new GridBagConstraints();

        gridBagConstraints.weightx= 0.5;
        gridBagConstraints.weighty= 1;

        //1
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.insets = new Insets(0, 0, 0, 5);
        gridBagConstraints.anchor = GridBagConstraints.LINE_END;
        this.add(new JLabel("username: "), gridBagConstraints);

        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.insets = new Insets(0, 0, 0, 0);
        gridBagConstraints.anchor = GridBagConstraints.LINE_START;
        this.add(userNameField, gridBagConstraints);

        //2
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.insets = new Insets(0, 0, 0, 5);
        gridBagConstraints.anchor = GridBagConstraints.LINE_END;
        this.add(new JLabel("email: "), gridBagConstraints);

        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.insets = new Insets(0, 0, 0, 0);
        gridBagConstraints.anchor = GridBagConstraints.LINE_START;
        this.add(emailField, gridBagConstraints);

        //3
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.insets = new Insets(0, 0, 0, 5);
        gridBagConstraints.anchor = GridBagConstraints.LINE_END;
        this.add(new JLabel("password: "), gridBagConstraints);

        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.insets = new Insets(0, 0, 0, 0);
        gridBagConstraints.anchor = GridBagConstraints.LINE_START;
        this.add(passwordField, gridBagConstraints);

        //4
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.insets = new Insets(0, 0, 0, 5);
        gridBagConstraints.anchor = GridBagConstraints.LINE_END;
        this.add(new JLabel("first name: "), gridBagConstraints);

        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.insets = new Insets(0, 0, 0, 0);
        gridBagConstraints.anchor = GridBagConstraints.LINE_START;
        this.add(firstNameField, gridBagConstraints);

        //5
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.insets = new Insets(0, 0, 0, 5);
        gridBagConstraints.anchor = GridBagConstraints.LINE_END;
        this.add(new JLabel("last name: "), gridBagConstraints);

        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.insets = new Insets(0, 0, 0, 0);
        gridBagConstraints.anchor = GridBagConstraints.LINE_START;
        this.add(lastNameField, gridBagConstraints);

        //6
        gridBagConstraints.gridx = 3;
        gridBagConstraints.gridy = 5;
        gridBagConstraints.insets = new Insets(0, 0, 0, 5);
        gridBagConstraints.anchor = GridBagConstraints.LINE_END;
        this.add(new JLabel("day: "), gridBagConstraints);

        gridBagConstraints.gridx = 4;
        gridBagConstraints.gridy = 5;
        gridBagConstraints.insets = new Insets(0, 0, 0, 0);
        gridBagConstraints.anchor = GridBagConstraints.LINE_START;
        this.add(dayField, gridBagConstraints);

        //7
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 5;
        gridBagConstraints.insets = new Insets(0, 0, 0, 5);
        gridBagConstraints.anchor = GridBagConstraints.LINE_END;
        this.add(new JLabel("month: "), gridBagConstraints);

        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 5;
        gridBagConstraints.insets = new Insets(0, 0, 0, 0);
        gridBagConstraints.anchor = GridBagConstraints.LINE_START;
        this.add(monthField, gridBagConstraints);

        //8
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 5;
        gridBagConstraints.insets = new Insets(0, 0, 0, 5);
        gridBagConstraints.anchor = GridBagConstraints.LINE_END;
        this.add(new JLabel("date of birth:    year: "), gridBagConstraints);

        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 5;
        gridBagConstraints.insets = new Insets(0, 0, 0, 0);
        gridBagConstraints.anchor = GridBagConstraints.LINE_START;
        this.add(yearField, gridBagConstraints);

        //9
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 6;
        gridBagConstraints.insets = new Insets(0, 0, 0, 5);
        gridBagConstraints.anchor = GridBagConstraints.LINE_END;
        this.add(new JLabel("phone number: "), gridBagConstraints);

        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 6;
        gridBagConstraints.insets = new Insets(0, 0, 0, 0);
        gridBagConstraints.anchor = GridBagConstraints.LINE_START;
        this.add(phoneNumberField, gridBagConstraints);

        //10
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 7;
        gridBagConstraints.insets = new Insets(0, 0, 0, 5);
        gridBagConstraints.anchor = GridBagConstraints.LINE_END;
        this.add(new JLabel("biography: "), gridBagConstraints);

        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 7;
        gridBagConstraints.insets = new Insets(0, 0, 0, 0);
        gridBagConstraints.anchor = GridBagConstraints.LINE_START;
        this.add(biographyField, gridBagConstraints);

        //11
        gridBagConstraints.weightx = 1;
        gridBagConstraints.weighty = 2;

        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 8;
        gridBagConstraints.insets = new Insets(0, 0, 0, 0);
        gridBagConstraints.anchor = GridBagConstraints.FIRST_LINE_START;
        this.add(registerButton, gridBagConstraints);

        registerButton.addActionListener(this);
    }



    public String getUserNameField() {
        return userNameField.getText();
    }

    public String getEmailField() {
        return emailField.getText();
    }

    public String getPasswordField() {
        return passwordField.getText();
    }

    public String getFirstNameField() {
        return firstNameField.getText();
    }

    public String getLastNameField() {
        return lastNameField.getText();
    }

    public String getPhoneNumberField() {
        return phoneNumberField.getText();
    }

    public String getBiographyField() {
        return biographyField.getText();
    }

    public String getDayField() {
        return dayField.getText();
    }

    public String getMonthField() {
        return monthField.getText();
    }

    public String getYearField() {
        return yearField.getText();
    }


    public void setFormListener(FormListener formListener) {
        this.formListener = formListener;
    }
























    @Override
    public void actionPerformed(ActionEvent e) {
        if (registerButton == (JButton) e.getSource()){
            RegistrationFormEvent registrationFormEvent= new RegistrationFormEvent(this, getUserNameField(), getEmailField(), getPasswordField(), getFirstNameField(), getLastNameField(), getPhoneNumberField(), getBiographyField(), getDayField(), getMonthField(), getYearField());
            formListener.eventOccurred(registrationFormEvent);
            //ترای کچ بزنیم برای تکراری بودن اطلاعات
        }
    }
}
