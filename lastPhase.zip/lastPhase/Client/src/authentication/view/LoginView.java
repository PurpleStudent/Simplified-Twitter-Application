package authentication.view;

import authentication.event.LoginFormEvent;
import authentication.listener.LoginFormListener;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LoginView extends JPanel implements ActionListener {

    private final JTextField usernameField= new JTextField(20);
    private final JTextField passwordField= new JTextField(20);

    private final JButton loginButton= new JButton("login");

    private LoginFormListener loginFormListener;


    public LoginView(){
        Border innerBorder = BorderFactory.createTitledBorder("login");
        Border outerBoarder = BorderFactory.createEmptyBorder(30, 30, 50, 30);
        this.setBorder(BorderFactory.createCompoundBorder(outerBoarder, innerBorder));
        this.setLayout(new GridBagLayout());
        GridBagConstraints gridBagConstraints = new GridBagConstraints();
        gridBagConstraints.weightx = 1;
        gridBagConstraints.weighty = 0.5;

        //1
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.insets = new Insets(0, 0, 0, 7);
        gridBagConstraints.anchor = GridBagConstraints.LINE_END;
        this.add(new JLabel("username: "), gridBagConstraints);
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.insets = new Insets(0, 0, 0, 7);
        gridBagConstraints.anchor = GridBagConstraints.LINE_START;
        this.add(usernameField, gridBagConstraints);

        //2
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.insets = new Insets(0, 0, 0, 7);
        gridBagConstraints.anchor = GridBagConstraints.LINE_END;
        this.add(new JLabel("password: "), gridBagConstraints);
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.insets = new Insets(0, 0, 0, 0);
        gridBagConstraints.anchor = GridBagConstraints.LINE_START;
        this.add(passwordField, gridBagConstraints);

        //3
        gridBagConstraints.weightx = 1;
        gridBagConstraints.weighty = 2;
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 5;
        gridBagConstraints.insets = new Insets(0, 0, 0, 0);
        gridBagConstraints.anchor = GridBagConstraints.FIRST_LINE_START;
        this.add(loginButton, gridBagConstraints);
        loginButton.addActionListener(this);
    }



    public String getUserNameField() {
        return usernameField.getText();
    }
    public String getPasswordField() {
        return passwordField.getText();
    }







    public void setLoginFormListener(LoginFormListener loginFormListener) {
        this.loginFormListener = loginFormListener;
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (loginButton == (JButton) e.getSource()){
            LoginFormEvent loginFormEvent= new LoginFormEvent(this,getUserNameField(),getPasswordField());
            loginFormListener.eventOccurred(loginFormEvent);
            //ترای کچ بزنیم برای تکراری بودن اطلاعات
        }
    }
}
