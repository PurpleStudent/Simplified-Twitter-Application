package authentication.event;

import java.util.EventObject;

public class RegistrationFormEvent extends EventObject {

    private String username;
    private String email;
    private String password;
    private String firstName;
    private String lastName;
    private String phoneNumber;
    private String biography;
    private String day;
    private String month;
    private String year;



    public RegistrationFormEvent(Object source, String username, String email, String password, String firstName, String lastName, String phoneNumber, String biography, String day, String month, String year) {
        super(source);
        this.username= username;
        this.email= email;
        this.password= password;
        this.firstName= firstName;
        this.lastName= lastName;
        this.phoneNumber= phoneNumber;
        this.biography= biography;
        this.day= day;
        this.month= month;
        this.year= year;
    }


    public String getUsername() {
        return username;
    }

    public void setUsername(String name) {
        this.username = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getBiography() {
        return biography;
    }

    public String getDay() {
        return day;
    }

    public String getMonth() {
        return month;
    }

    public String getYear() {
        return year;
    }


    @Override
    public String toString() {
        return "RegistrationFormEvent{" + username + '\'' + email + '\'' + password + '\'' + firstName + '\'' + lastName + '\'' +
                phoneNumber + '\'' + biography + '\'' + day + '\'' + month + '\'' + year + '\'' + '}';
    }
}
