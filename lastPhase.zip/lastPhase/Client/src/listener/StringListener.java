package listener;

public interface StringListener {
    void stringEventOccurred(String string);
}
