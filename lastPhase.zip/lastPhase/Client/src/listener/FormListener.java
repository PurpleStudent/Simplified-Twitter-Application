package listener;

import authentication.event.RegistrationFormEvent;

public interface FormListener {
    void eventOccurred(RegistrationFormEvent registrationFormEvent);
}
