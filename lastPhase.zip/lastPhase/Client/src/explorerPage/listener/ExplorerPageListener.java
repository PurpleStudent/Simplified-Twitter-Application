package explorerPage.listener;

import explorerPage.view.SearchPageView;
import homepage.listener.HomePageListener;
import homepage.view.HomePageView;
import listener.StringListener;
import models.Comment;
import models.DateTime;
import models.Tweet;
import models.User;
import tweet.listener.TweetListener;
import tweet.view.TweetView;
import view.MainFrame;
import view.MainPanel;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.util.LinkedList;
import java.util.Scanner;

public class ExplorerPageListener implements StringListener {


    //ExplorerPageController controller= new ExplorerPageController();
    SearchPageView searchPageView= new SearchPageView();
    HomePageView homePageView= new HomePageView();
    TweetView tweetView;
    MainPanel mainPanel= new MainPanel();















    @Override
    public void stringEventOccurred(String string) {
        if (string.equals("Search")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            searchPageView.setStringListener(new SearchListener());
            MainFrame.mainFrame.getContentPane().add(searchPageView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }


        if (string.equals("Random tweets or popular tweets")){

            if ( firstExplorerTweet()!=null ) {
                MainFrame.mainFrame.getContentPane().removeAll();
                MainFrame.mainFrame.getContentPane().invalidate();
                tweetView = new TweetView(
                        firstExplorerTweet(),
                        getTweetImage(firstExplorerTweet().getId()),
                        getProfileImage(firstExplorerTweet().getCreatorUserId()),
                        true
                );
                tweetView.setListener(new TweetListener());
                MainFrame.mainFrame.getContentPane().add(tweetView);
                MainFrame.mainFrame.getContentPane().revalidate();
                MainFrame.mainFrame.repaint();
            }
        }


        if (string.equals("Return to home page")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            homePageView.setStringListener(new HomePageListener());
            MainFrame.mainFrame.getContentPane().add(homePageView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }

        if (string.equals("log out")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            MainFrame.mainFrame.getContentPane().add(mainPanel);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }

        if (string.equals("exit")){
            System.exit(0);
        }

    }































    private Tweet firstExplorerTweet(){
        try {
            Tweet tweet= null;
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{ExplorerPageController}"+"{firstExplorerTweet}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();

            if (!response.equals("null")) {
                String remaining = response;
                LinkedList<String> informationList = new LinkedList<>();

                while (!remaining.equals("")) {
                    String info = remaining.substring(remaining.indexOf('{') + 1, remaining.indexOf('}'));
                    informationList.add(info);

                    if (remaining.indexOf('}') + 1 == remaining.length()) {
                        remaining = "";
                    } else {
                        remaining = remaining.substring(remaining.indexOf('}') + 1);
                    }
                }

                long id = Long.parseLong(informationList.get(0));
                long ownerTweetId = Long.parseLong(informationList.get(1));
                String text = informationList.get(2);
                long creatorUserId= Long.parseLong(informationList.get(3));
                String creatorUsername= informationList.get(4);
                long reportNumber= Long.parseLong(informationList.get(5));
                DateTime dateTimeOfCreation= DateTime.convertStringToDateTime(informationList.get(6));

                if (ownerTweetId==-1){
                    tweet = new Tweet(creatorUserId, text);
                    tweet.setId(id);
                    tweet.setReportNumber(reportNumber);
                    tweet.setDateTimeOfCreation(dateTimeOfCreation);
                    tweet.setCreatorUsername(creatorUsername);
                }
                else {
                    tweet = new Comment(creatorUserId, text, ownerTweetId);
                    tweet.setId(id);
                    tweet.setReportNumber(reportNumber);
                    tweet.setDateTimeOfCreation(dateTimeOfCreation);
                    tweet.setCreatorUsername(creatorUsername);
                }
            }
            socket.close();
            return tweet;
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }































    private BufferedImage getTweetImage(long tweetId){
        try {
            // first outputs
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));
            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{ExplorerPageController}"+"{getTweetImage}{"+tweetId+"}";
            output.println(message);
            //------------------------------------------------------------------------------------------------------------------------------------------------------------------
            // first inputs
            BufferedImage image= null;
            InputStream inputStream = socket.getInputStream();
            byte[] sizeAr = new byte[4];
            inputStream.read(sizeAr);
            int size = ByteBuffer.wrap(sizeAr).asIntBuffer().get();
            byte[] imageAr = new byte[size];
            inputStream.read(imageAr);
            image = ImageIO.read(new ByteArrayInputStream(imageAr));
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
            // second outputs
            PrintWriter output2 = new PrintWriter(socket.getOutputStream(), true);
            String message2 = "received.";
            output.println(message);
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------------
            // second inputs
            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();
            socket.close();
            return image;
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }































    private BufferedImage getProfileImage(long userid){
        try {
            // first outputs
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));
            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{ExplorerPageController}"+"{getProfileImage}{"+userid+"}";
            output.println(message);
            //------------------------------------------------------------------------------------------------------------------------------------------------------------------
            // first inputs
            BufferedImage image= null;
            InputStream inputStream = socket.getInputStream();
            byte[] sizeAr = new byte[4];
            inputStream.read(sizeAr);
            int size = ByteBuffer.wrap(sizeAr).asIntBuffer().get();
            byte[] imageAr = new byte[size];
            inputStream.read(imageAr);
            image = ImageIO.read(new ByteArrayInputStream(imageAr));
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
            // second outputs
            PrintWriter output2 = new PrintWriter(socket.getOutputStream(), true);
            String message2 = "received.";
            output.println(message);
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------------
            // second inputs
            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();
            socket.close();
            return image;
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}
