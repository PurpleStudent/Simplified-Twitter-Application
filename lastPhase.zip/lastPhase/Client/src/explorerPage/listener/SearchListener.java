package explorerPage.listener;

import anotherUserPersonalPage.listener.AnotherUserPersonalPageListener;
import anotherUserPersonalPage.view.AnotherUserPersonalPageView;
import listener.StringListener;
import models.Date;
import models.DateTime;
import models.Profile;
import models.User;
import view.MainFrame;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.util.LinkedList;
import java.util.Scanner;

public class SearchListener implements StringListener {

    //ExplorerPageController controller= new ExplorerPageController();

    AnotherUserPersonalPageView anotherUserPersonalPageView;



    @Override
    public void stringEventOccurred(String string) {
        MainFrame.mainFrame.getContentPane().removeAll();
        MainFrame.mainFrame.getContentPane().invalidate();
        anotherUserPersonalPageView= new AnotherUserPersonalPageView(
                getUserWithUsername (string),
                buttonMode ( getUserWithUsername(string).getId() ),
                showLastSeenDate ( getUserWithUsername(string).getId() ),
                showDateOfBirth ( getUserWithUsername(string).getId() ),
                showEmail ( getUserWithUsername(string).getId() ),
                showPhoneNumber ( getUserWithUsername(string).getId() ),
                getProfileImage ( getUserWithUsername(string).getId() )
        );
        anotherUserPersonalPageView.setListener(new AnotherUserPersonalPageListener());
        MainFrame.mainFrame.getContentPane().add(anotherUserPersonalPageView);
        MainFrame.mainFrame.getContentPane().revalidate();
        MainFrame.mainFrame.repaint();
    }































    private User getUserWithUsername(String userName){
        try {
            User user= null;
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{ExplorerPageController}"+"{getUserWithUsername}{"+userName+"}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();

            if (!response.equals("null")) {
                String remaining = response;
                LinkedList<String> informationList = new LinkedList<>();

                while (!remaining.equals("")) {
                    String info = remaining.substring(remaining.indexOf('{') + 1, remaining.indexOf('}'));
                    informationList.add(info);

                    if (remaining.indexOf('}') + 1 == remaining.length()) {
                        remaining = "";
                    } else {
                        remaining = remaining.substring(remaining.indexOf('}') + 1);
                    }
                }

                long userid = Long.parseLong(informationList.get(0));
                String username = informationList.get(1);
                String firstname = informationList.get(2);
                String lastname = informationList.get(3);
                String email= informationList.get(4);
                String biography= informationList.get(5);
                long phoneNumber = Long.parseLong(informationList.get(6));
                DateTime lastSeenDate = DateTime.convertStringToDateTime(informationList.get(7));
                Date dateOfBirth = Date.convertStringToDate(informationList.get(8));
                boolean active=false;
                if (informationList.get(9).equals("true")){active=true;}
                boolean privateAccount = false;
                if (informationList.get(10).equals("true")){privateAccount=true;}
                String showLastSeenDate= informationList.get(11);
                String showDateOfBirth= informationList.get(12);
                String showEmail = informationList.get(13);
                String showPhoneNumber = informationList.get(14);

                Profile profile= new Profile(firstname,lastname,email);
                profile.setBiography(biography);
                profile.setPhoneNumber(phoneNumber);
                profile.setLastSeenDate(lastSeenDate);
                profile.setDateOfBirth(dateOfBirth);
                profile.setActive(active);
                profile.setPrivateAccount(privateAccount);
                profile.setShowLastSeenDate(showLastSeenDate);
                profile.setShowDateOfBirth(showDateOfBirth);
                profile.setShowEmail(showEmail);
                profile.setShowPhoneNumber(showPhoneNumber);


                user = new User(username,profile);
                user.setId(userid);
            }

            socket.close();
            return user;
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }































    private String buttonMode(long userid){
        try {
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{ExplorerPageController}"+"{buttonMode}{"+userid+"}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();

            socket.close();
            return response;
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return "";
    }































    private boolean showLastSeenDate(long userid){
        try {
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{ExplorerPageController}"+"{showLastSeenDate}{"+userid+"}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();

            socket.close();
            return Boolean.parseBoolean(response);
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }































    private boolean showDateOfBirth(long userid){
        try {
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{ExplorerPageController}"+"{showDateOfBirth}{"+userid+"}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();

            socket.close();
            return Boolean.parseBoolean(response);
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }































    private boolean showEmail(long userid){
        try {
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{ExplorerPageController}"+"{showEmail}{"+userid+"}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();

            socket.close();
            return Boolean.parseBoolean(response);
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }































    private boolean showPhoneNumber(long userid){
        try {
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{ExplorerPageController}"+"{showPhoneNumber}{"+userid+"}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();

            socket.close();
            return Boolean.parseBoolean(response);
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }































    private BufferedImage getProfileImage(long userid){
        try {
            // first outputs
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));
            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{ExplorerPageController}"+"{getProfileImage}{"+userid+"}";
            output.println(message);
            //------------------------------------------------------------------------------------------------------------------------------------------------------------------
            // first inputs
            BufferedImage image= null;
            InputStream inputStream = socket.getInputStream();
            byte[] sizeAr = new byte[4];
            inputStream.read(sizeAr);
            int size = ByteBuffer.wrap(sizeAr).asIntBuffer().get();
            byte[] imageAr = new byte[size];
            inputStream.read(imageAr);
            image = ImageIO.read(new ByteArrayInputStream(imageAr));
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
            // second outputs
            PrintWriter output2 = new PrintWriter(socket.getOutputStream(), true);
            String message2 = "received.";
            output.println(message);
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------------
            // second inputs
            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();
            socket.close();
            return image;
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}
