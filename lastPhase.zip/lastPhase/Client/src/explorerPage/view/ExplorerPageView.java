package explorerPage.view;

import listener.StringListener;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ExplorerPageView extends JPanel implements ActionListener {


    private final JButton searchButton= new JButton("Search");
    private final JButton randomTweetsOrPopularTweetsButton= new JButton("Random tweets or popular tweets");
    private final JButton returnToHomePageButton= new JButton("Return to home page");
    private final JButton logOutButton= new JButton("log out");
    private final JButton exitButton= new JButton("exit");





    private StringListener stringListener;





    public ExplorerPageView(){
        this.setBackground(Color.yellow);
        this.setLayout(new GridLayout(5,1));

        this.add(searchButton);
        this.add(randomTweetsOrPopularTweetsButton);
        this.add(returnToHomePageButton);
        this.add(logOutButton);
        this.add(exitButton);

        searchButton.addActionListener(this);
        randomTweetsOrPopularTweetsButton.addActionListener(this);
        returnToHomePageButton.addActionListener(this);
        logOutButton.addActionListener(this);
        exitButton.addActionListener(this);
    }


    public void setStringListener(StringListener stringListener) {
        this.stringListener = stringListener;
    }






    @Override
    public void actionPerformed(ActionEvent e) {
        if (searchButton == (JButton) e.getSource()){
            stringListener.stringEventOccurred("Search");
        }
        if (randomTweetsOrPopularTweetsButton == (JButton) e.getSource()){
            stringListener.stringEventOccurred("Random tweets or popular tweets");
        }
        if (returnToHomePageButton == (JButton) e.getSource()){
            stringListener.stringEventOccurred("Return to home page");
        }
        if (logOutButton == (JButton) e.getSource()){
            stringListener.stringEventOccurred("log out");
        }
        if (exitButton == (JButton) e.getSource()){
            stringListener.stringEventOccurred("exit");
        }
    }
}
