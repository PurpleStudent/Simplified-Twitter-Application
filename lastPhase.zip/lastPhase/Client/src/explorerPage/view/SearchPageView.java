package explorerPage.view;

import listener.StringListener;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SearchPageView extends JPanel implements ActionListener {

    private final JTextField jTextField= new JTextField(70);
    private final JButton searchButton= new JButton("Search With Username");


    private StringListener stringListener;


    public SearchPageView(){
        this.setBackground(new Color(164, 142, 243));
        Border innerBorder= BorderFactory.createTitledBorder("Search With Username: ");
        Border outerBorder= BorderFactory.createEmptyBorder(20,20,300,20);
        this.setBorder(BorderFactory.createCompoundBorder(outerBorder,innerBorder));
        this.setLayout(new GridBagLayout());
        GridBagConstraints gridBagConstraints= new GridBagConstraints();
        gridBagConstraints.weightx= 1;
        gridBagConstraints.weighty= 1;
        //jTextField
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.insets = new Insets(0, 0, 0, 5);
        gridBagConstraints.anchor = GridBagConstraints.LINE_END;
        this.add(new JLabel("Username: "), gridBagConstraints);
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.insets = new Insets(0, 0, 0, 0);
        gridBagConstraints.anchor = GridBagConstraints.LINE_START;
        this.add(jTextField, gridBagConstraints);
        //createNewTweetButton
        gridBagConstraints.weightx = 1;
        gridBagConstraints.weighty = 2;
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 8;
        gridBagConstraints.insets = new Insets(0, 0, 0, 0);
        gridBagConstraints.anchor = GridBagConstraints.FIRST_LINE_START;
        this.add(searchButton, gridBagConstraints);
        searchButton.addActionListener(this);
    }


    public void setStringListener(StringListener stringListener) {
        this.stringListener = stringListener;
    }

    public String getTextField() {
        return jTextField.getText();
    }



    @Override
    public void actionPerformed(ActionEvent e) {
        if (searchButton == (JButton) e.getSource()){
            stringListener.stringEventOccurred(getTextField());
        }
    }
}
