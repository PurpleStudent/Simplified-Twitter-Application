package announcements.listener;

import announcements.view.RequestsSectionView;
import listener.StringListener;
import message.listener.SystemMessageListener;
import message.view.SystemMessageView;
import models.DateTime;
import models.SystemMessage;
import models.User;
import personalPage.listener.PersonalPageListener;
import personalPage.view.PersonalPageView;
import view.MainFrame;
import view.MainPanel;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.LinkedList;
import java.util.Scanner;

public class AnnouncementsListener implements StringListener {

    RequestsSectionView requestsSectionView= new RequestsSectionView();
    PersonalPageView personalPageView= new PersonalPageView();
    SystemMessageView systemMessageView;
    //AnnouncementsController controller= new AnnouncementsController();
    MainPanel mainPanel= new MainPanel();








    @Override
    public void stringEventOccurred(String string) {
        if (string.equals("requests section")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            requestsSectionView.setStringListener(new RequestsSectionListener());
            MainFrame.mainFrame.getContentPane().add(requestsSectionView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }





        if (string.equals("system messages section")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            systemMessageView= new SystemMessageView(getFirstSystemMessages());
            systemMessageView.setListener(new SystemMessageListener());
            MainFrame.mainFrame.getContentPane().add(systemMessageView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }





        if (string.equals("return to personal page")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            personalPageView.setStringListener(new PersonalPageListener());
            MainFrame.mainFrame.getContentPane().add(personalPageView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }

        if (string.equals("Log Out")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            MainFrame.mainFrame.getContentPane().add(mainPanel);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }

        if (string.equals("Exit")){
            System.exit(0);
        }
    }




























    private SystemMessage getFirstSystemMessages(){
        try {
            SystemMessage systemMessage= null;
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{AnnouncementsController}"+"{getFirstSystemMessages}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();

            if (!response.equals("null")) {
                String remaining = response;
                LinkedList<String> informationList = new LinkedList<>();

                while (!remaining.equals("")) {
                    String info = remaining.substring(remaining.indexOf('{') + 1, remaining.indexOf('}'));
                    informationList.add(info);

                    if (remaining.indexOf('}') + 1 == remaining.length()) {
                        remaining = "";
                    } else {
                        remaining = remaining.substring(remaining.indexOf('}') + 1);
                    }
                }

                long id = Long.parseLong(informationList.get(0));
                String text = informationList.get(1);
                long recipientId = Long.parseLong(informationList.get(2));
                DateTime dateTimeOfCreation = DateTime.convertStringToDateTime(informationList.get(3));

                systemMessage = new SystemMessage(recipientId,text);
                systemMessage.setId(id);
                systemMessage.setDateTimeOfCreation(dateTimeOfCreation);

            }

            socket.close();
            return systemMessage;
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}
