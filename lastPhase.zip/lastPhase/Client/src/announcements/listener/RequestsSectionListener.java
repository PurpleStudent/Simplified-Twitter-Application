package announcements.listener;

import announcements.view.AnnouncementsView;
import listener.StringListener;
import message.listener.SystemMessageListener;
import message.view.SystemMessageView;
import models.DateTime;
import models.Request;
import models.SystemMessage;
import models.User;
import request.listener.RequestListener;
import request.view.RequestView;
import view.MainFrame;
import view.MainPanel;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.LinkedList;
import java.util.Scanner;

public class RequestsSectionListener implements StringListener {

    //AnnouncementsController controller= new AnnouncementsController();
    MainPanel mainPanel= new MainPanel();
    AnnouncementsView announcementsView= new AnnouncementsView();
    RequestView requestView;
    SystemMessageView systemMessageView;








    @Override
    public void stringEventOccurred(String string) {
        if (string.equals("see Other Users Requests To Follow")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            requestView= new RequestView ( getFirstRequest() );
            requestView.setListener(new RequestListener());
            MainFrame.mainFrame.getContentPane().add(requestView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }




        if (string.equals("see Status Of Your Follow Up Requests From Other Users")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            systemMessageView= new SystemMessageView ( getFirstSystemMessages() );
            systemMessageView.setListener(new SystemMessageListener());
            MainFrame.mainFrame.getContentPane().add(systemMessageView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }






        if (string.equals("return To Announcements")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            announcementsView.setStringListener(new AnnouncementsListener());
            MainFrame.mainFrame.getContentPane().add(announcementsView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }




        if (string.equals("Log Out")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            MainFrame.mainFrame.getContentPane().add(mainPanel);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }




        if (string.equals("Exit")){
            System.exit(0);
        }

    }

































    private Request getFirstRequest(){
        try {
            Request request= null;
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{AnnouncementsController}"+"{getFirstRequest}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();

            if (!response.equals("null")) {
                String remaining = response;
                LinkedList<String> informationList = new LinkedList<>();

                while (!remaining.equals("")) {
                    String info = remaining.substring(remaining.indexOf('{') + 1, remaining.indexOf('}'));
                    informationList.add(info);

                    if (remaining.indexOf('}') + 1 == remaining.length()) {
                        remaining = "";
                    } else {
                        remaining = remaining.substring(remaining.indexOf('}') + 1);
                    }
                }

                long id = Long.parseLong(informationList.get(0));
                String text = informationList.get(1);
                long requesterId = Long.parseLong(informationList.get(2));
                long requestedId = Long.parseLong(informationList.get(3));

                request = new Request(requesterId,requestedId);
                request.setId(id);
                request.setText(text);

            }

            socket.close();
            return request;
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }






























    private SystemMessage getFirstSystemMessages(){
        try {
            SystemMessage systemMessage= null;
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{AnnouncementsController}"+"{getFirstSystemMessages}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();

            if (!response.equals("null")) {
                String remaining = response;
                LinkedList<String> informationList = new LinkedList<>();

                while (!remaining.equals("")) {
                    String info = remaining.substring(remaining.indexOf('{') + 1, remaining.indexOf('}'));
                    informationList.add(info);

                    if (remaining.indexOf('}') + 1 == remaining.length()) {
                        remaining = "";
                    } else {
                        remaining = remaining.substring(remaining.indexOf('}') + 1);
                    }
                }

                long id = Long.parseLong(informationList.get(0));
                String text = informationList.get(1);
                long recipientId = Long.parseLong(informationList.get(2));
                DateTime dateTimeOfCreation = DateTime.convertStringToDateTime(informationList.get(3));

                systemMessage = new SystemMessage(recipientId,text);
                systemMessage.setId(id);
                systemMessage.setDateTimeOfCreation(dateTimeOfCreation);

            }

            socket.close();
            return systemMessage;
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}
