package announcements.view;

import listener.StringListener;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AnnouncementsView extends JPanel implements ActionListener {

    private final JButton requestsSection= new JButton("requests section"+ "   ✅");
    private final JButton systemMessagesSection= new JButton("system messages section"+ "   ✅");
    private final JButton returnToPersonalPage= new JButton("return to personal page"+ "   ✅");
    private final JButton logOutButton= new JButton("Log Out"+ "   ✅");
    private final JButton exitButton= new JButton("Exit"+ "   ✅");

    private StringListener stringListener;
















    public AnnouncementsView(){
        this.setBackground(Color.yellow);
        this.setLayout(new GridLayout(5,1));

        this.add(requestsSection);
        this.add(systemMessagesSection);
        this.add(returnToPersonalPage);
        this.add(logOutButton);
        this.add(exitButton);

        requestsSection.addActionListener(this);
        systemMessagesSection.addActionListener(this);
        returnToPersonalPage.addActionListener(this);
        logOutButton.addActionListener(this);
        exitButton.addActionListener(this);
    }









    public void setStringListener(StringListener stringListener) {
        this.stringListener = stringListener;
    }








    @Override
    public void actionPerformed(ActionEvent e) {
        if (requestsSection == (JButton) e.getSource()){
            stringListener.stringEventOccurred("requests section");
        }
        if (systemMessagesSection == (JButton) e.getSource()){
            stringListener.stringEventOccurred("system messages section");
        }
        if (returnToPersonalPage == (JButton) e.getSource()){
            stringListener.stringEventOccurred("return to personal page");
        }
        if (logOutButton == (JButton) e.getSource()){
            stringListener.stringEventOccurred("Log Out");
        }
        if (exitButton == (JButton) e.getSource()){
            stringListener.stringEventOccurred("Exit");
        }
    }
}
