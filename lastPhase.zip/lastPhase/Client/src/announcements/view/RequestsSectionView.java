package announcements.view;

import listener.StringListener;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class RequestsSectionView extends JPanel implements ActionListener {

    private final JButton seeOtherUsersRequestsToFollow= new JButton("see other users' requests to follow"+ "   ✅");
    private final JButton seeStatusOfYourFollowUpRequestsFromOtherUsers= new JButton("see the status of your follow-up requests from other users"+ "   ✅");
    private final JButton returnToAnnouncements= new JButton("return to announcements"+ "   ✅");
    private final JButton logOutButton= new JButton("Log Out"+ "   ✅");
    private final JButton exitButton= new JButton("Exit"+ "   ✅");

    private StringListener stringListener;






    public RequestsSectionView(){
        this.setBackground(Color.yellow);
        this.setLayout(new GridLayout(5,1));

        this.add(seeOtherUsersRequestsToFollow);
        this.add(seeStatusOfYourFollowUpRequestsFromOtherUsers);
        this.add(returnToAnnouncements);
        this.add(logOutButton);
        this.add(exitButton);

        seeOtherUsersRequestsToFollow.addActionListener(this);
        seeStatusOfYourFollowUpRequestsFromOtherUsers.addActionListener(this);
        returnToAnnouncements.addActionListener(this);
        logOutButton.addActionListener(this);
        exitButton.addActionListener(this);
    }









    public void setStringListener(StringListener stringListener) {
        this.stringListener = stringListener;
    }








    @Override
    public void actionPerformed(ActionEvent e) {
        if (seeOtherUsersRequestsToFollow == (JButton) e.getSource()){
            stringListener.stringEventOccurred("see Other Users Requests To Follow");
        }
        if (seeStatusOfYourFollowUpRequestsFromOtherUsers == (JButton) e.getSource()){
            stringListener.stringEventOccurred("see Status Of Your Follow Up Requests From Other Users");
        }
        if (returnToAnnouncements == (JButton) e.getSource()){
            stringListener.stringEventOccurred("return To Announcements");
        }
        if (logOutButton == (JButton) e.getSource()){
            stringListener.stringEventOccurred("Log Out");
        }
        if (exitButton == (JButton) e.getSource()){
            stringListener.stringEventOccurred("Exit");
        }
    }
}
