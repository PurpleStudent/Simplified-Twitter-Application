package category.listener;

import accessListsPage.listener.CategoriesAndSettingsListener;
import accessListsPage.view.CategoriesAndSettingsView;
import category.event.CategoryEvent;
import category.view.AddMemberToCategoryView;
import category.view.CategoryMemberView;
import category.view.CategoryView;
import models.*;
import view.MainFrame;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.LinkedList;
import java.util.Scanner;

public class CategoryListener {

    //CategoryController controller= new CategoryController();

    CategoryView categoryView;
    CategoriesAndSettingsView categoriesAndSettingsView= new CategoriesAndSettingsView();
    AddMemberToCategoryView addMemberToCategoryView;
    CategoryMemberView categoryMemberView;












    public void eventOccurred(CategoryEvent event){

        if (event.getButton().equals("previous")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            categoryView= new CategoryView ( previousCategory(event.getCategory().getId()) );
            categoryView.setListener(new CategoryListener());
            MainFrame.mainFrame.getContentPane().add(categoryView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }


        if (event.getButton().equals("next")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            categoryView= new CategoryView(nextCategory(event.getCategory().getId()));
            categoryView.setListener(new CategoryListener());
            MainFrame.mainFrame.getContentPane().add(categoryView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }


        if (event.getButton().equals("return to categories and settings page")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            categoriesAndSettingsView.setListener(new CategoriesAndSettingsListener());
            MainFrame.mainFrame.getContentPane().add(categoriesAndSettingsView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }


        if (event.getButton().equals("add member")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            addMemberToCategoryView= new AddMemberToCategoryView(event.getCategory().getId());
            addMemberToCategoryView.setListener(new AddMemberToCategoryListener());
            MainFrame.mainFrame.getContentPane().add(addMemberToCategoryView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }


        if (event.getButton().equals("delete category")){}



        if (event.getButton().equals("see members")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            categoryMemberView= new CategoryMemberView( firstCategoryMember(event.getCategory().getId()) , event.getCategory() );
            categoryMemberView.setListener(new CategoryMemberListener());
            MainFrame.mainFrame.getContentPane().add(categoryMemberView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }

    }































    private Category previousCategory(long currentCategoryId){
        try {
            Category category= null;
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{CategoryController}"+"{previousCategory}{"+currentCategoryId+"}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();

            if (!response.equals("null")) {
                String remaining = response;
                LinkedList<String> informationList = new LinkedList<>();

                while (!remaining.equals("")) {
                    String info = remaining.substring(remaining.indexOf('{') + 1, remaining.indexOf('}'));
                    informationList.add(info);

                    if (remaining.indexOf('}') + 1 == remaining.length()) {
                        remaining = "";
                    } else {
                        remaining = remaining.substring(remaining.indexOf('}') + 1);
                    }
                }

                long id= Long.parseLong(informationList.get(0));
                String categoryName= informationList.get(1);
                long userId = Long.parseLong(informationList.get(2));

                category = new Category(categoryName , userId);
                category.setId(id);
            }

            socket.close();
            return category;
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }































    private Category nextCategory(long currentCategoryId){
        try {
            Category category= null;
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{CategoryController}"+"{nextCategory}{"+currentCategoryId+"}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();

            if (!response.equals("null")) {
                String remaining = response;
                LinkedList<String> informationList = new LinkedList<>();

                while (!remaining.equals("")) {
                    String info = remaining.substring(remaining.indexOf('{') + 1, remaining.indexOf('}'));
                    informationList.add(info);

                    if (remaining.indexOf('}') + 1 == remaining.length()) {
                        remaining = "";
                    } else {
                        remaining = remaining.substring(remaining.indexOf('}') + 1);
                    }
                }

                long id= Long.parseLong(informationList.get(0));
                String categoryName= informationList.get(1);
                long userId = Long.parseLong(informationList.get(2));

                category = new Category(categoryName , userId);
                category.setId(id);
            }

            socket.close();
            return category;
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }































    private User firstCategoryMember(long categoryId){
        try {
            User user= null;
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{CategoryController}"+"{firstCategoryMember}{"+categoryId+"}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();

            if (!response.equals("null")) {
                String remaining = response;
                LinkedList<String> informationList = new LinkedList<>();

                while (!remaining.equals("")) {
                    String info = remaining.substring(remaining.indexOf('{') + 1, remaining.indexOf('}'));
                    informationList.add(info);

                    if (remaining.indexOf('}') + 1 == remaining.length()) {
                        remaining = "";
                    } else {
                        remaining = remaining.substring(remaining.indexOf('}') + 1);
                    }
                }

                long userid = Long.parseLong(informationList.get(0));
                String username = informationList.get(1);
                String firstname = informationList.get(2);
                String lastname = informationList.get(3);
                String email= informationList.get(4);
                String biography= informationList.get(5);
                long phoneNumber = Long.parseLong(informationList.get(6));
                DateTime lastSeenDate = DateTime.convertStringToDateTime(informationList.get(7));
                Date dateOfBirth = Date.convertStringToDate(informationList.get(8));
                boolean active=false;
                if (informationList.get(9).equals("true")){active=true;}
                boolean privateAccount = false;
                if (informationList.get(10).equals("true")){privateAccount=true;}
                String showLastSeenDate= informationList.get(11);
                String showDateOfBirth= informationList.get(12);
                String showEmail = informationList.get(13);
                String showPhoneNumber = informationList.get(14);

                Profile profile= new Profile(firstname,lastname,email);
                profile.setBiography(biography);
                profile.setPhoneNumber(phoneNumber);
                profile.setLastSeenDate(lastSeenDate);
                profile.setDateOfBirth(dateOfBirth);
                profile.setActive(active);
                profile.setPrivateAccount(privateAccount);
                profile.setShowLastSeenDate(showLastSeenDate);
                profile.setShowDateOfBirth(showDateOfBirth);
                profile.setShowEmail(showEmail);
                profile.setShowPhoneNumber(showPhoneNumber);


                user = new User(username,profile);
                user.setId(userid);
            }

            socket.close();
            return user;
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}
