package category.listener;

import category.event.AddMemberToCategoryEvent;
import category.view.CategoryView;
import models.Category;
import models.DateTime;
import models.Message;
import models.User;
import view.MainFrame;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.LinkedList;
import java.util.Scanner;

public class AddMemberToCategoryListener {

    //CategoryController controller= new CategoryController();

    CategoryView categoryView;







    public void eventOccurred(AddMemberToCategoryEvent event) {

        if (event.getButton().equals("add member")){
            addMember ( event.getUsername() , event.getCategoryId() );
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            categoryView= new CategoryView ( getCategory(event.getCategoryId()) );
            categoryView.setListener(new CategoryListener());
            MainFrame.mainFrame.getContentPane().add(categoryView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }
    }































    private void addMember(String username , long categoryId){
        try {
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{CategoryController}"+"{addMember}{"+username+"}{"+categoryId+"}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();

            socket.close();
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }































    private Category getCategory(long categoryId){
        try {
            Category category= null;
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{CategoryController}"+"{getCategory}{"+categoryId+"}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();

            if (!response.equals("null")) {
                String remaining = response;
                LinkedList<String> informationList = new LinkedList<>();

                while (!remaining.equals("")) {
                    String info = remaining.substring(remaining.indexOf('{') + 1, remaining.indexOf('}'));
                    informationList.add(info);

                    if (remaining.indexOf('}') + 1 == remaining.length()) {
                        remaining = "";
                    } else {
                        remaining = remaining.substring(remaining.indexOf('}') + 1);
                    }
                }

                long id= Long.parseLong(informationList.get(0));
                String categoryName= informationList.get(1);
                long userId = Long.parseLong(informationList.get(2));

                category = new Category(categoryName , userId);
                category.setId(id);
            }

            socket.close();
            return category;
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}
