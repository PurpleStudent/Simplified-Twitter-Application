package category.listener;

import category.event.CategoryMemberEvent;
import category.view.CategoryMemberView;
import category.view.CategoryView;
import models.Date;
import models.DateTime;
import models.Profile;
import models.User;
import view.MainFrame;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.LinkedList;
import java.util.Scanner;

public class CategoryMemberListener {


    //CategoryController controller= new CategoryController();

    CategoryMemberView categoryMemberView;
    CategoryView categoryView;









    public void eventOccurred(CategoryMemberEvent event) {

        if (event.getButton().equals("return to category")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            categoryView= new CategoryView(event.getCategory());
            categoryView.setListener(new CategoryListener());
            MainFrame.mainFrame.getContentPane().add(categoryView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }




        if (event.getButton().equals("next")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            categoryMemberView= new CategoryMemberView ( nextCategoryMember (event.getUser().getId() , event.getCategory().getId() ) ,event.getCategory() );
            categoryMemberView.setListener(new CategoryMemberListener());
            MainFrame.mainFrame.getContentPane().add(categoryMemberView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }




        if (event.getButton().equals("previous")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            categoryMemberView= new CategoryMemberView ( previousCategoryMember ( event.getUser().getId() , event.getCategory().getId() ),event.getCategory() );
            categoryMemberView.setListener(new CategoryMemberListener());
            MainFrame.mainFrame.getContentPane().add(categoryMemberView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }
    }































    private User nextCategoryMember( long currentCategoryMemberId , long categoryId ){
        try {
            User user= null;
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{CategoryController}"+"{nextCategoryMember}{"+currentCategoryMemberId+"}{"+categoryId+"}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();

            if (!response.equals("null")) {
                String remaining = response;
                LinkedList<String> informationList = new LinkedList<>();

                while (!remaining.equals("")) {
                    String info = remaining.substring(remaining.indexOf('{') + 1, remaining.indexOf('}'));
                    informationList.add(info);

                    if (remaining.indexOf('}') + 1 == remaining.length()) {
                        remaining = "";
                    } else {
                        remaining = remaining.substring(remaining.indexOf('}') + 1);
                    }
                }

                long userid = Long.parseLong(informationList.get(0));
                String username = informationList.get(1);
                String firstname = informationList.get(2);
                String lastname = informationList.get(3);
                String email= informationList.get(4);
                String biography= informationList.get(5);
                long phoneNumber = Long.parseLong(informationList.get(6));
                DateTime lastSeenDate = DateTime.convertStringToDateTime(informationList.get(7));
                Date dateOfBirth = Date.convertStringToDate(informationList.get(8));
                boolean active=false;
                if (informationList.get(9).equals("true")){active=true;}
                boolean privateAccount = false;
                if (informationList.get(10).equals("true")){privateAccount=true;}
                String showLastSeenDate= informationList.get(11);
                String showDateOfBirth= informationList.get(12);
                String showEmail = informationList.get(13);
                String showPhoneNumber = informationList.get(14);

                Profile profile= new Profile(firstname,lastname,email);
                profile.setBiography(biography);
                profile.setPhoneNumber(phoneNumber);
                profile.setLastSeenDate(lastSeenDate);
                profile.setDateOfBirth(dateOfBirth);
                profile.setActive(active);
                profile.setPrivateAccount(privateAccount);
                profile.setShowLastSeenDate(showLastSeenDate);
                profile.setShowDateOfBirth(showDateOfBirth);
                profile.setShowEmail(showEmail);
                profile.setShowPhoneNumber(showPhoneNumber);


                user = new User(username,profile);
                user.setId(userid);
            }

            socket.close();
            return user;
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }






























    private User previousCategoryMember( long currentCategoryMemberId , long categoryId ){
        try {
            User user= null;
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{CategoryController}"+"{previousCategoryMember}{"+currentCategoryMemberId+"}{"+categoryId+"}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();

            if (!response.equals("null")) {
                String remaining = response;
                LinkedList<String> informationList = new LinkedList<>();

                while (!remaining.equals("")) {
                    String info = remaining.substring(remaining.indexOf('{') + 1, remaining.indexOf('}'));
                    informationList.add(info);

                    if (remaining.indexOf('}') + 1 == remaining.length()) {
                        remaining = "";
                    } else {
                        remaining = remaining.substring(remaining.indexOf('}') + 1);
                    }
                }

                long userid = Long.parseLong(informationList.get(0));
                String username = informationList.get(1);
                String firstname = informationList.get(2);
                String lastname = informationList.get(3);
                String email= informationList.get(4);
                String biography= informationList.get(5);
                long phoneNumber = Long.parseLong(informationList.get(6));
                DateTime lastSeenDate = DateTime.convertStringToDateTime(informationList.get(7));
                Date dateOfBirth = Date.convertStringToDate(informationList.get(8));
                boolean active=false;
                if (informationList.get(9).equals("true")){active=true;}
                boolean privateAccount = false;
                if (informationList.get(10).equals("true")){privateAccount=true;}
                String showLastSeenDate= informationList.get(11);
                String showDateOfBirth= informationList.get(12);
                String showEmail = informationList.get(13);
                String showPhoneNumber = informationList.get(14);

                Profile profile= new Profile(firstname,lastname,email);
                profile.setBiography(biography);
                profile.setPhoneNumber(phoneNumber);
                profile.setLastSeenDate(lastSeenDate);
                profile.setDateOfBirth(dateOfBirth);
                profile.setActive(active);
                profile.setPrivateAccount(privateAccount);
                profile.setShowLastSeenDate(showLastSeenDate);
                profile.setShowDateOfBirth(showDateOfBirth);
                profile.setShowEmail(showEmail);
                profile.setShowPhoneNumber(showPhoneNumber);


                user = new User(username,profile);
                user.setId(userid);
            }

            socket.close();
            return user;
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}
