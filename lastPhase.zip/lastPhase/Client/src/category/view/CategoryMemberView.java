package category.view;

import category.event.CategoryMemberEvent;
import category.listener.CategoryMemberListener;
import models.Category;
import models.User;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CategoryMemberView extends JPanel implements ActionListener {

    User user;
    Category category;


    JButton returnToCategory= new JButton("return to category");
    JButton nextButton= new JButton("next");
    JButton previousButton= new JButton("previous");

    private CategoryMemberListener listener;



    public CategoryMemberView(User user, Category category){
        this.setBackground(new Color(180, 239, 223));
        this.user= user;
        this.category= category;

        if (user!=null) {

            //
            previousButton.setBounds(50, 600, 20, 100);
            this.add(previousButton);
            previousButton.addActionListener(this);

            //
            nextButton.setBounds(50, 600, 20, 100);
            this.add(nextButton);
            nextButton.addActionListener(this);
        }

        //
        returnToCategory.setBounds(90,600,20,100);
        this.add(returnToCategory);
        returnToCategory.addActionListener(this);
    }




    public void setListener(CategoryMemberListener listener) {
        this.listener = listener;
    }




    @Override
    public void paint(Graphics g) {
        super.paint(g);
        Font myFont = new Font ("Bold Italic", Font.BOLD, 30);
        g.setFont (myFont);

        if (user!=null) {
            g.setColor(new Color(126, 63, 213));
            g.drawString(user.getUsername(), 100, 300);
        }
        else {
            g.setColor(new Color(126, 63, 213));
            g.drawString("The list is empty", 100, 300);
        }

        g.setColor(new Color(198, 241, 8));
        g.drawString(
                "❤"+"❤"+"❤"+"❤"+"❤"+"❤"+"❤"+"❤"+"❤"+"❤"+"❤"+"❤"+"❤"+"❤"+"❤"+"❤"+"❤"+"❤"+"❤"+"❤"+"❤"+"❤"+"❤"+"❤"+"❤"+"❤"+"❤"+"❤"+"❤"+"❤"+"❤",
                30, 700
        );

        g.setColor(new Color(144, 65, 219));

        g.fillRect(10, 70, 5, 670);
        g.fillRect(10,70,950,5);
        g.fillRect(960, 70, 5, 675);
        g.fillRect(10, 740, 950, 5);

    }






    @Override
    public void actionPerformed(ActionEvent e) {

        if (returnToCategory == (JButton) e.getSource()){
            CategoryMemberEvent event= new CategoryMemberEvent(this,"return to category",user,category);
            listener.eventOccurred(event);
        }

        if (nextButton == (JButton) e.getSource()){
            CategoryMemberEvent event= new CategoryMemberEvent(this,"next",user,category);
            listener.eventOccurred(event);
        }

        if (previousButton == (JButton) e.getSource()){
            CategoryMemberEvent event= new CategoryMemberEvent(this,"previous",user,category);
            listener.eventOccurred(event);
        }
    }
}
