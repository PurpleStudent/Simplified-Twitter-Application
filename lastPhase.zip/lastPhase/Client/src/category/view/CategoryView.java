package category.view;

import category.event.CategoryEvent;
import category.listener.CategoryListener;
import models.Category;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class CategoryView extends JPanel implements ActionListener {

    Category category;

    JButton nextButton= new JButton("next");
    JButton previousButton= new JButton("previous");
    JButton returnToCategoriesAndSettingsPage= new JButton("return to categories and settings page");
    JButton addMember= new JButton("add member");
    JButton seeMembers= new JButton("see members");
    JButton deleteCategory= new JButton("delete category");

    private CategoryListener listener;













    public CategoryView(Category category){
        this.setBackground(new Color(67, 232, 185));

        if (category!=null) {
            //
            previousButton.setBounds(10, 600, 20, 100);
            this.add(previousButton);
            previousButton.addActionListener(this);

            //
            nextButton.setBounds(50, 600, 20, 100);
            this.add(nextButton);
            nextButton.addActionListener(this);

            //
            addMember.setBounds(130,600,20,100);
            this.add(addMember);
            addMember.addActionListener(this);

            //
            deleteCategory.setBounds(130,600,20,100);
            this.add(deleteCategory);
            deleteCategory.addActionListener(this);

            //
            seeMembers.setBounds(130,600,20,100);
            this.add(seeMembers);
            seeMembers.addActionListener(this);
        }

        //
        returnToCategoriesAndSettingsPage.setBounds(90,600,20,100);
        this.add(returnToCategoriesAndSettingsPage);
        returnToCategoriesAndSettingsPage.addActionListener(this);

        this.category= category;
    }


    public void setListener(CategoryListener listener) {
        this.listener = listener;
    }













    @Override
    public void paint(Graphics g) {
        super.paint(g);
        Font myFont = new Font ("Bold Italic", Font.BOLD, 50);
        g.setFont (myFont);

        if (category!=null) {

            g.setColor(new Color(18, 154, 123));
            g.drawString(category.getId() + ". " + category.getCategoryName(), 200, 300);

            g.setColor(new Color(220, 50, 75));

            g.fillRect(10, 10, 5, 730);
            g.fillRect(10, 10, 90, 5);
            g.fillRect(880, 10, 80, 5);
            g.fillRect(960, 10, 5, 735);
            g.fillRect(10, 740, 950, 5);
        }

        else {
            g.setColor(new Color(173, 29, 104));
            g.drawString("There are no categories", 300, 300);

            g.setColor(new Color(107, 18, 229));

            g.fillRect(10, 70, 5, 670);
            g.fillRect(10,70,950,5);
            g.fillRect(960, 70, 5, 675);
            g.fillRect(10, 740, 950, 5);
        }
    }













    @Override
    public void actionPerformed(ActionEvent e) {
        if (previousButton == (JButton) e.getSource()){
            CategoryEvent event = new CategoryEvent(this,"previous",category);
            listener.eventOccurred(event);
            //ترای کچ بزنیم برای تکراری بودن اطلاعات
        }
        if (nextButton == (JButton) e.getSource()){
            CategoryEvent event= new CategoryEvent(this,"next",category);
            listener.eventOccurred(event);
        }
        if (returnToCategoriesAndSettingsPage == (JButton) e.getSource()){
            CategoryEvent event= new CategoryEvent(this,"return to categories and settings page",category);
            listener.eventOccurred(event);
        }
        if (addMember == (JButton) e.getSource()){
            CategoryEvent event;
            if (category==null){event= new CategoryEvent(this,"add member",category);}
            else {event= new CategoryEvent(this,"add member",category);}
            listener.eventOccurred(event);
        }
        if (deleteCategory == (JButton) e.getSource()){
            CategoryEvent event= new CategoryEvent(this,"delete category",category);
            listener.eventOccurred(event);
        }
        if (seeMembers == (JButton) e.getSource()){
            CategoryEvent event= new CategoryEvent(this,"see members",category);
            listener.eventOccurred(event);
        }
    }
}
