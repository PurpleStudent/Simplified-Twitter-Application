package category.event;

import models.Category;
import models.User;

import java.util.EventObject;

public class CategoryMemberEvent extends EventObject {

    private final String button;
    private final User user;
    private final Category category;






    public CategoryMemberEvent(Object source, String button, User user, Category category) {
        super(source);
        this.button = button;
        this.user = user;
        this.category = category;
    }


    public String getButton() {
        return button;
    }

    public User getUser() {
        return user;
    }

    public Category getCategory() {
        return category;
    }
}
