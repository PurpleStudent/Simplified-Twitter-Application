package category.event;

import java.util.EventObject;

public class AddMemberToCategoryEvent extends EventObject {

    private final String button;
    private final String username;
    private final long categoryId;




    public AddMemberToCategoryEvent(Object source, String button, String username, long categoryId) {
        super(source);
        this.button= button;
        this.username= username;
        this.categoryId= categoryId;
    }


    public String getButton() {
        return button;
    }

    public String getUsername() {
        return username;
    }

    public long getCategoryId() {
        return categoryId;
    }
}
