package category.event;

import models.Category;

import java.util.EventObject;

public class CategoryEvent extends EventObject {

    private final String button;
    private final Category category;







    public CategoryEvent(Object source, String button, Category category) {
        super(source);
        this.button= button;
        this.category= category;
    }

    public String getButton() {
        return button;
    }

    public Category getCategory() {
        return category;
    }
}
