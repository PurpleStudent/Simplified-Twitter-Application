package models;

public class Date {

    protected int day;
    protected int month;
    protected int year;

    public Date(int year, int month, int day){
        this.year=year;
        this.month=month;
        this.day=day;
    }

    public int getDay() {return day;}

    public int getMonth() {return month;}

    public int getYear() {return year;}

    @Override
    public String toString() {
        return  year+"-"+month+"-"+day;
    }

    public static Date convertStringToDate(String s){
        Date date;
        String s1= s.substring(0,s.indexOf("-")); // year
        String ss= s.substring(s.indexOf("-")+1);
        String s2= ss.substring(0,ss.indexOf("-")); // month
        String s3= ss.substring(ss.indexOf("-")+1); //day
        date= new Date(Integer.parseInt(s1),Integer.parseInt(s2),Integer.parseInt(s3));
        return date;
    }
}
