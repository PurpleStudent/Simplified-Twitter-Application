package models;

import sun.security.util.Password;

public class User extends Model{

    private String username;
    private String password;
    private Profile profile;

    public static long currentUserId; //?!
    public static long authToken;
    public static String port;
    public static String ipAddress;





    // username
    // first name
    // last name
    // biography
    // last seen date
    // date of birth
    // email
    // phone number







    public User(String username, String password, Profile profile){
        this.username= username;
        this.password= password;
        this.profile= profile;
    }

    public User(String username, Profile profile){
        this.username= username;
        this.profile= profile;
    }



















    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String newPassword){
        this.password= newPassword;
    }

    public Profile getProfile() {
        return profile;
    }

    public void setProfile(Profile profile) {
        this.profile = profile;
    }
}
