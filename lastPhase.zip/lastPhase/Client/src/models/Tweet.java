package models;

public class Tweet extends Model{

    protected final long creatorUserId;
    protected String creatorUsername; //حواست به این باشه ها
    protected String text;
    protected long reportNumber;







    public Tweet(long creatorUserId, String text){
        this.creatorUserId=creatorUserId;
        this.text=text;
        //this.id=createNewId();
        dateTimeOfCreation= DateTime.now();
    }









    public String getText() {
        return text;
    }
    public void setText(String text) {
        this.text = text;
    }

    public long getCreatorUserId() {
        return creatorUserId;
    }

    public String getCreatorUsername() {
        return creatorUsername;
    }

    public void setCreatorUsername(String creatorUsername) {
        this.creatorUsername = creatorUsername;
    }

    public long getReportNumber() {
        return reportNumber;
    }

    public void setReportNumber(long reportNumber) {
        this.reportNumber = reportNumber;
    }

    public long getOwnerTweetId() {
        return -1;
    }
}
