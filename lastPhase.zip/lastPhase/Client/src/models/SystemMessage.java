package models;

public class SystemMessage extends Model{

    private User recipient;
    private long recipientId;
    private String text;




    public SystemMessage(long recipientId,String text){
        this.recipientId=recipientId;
        this.text=text;
        dateTimeOfCreation= DateTime.now();
    }


    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public User getRecipient() {
        return recipient;
    }

    public void setRecipient(User recipient) {
        this.recipient = recipient;
    }

    public long getRecipientId() {
        return recipientId;
    }

    public void setRecipientId(long recipientId) {
        this.recipientId = recipientId;
    }
}
