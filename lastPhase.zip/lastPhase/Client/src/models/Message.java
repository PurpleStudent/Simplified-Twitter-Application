package models;

public class Message extends Model{


    private String creatorUsername;
    private final long creatorUserId;
    private String recipientUsername;
    private final long recipientUserId;
    private final String text;




















    public Message(long creatorUserId, String text, long recipientUserId){
        this.creatorUserId= creatorUserId;
        this.recipientUserId= recipientUserId;
        this.text= text;
        dateTimeOfCreation= DateTime.now();
    }


    public String getCreatorUsername() {
        return creatorUsername;
    }

    public void setCreatorUsername(String creatorUsername) {
        this.creatorUsername = creatorUsername;
    }

    public String getRecipientUsername() {
        return recipientUsername;
    }

    public void setRecipientUsername(String recipientUsername) {
        this.recipientUsername = recipientUsername;
    }

    public String getText() {
        return text;
    }


    public long getCreatorUserId() {
        return creatorUserId;
    }

    public long getRecipientUserId() {
        return recipientUserId;
    }
}
