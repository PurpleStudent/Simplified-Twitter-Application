package models;

public class Model {

    protected long id;
    protected DateTime dateTimeOfCreation;


    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public DateTime getDateTimeOfCreation() {
        return dateTimeOfCreation;
    }

    public void setDateTimeOfCreation(DateTime dateTimeOfCreation) {
        this.dateTimeOfCreation = dateTimeOfCreation;
    }
}
