package models;

public class Profile {

    private String firstName;
    private String lastName;
    private Date dateOfBirth;
    private String email;
    private long phoneNumber;
    private String biography;
    private boolean active;
    private boolean privateAccount;
    private DateTime lastSeenDate;
    private String showLastSeenDate;
    private String showDateOfBirth;
    private String showEmail;
    private String showPhoneNumber;




    public Profile(String firstName, String lastName, String email){
        this.firstName = firstName;
        this.lastName = lastName;
        this.dateOfBirth= null;
        this.email = email;
        this.phoneNumber=-1;
        this.biography= "";
        this.active=true;
        this.privateAccount=false;
        this.lastSeenDate=DateTime.now();
        this.showLastSeenDate="everybody";
        this.showDateOfBirth="everybody";
        this.showEmail="everybody";
        this.showPhoneNumber="everybody";
    }

















    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Date getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(Date dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public long getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(long phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getBiography() {
        return biography;
    }

    public void setBiography(String biography) {
        this.biography = biography;
    }

    public boolean isPrivateAccount() {
        return privateAccount;
    }

    public void setPrivateAccount(boolean privateAccount) {
        this.privateAccount = privateAccount;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public DateTime getLastSeenDate() {
        return lastSeenDate;
    }

    public void setLastSeenDate(DateTime lastSeenDate) {
        this.lastSeenDate = lastSeenDate;
    }

    public String getShowLastSeenDate() {
        return showLastSeenDate;
    }

    public void setShowLastSeenDate(String showLastSeenDate) {
        this.showLastSeenDate = showLastSeenDate;
    }

    public String getShowDateOfBirth() {
        return showDateOfBirth;
    }

    public void setShowDateOfBirth(String showDateOfBirth) {
        this.showDateOfBirth = showDateOfBirth;
    }

    public String getShowEmail() {
        return showEmail;
    }

    public void setShowEmail(String showEmail) {
        this.showEmail = showEmail;
    }

    public String getShowPhoneNumber() {
        return showPhoneNumber;
    }

    public void setShowPhoneNumber(String showPhoneNumber) {
        this.showPhoneNumber = showPhoneNumber;
    }
}
