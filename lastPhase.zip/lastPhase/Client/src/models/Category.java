package models;

public class Category extends Model{


    private String categoryName;
    private long userId;
    private User user;  //صاحب دسته




    public Category(String categoryName, long userId){
        this.categoryName= categoryName;
        this.userId= userId;
    }






    public String getCategoryName() {return categoryName;}

    public void setCategoryName(String categoryName) {this.categoryName = categoryName;}

    public User getUser() {return user;}

    public void setUser(User user) {this.user = user;}

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }







    public void showCategory(){
        System.out.println(this.getCategoryName());
        /*for (int i = 0; i < this.getCategory().size(); i++) {
            if (this.getCategory().get(i).getActive()) {
                System.out.println(this.getCategory().get(i).getUserName());
            }
        }*/
    }
}
