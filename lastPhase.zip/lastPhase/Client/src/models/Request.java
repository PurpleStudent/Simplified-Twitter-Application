package models;

public class Request extends Model{


    private User requester;
    private User requested;
    private long requesterId;
    private long requestedId;
    private String text;

    public Request(long requesterId,long requestedId){
        this.text= "I want to follow you.";
        this.requesterId= requesterId;
        this.requestedId= requestedId;
        //this.id=createNewId();
    }

    public User getRequester() {
        return requester;
    }

    public void setRequester(User requester) {
        this.requester = requester;
    }

    public User getRequested() {
        return requested;
    }

    public void setRequested(User requested) {
        this.requested = requested;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public long getRequesterId() {
        return requesterId;
    }

    public void setRequesterId(long requesterId) {
        this.requesterId = requesterId;
    }

    public long getRequestedId() {
        return requestedId;
    }

    public void setRequestedId(long requestedId) {
        this.requestedId = requestedId;
    }
}
