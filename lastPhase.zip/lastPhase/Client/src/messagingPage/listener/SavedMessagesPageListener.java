package messagingPage.listener;

import listener.StringListener;
import message.listener.SavedMessagePreviousNextListener;
import message.view.SavedMessageView;
import messagingPage.view.MessagingPageView;
import messagingPage.view.WriteNewSavedMessageView;
import models.DateTime;
import models.Message;
import models.User;
import view.MainFrame;
import view.MainPanel;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.util.LinkedList;
import java.util.Scanner;

public class SavedMessagesPageListener implements StringListener {


    //MessagingPageController controller= new MessagingPageController();

    MessagingPageView messagingPageView= new MessagingPageView();
    WriteNewSavedMessageView writeNewSavedMessageView= new WriteNewSavedMessageView();
    SavedMessageView savedMessageView;
    MainPanel mainPanel= new MainPanel();



















    @Override
    public void stringEventOccurred(String string) {



        if (string.equals("view Saved Messages")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            savedMessageView= new SavedMessageView(
                    getFirstSavedMessages(),
                    getMessageImage ( getFirstSavedMessages().getId() )
            );
            savedMessageView.setSavedMessagePreviousNextListener(new SavedMessagePreviousNextListener());
            MainFrame.mainFrame.getContentPane().add(savedMessageView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }







        if (string.equals("write Message Save In Saved Messages")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            writeNewSavedMessageView.setWriteNewSavedMessageListener(new WriteNewSavedMessageListener());
            MainFrame.mainFrame.getContentPane().add(writeNewSavedMessageView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }





        if (string.equals("return To Messaging Page")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            messagingPageView.setStringListener(new MessagingPageListener());
            MainFrame.mainFrame.getContentPane().add(messagingPageView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }


        if (string.equals("log Out")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            MainFrame.mainFrame.getContentPane().add(mainPanel);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }


        if (string.equals("exit")){
            System.exit(0);
        }

    }































    private Message getFirstSavedMessages(){
        try {
            Message myMessage= null;
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{MessagingPageController}"+"{getFirstSavedMessages}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();

            if (!response.equals("null")) {
                String remaining = response;
                LinkedList<String> informationList = new LinkedList<>();

                while (!remaining.equals("")) {
                    String info = remaining.substring(remaining.indexOf('{') + 1, remaining.indexOf('}'));
                    informationList.add(info);

                    if (remaining.indexOf('}') + 1 == remaining.length()) {
                        remaining = "";
                    } else {
                        remaining = remaining.substring(remaining.indexOf('}') + 1);
                    }
                }

                long creatorUserId = Long.parseLong(informationList.get(0));
                long recipientUserId = Long.parseLong(informationList.get(1));
                String creatorUsername = informationList.get(2);
                String recipientUsername = informationList.get(3);
                String text= informationList.get(4);
                long id= Long.parseLong(informationList.get(5));
                DateTime dateTimeOfCreation= DateTime.convertStringToDateTime(informationList.get(6));

                myMessage = new Message(creatorUserId, text, recipientUserId);
                myMessage.setId(id);
                myMessage.setCreatorUsername(creatorUsername);
                myMessage.setRecipientUsername(recipientUsername);
                myMessage.setDateTimeOfCreation(dateTimeOfCreation);
            }

            socket.close();
            return myMessage;
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }































    private BufferedImage getMessageImage(long messageId){
        try {
            // first outputs
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));
            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{MessagingPageController}"+"{getMessageImage}{"+messageId+"}";
            output.println(message);
            //------------------------------------------------------------------------------------------------------------------------------------------------------------------
            // first inputs
            BufferedImage image= null;
            InputStream inputStream = socket.getInputStream();
            byte[] sizeAr = new byte[4];
            inputStream.read(sizeAr);
            int size = ByteBuffer.wrap(sizeAr).asIntBuffer().get();
            byte[] imageAr = new byte[size];
            inputStream.read(imageAr);
            image = ImageIO.read(new ByteArrayInputStream(imageAr));
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
            // second outputs
            PrintWriter output2 = new PrintWriter(socket.getOutputStream(), true);
            String message2 = "received.";
            output.println(message);
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------------
            // second inputs
            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();
            socket.close();
            return image;
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}
