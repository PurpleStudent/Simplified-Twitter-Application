package messagingPage.listener;

import messagingPage.event.WriteSaveMessageEvent;
import messagingPage.view.MessagingPageView;
import models.DateTime;
import models.Message;
import models.User;
import view.MainFrame;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.util.LinkedList;
import java.util.Scanner;

public class WriteNewSavedMessageListener {


    //MessagingPageController messagingPageController= new MessagingPageController();
    MessagingPageView messagingPageView= new MessagingPageView();


















    public void eventOccurred(WriteSaveMessageEvent event){



        if (event.getButton().equals("createNewSavedMessage")){
            createNewSavedMessage (event.getText() , event.getPhotoAddress());
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            messagingPageView.setStringListener(new MessagingPageListener());
            MainFrame.mainFrame.getContentPane().add(messagingPageView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }




        if (event.getButton().equals("cancel")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            messagingPageView.setStringListener(new MessagingPageListener());
            MainFrame.mainFrame.getContentPane().add(messagingPageView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }
    }































    private void createNewSavedMessage( String text , String photoAddress ){

        try {
            // first outputs
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));
            OutputStream outputStream= socket.getOutputStream();
            PrintWriter output = new PrintWriter( outputStream , true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{MessagingPageController}"+"{createNewSavedMessage}{"+text+"}";
            output.println(message);
            //-----------------------------------------------------------------------------------------------------------------------------------------------------------------
            // first inputs
            Scanner input1 = new Scanner(socket.getInputStream());
            String response1= input1.nextLine();
            //-----------------------------------------------------------------------------------------------------------------------------------------------------------------
            // second outputs
            File file;
            ByteArrayOutputStream byteArrayOutputStream= null;
            byteArrayOutputStream = new ByteArrayOutputStream();
            if (!photoAddress.equals("")) {
                file = new File(photoAddress);
                file.getParentFile().mkdirs();
                if (!file.exists()) {
                    file.createNewFile();
                }
                BufferedImage image = ImageIO.read(file);
                ImageIO.write(image, "jpg", byteArrayOutputStream);
            }
            if (response1.equals("Send the image.")){
                byte[] size = ByteBuffer.allocate(4).putInt(byteArrayOutputStream.size()).array();
                outputStream.write(size);
                outputStream.write(byteArrayOutputStream.toByteArray());
                outputStream.flush();
            }
            //----------------------------------------------------------------------------------------------------------------------------------------------------------------
            // second inputs
            Scanner input2 = new Scanner(socket.getInputStream());
            String response2= input2.nextLine();
            socket.close();
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
}
