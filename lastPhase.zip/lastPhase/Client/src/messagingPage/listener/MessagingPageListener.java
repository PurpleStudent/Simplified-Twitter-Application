package messagingPage.listener;

import group.listener.CreateGroupListener;
import group.listener.GroupListener;
import group.view.CreateGroupView;
import group.view.GroupView;
import homepage.listener.HomePageListener;
import homepage.view.HomePageView;
import listener.StringListener;
import message.listener.ChatListener;
import message.view.ChatView;
import messagingPage.view.SavedMessagesPageView;
import models.*;
import view.MainFrame;
import view.MainPanel;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.LinkedList;
import java.util.Scanner;

public class MessagingPageListener implements StringListener {


    //MessagingPageController controller= new MessagingPageController();

    SavedMessagesPageView savedMessagesPageView= new SavedMessagesPageView();
    HomePageView homePageView= new HomePageView();
    CreateGroupView createGroupView= new CreateGroupView();
    GroupView groupView;
    ChatView chatView;
    MainPanel mainPanel= new MainPanel();



















    @Override
    public void stringEventOccurred(String string) {

        if (string.equals("saved messages")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            savedMessagesPageView.setStringListener(new SavedMessagesPageListener());
            MainFrame.mainFrame.getContentPane().add(savedMessagesPageView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }




        if (string.equals("View messages sent by others")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            chatView= new ChatView(
                    getAnotherUser (getFirstChat().getId()) ,
                    getFirstChat() ,
                    getNumberOfUnreadMessages ( getFirstChat().getId() )
            );
            chatView.setListener(new ChatListener());
            MainFrame.mainFrame.getContentPane().add(chatView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }




        if (string.equals("Create New Group")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            createGroupView.setListener(new CreateGroupListener());
            MainFrame.mainFrame.getContentPane().add(createGroupView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }




        if (string.equals("my groups")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            groupView= new GroupView ( myFirstGroup() );
            groupView.setListener(new GroupListener());
            MainFrame.mainFrame.getContentPane().add(groupView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }




        if (string.equals("Return to home page")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            homePageView.setStringListener(new HomePageListener());
            MainFrame.mainFrame.getContentPane().add(homePageView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }



        if (string.equals("log out")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            MainFrame.mainFrame.getContentPane().add(mainPanel);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }

        if (string.equals("exit")){
            System.exit(0);
        }

    }






























    private Group myFirstGroup(){
        try {
            Group group= null;
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{MessagingPageController}"+"{myFirstGroup}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();

            if (!response.equals("null")) {
                String remaining = response;
                LinkedList<String> informationList = new LinkedList<>();

                while (!remaining.equals("")) {
                    String info = remaining.substring(remaining.indexOf('{') + 1, remaining.indexOf('}'));
                    informationList.add(info);

                    if (remaining.indexOf('}') + 1 == remaining.length()) {
                        remaining = "";
                    } else {
                        remaining = remaining.substring(remaining.indexOf('}') + 1);
                    }
                }

                long id = Long.parseLong(informationList.get(0));
                String name = informationList.get(1);

                group = new Group(name);
                group.setId(id);
            }
            socket.close();
            return group;
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }































    private User getAnotherUser(long chatId){
        try {
            User user= null;
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{MessagingPageController}"+"{getAnotherUser}{"+chatId+"}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();

            if (!response.equals("null")) {
                String remaining = response;
                LinkedList<String> informationList = new LinkedList<>();

                while (!remaining.equals("")) {
                    String info = remaining.substring(remaining.indexOf('{') + 1, remaining.indexOf('}'));
                    informationList.add(info);

                    if (remaining.indexOf('}') + 1 == remaining.length()) {
                        remaining = "";
                    } else {
                        remaining = remaining.substring(remaining.indexOf('}') + 1);
                    }
                }

                long userid = Long.parseLong(informationList.get(0));
                String username = informationList.get(1);
                String firstname = informationList.get(2);
                String lastname = informationList.get(3);
                String email= informationList.get(4);
                String biography= informationList.get(5);
                long phoneNumber = Long.parseLong(informationList.get(6));
                DateTime lastSeenDate = DateTime.convertStringToDateTime(informationList.get(7));
                Date dateOfBirth = Date.convertStringToDate(informationList.get(8));
                boolean active=false;
                if (informationList.get(9).equals("true")){active=true;}
                boolean privateAccount = false;
                if (informationList.get(10).equals("true")){privateAccount=true;}
                String showLastSeenDate= informationList.get(11);
                String showDateOfBirth= informationList.get(12);
                String showEmail = informationList.get(13);
                String showPhoneNumber = informationList.get(14);

                Profile profile= new Profile(firstname,lastname,email);
                profile.setBiography(biography);
                profile.setPhoneNumber(phoneNumber);
                profile.setLastSeenDate(lastSeenDate);
                profile.setDateOfBirth(dateOfBirth);
                profile.setActive(active);
                profile.setPrivateAccount(privateAccount);
                profile.setShowLastSeenDate(showLastSeenDate);
                profile.setShowDateOfBirth(showDateOfBirth);
                profile.setShowEmail(showEmail);
                profile.setShowPhoneNumber(showPhoneNumber);


                user = new User(username,profile);
                user.setId(userid);
            }

            socket.close();
            return user;
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }































    private Chat getFirstChat(){
        try {
            Chat chat= null;
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{MessagingPageController}"+"{getFirstChat}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();

            if (!response.equals("null")) {
                String remaining = response;
                LinkedList<String> informationList = new LinkedList<>();

                while (!remaining.equals("")) {
                    String info = remaining.substring(remaining.indexOf('{') + 1, remaining.indexOf('}'));
                    informationList.add(info);

                    if (remaining.indexOf('}') + 1 == remaining.length()) {
                        remaining = "";
                    } else {
                        remaining = remaining.substring(remaining.indexOf('}') + 1);
                    }
                }

                long user1id = Long.parseLong(informationList.get(0));
                long user2id = Long.parseLong(informationList.get(1));
                long id= Long.parseLong(informationList.get(2));

                chat = new Chat(user1id,user2id);
                chat.setId(id);
            }

            socket.close();
            return chat;
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }































    private int getNumberOfUnreadMessages(long chatId){
        try {
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{MessagingPageController}"+"{getNumberOfUnreadMessages}{"+chatId+"}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();

            socket.close();
            return Integer.parseInt(response);
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return -1;
    }



}
