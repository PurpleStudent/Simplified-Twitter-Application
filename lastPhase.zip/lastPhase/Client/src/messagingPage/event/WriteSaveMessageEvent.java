package messagingPage.event;

import java.util.EventObject;

public class WriteSaveMessageEvent extends EventObject {


    String button;
    String text;
    String photoAddress;






    public WriteSaveMessageEvent(Object source, String button, String text, String photoAddress) {
        super(source);
        this.button= button;
        this.text= text;
        this.photoAddress= photoAddress;
    }


    public String getButton() {
        return button;
    }

    public String getText() {
        return text;
    }

    public String getPhotoAddress() {
        return photoAddress;
    }
}
