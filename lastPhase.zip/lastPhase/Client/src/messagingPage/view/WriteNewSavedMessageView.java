package messagingPage.view;

import messagingPage.event.WriteSaveMessageEvent;
import messagingPage.listener.WriteNewSavedMessageListener;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class WriteNewSavedMessageView extends JPanel implements ActionListener {


    private final JTextField text= new JTextField(70);
    private final JTextField photoAddress= new JTextField(70);

    private final JButton createNewSavedMessage= new JButton("Create New Saved Message");
    private final JButton cancel= new JButton("Cancel");


    WriteNewSavedMessageListener writeNewSavedMessageListener;
























    public WriteNewSavedMessageView(){
        this.setBackground(new Color(234, 130, 130));
        Border innerBorder = BorderFactory.createTitledBorder("Write New Saved Message");
        Border outerBoarder = BorderFactory.createEmptyBorder(30, 30, 200, 30);
        this.setBorder(BorderFactory.createCompoundBorder(outerBoarder, innerBorder));
        this.setLayout(new GridBagLayout());
        GridBagConstraints gridBagConstraints = new GridBagConstraints();
        gridBagConstraints.weightx = 1;
        gridBagConstraints.weighty = 0.5;

        //1
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.insets = new Insets(0, 0, 0, 5);
        gridBagConstraints.anchor = GridBagConstraints.LINE_END;
        this.add(new JLabel("text : "), gridBagConstraints);

        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.insets = new Insets(0, 0, 0, 0);
        gridBagConstraints.anchor = GridBagConstraints.LINE_START;
        this.add(text , gridBagConstraints);

        //2
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.insets = new Insets(0, 0, 0, 5);
        gridBagConstraints.anchor = GridBagConstraints.LINE_END;
        this.add(new JLabel("photo address : "), gridBagConstraints);

        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.insets = new Insets(0, 0, 0, 0);
        gridBagConstraints.anchor = GridBagConstraints.LINE_START;
        this.add(photoAddress, gridBagConstraints);

        //3
        gridBagConstraints.weightx = 1;
        gridBagConstraints.weighty = 2;

        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 5;
        gridBagConstraints.insets = new Insets(0, 0, 0, 0);
        gridBagConstraints.anchor = GridBagConstraints.FIRST_LINE_START;
        this.add(createNewSavedMessage, gridBagConstraints);
        createNewSavedMessage.addActionListener(this);

        //4
        gridBagConstraints.weightx = 1;
        gridBagConstraints.weighty = 2;

        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 6;
        gridBagConstraints.insets = new Insets(0, 0, 0, 0);
        gridBagConstraints.anchor = GridBagConstraints.FIRST_LINE_START;
        this.add(cancel, gridBagConstraints);
        cancel.addActionListener(this);
    }


































    public String getTextField() {
        return text.getText();
    }

    public String getPhotoAddress() {
        return photoAddress.getText();
    }

    public void setWriteNewSavedMessageListener(WriteNewSavedMessageListener writeNewSavedMessageListener) {
        this.writeNewSavedMessageListener = writeNewSavedMessageListener;
    }


















    @Override
    public void paint(Graphics g) {
        super.paint(g);
        Font myFont = new Font ("Bold Italic", Font.BOLD, 100);
        g.setFont (myFont);

        g.setColor(new Color(226, 25, 111));
        g.drawString("💐"+"💐"+"💐"+"💐"+"💐"+"💐"+"💐"+"💐"+"💐" , 10 , 700);
    }























    @Override
    public void actionPerformed(ActionEvent e) {
        if (createNewSavedMessage == (JButton) e.getSource()){
            WriteSaveMessageEvent event= new WriteSaveMessageEvent(this,"createNewSavedMessage",getTextField(),getPhotoAddress());
            writeNewSavedMessageListener.eventOccurred(event);
            //ترای کچ بزنیم برای تکراری بودن اطلاعات
        }

        if (cancel == (JButton) e.getSource()){
            WriteSaveMessageEvent event= new WriteSaveMessageEvent(this,"cancel",getTextField(),getPhotoAddress());
            writeNewSavedMessageListener.eventOccurred(event);
        }
    }
}
