package messagingPage.view;

import listener.StringListener;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SavedMessagesPageView extends JPanel implements ActionListener {


    private final JButton viewSavedMessages= new JButton("View saved messages");
    private final JButton writeMessageSaveInSavedMessages= new JButton("Write a message and save it in saved messages");
    private final JButton returnToMessagingPage= new JButton("Return to messaging page");
    private final JButton logOutButton= new JButton("log out");
    private final JButton exitButton= new JButton("exit");

    private StringListener stringListener;

    public SavedMessagesPageView(){
        this.setBackground(Color.yellow);
        this.setLayout(new GridLayout(5,1));

        this.add(viewSavedMessages);
        this.add(writeMessageSaveInSavedMessages);
        this.add(returnToMessagingPage);
        this.add(logOutButton);
        this.add(exitButton);

        viewSavedMessages.addActionListener(this);
        writeMessageSaveInSavedMessages.addActionListener(this);
        returnToMessagingPage.addActionListener(this);
        logOutButton.addActionListener(this);
        exitButton.addActionListener(this);
    }


    public void setStringListener(StringListener stringListener) {
        this.stringListener = stringListener;
    }


























    @Override
    public void actionPerformed(ActionEvent e) {
        if (viewSavedMessages == (JButton) e.getSource()){
            stringListener.stringEventOccurred("view Saved Messages");
        }
        if (writeMessageSaveInSavedMessages == (JButton) e.getSource()){
            stringListener.stringEventOccurred("write Message Save In Saved Messages");
        }
        if (returnToMessagingPage == (JButton) e.getSource()){
            stringListener.stringEventOccurred("return To Messaging Page");
        }
        if (logOutButton == (JButton) e.getSource()){
            stringListener.stringEventOccurred("log Out");
        }
        if (exitButton == (JButton) e.getSource()){
            stringListener.stringEventOccurred("exit");
        }
    }
}
