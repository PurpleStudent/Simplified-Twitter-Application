package messagingPage.view;

import listener.StringListener;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MessagingPageView extends JPanel implements ActionListener {


    private final JButton savedMessagesButton= new JButton("saved messages");
    private final JButton viewMessagesSentByOthersButton= new JButton("View messages sent by others");
    private final JButton createNewGroup= new JButton("Create a new group");
    private final JButton myGroups= new JButton("My groups");
    private final JButton returnToHomePageButton= new JButton("Return to home page");
    private final JButton logOutButton= new JButton("log out");
    private final JButton exitButton= new JButton("exit");




    private StringListener stringListener;



    public MessagingPageView(){
        this.setBackground(Color.yellow);
        this.setLayout(new GridLayout(7,1));

        this.add(savedMessagesButton);
        this.add(viewMessagesSentByOthersButton);
        this.add(createNewGroup);
        this.add(myGroups);
        this.add(returnToHomePageButton);
        this.add(logOutButton);
        this.add(exitButton);

        savedMessagesButton.addActionListener(this);
        viewMessagesSentByOthersButton.addActionListener(this);
        createNewGroup.addActionListener(this);
        myGroups.addActionListener(this);
        returnToHomePageButton.addActionListener(this);
        logOutButton.addActionListener(this);
        exitButton.addActionListener(this);
    }


    public void setStringListener(StringListener stringListener) {
        this.stringListener = stringListener;
    }






    @Override
    public void actionPerformed(ActionEvent e) {
        if (savedMessagesButton == (JButton) e.getSource()){
            stringListener.stringEventOccurred("saved messages");
        }
        if (viewMessagesSentByOthersButton == (JButton) e.getSource()){
            stringListener.stringEventOccurred("View messages sent by others");
        }
        if (createNewGroup == (JButton) e.getSource()){
            stringListener.stringEventOccurred("Create New Group");
        }
        if (myGroups == (JButton) e.getSource()){
            stringListener.stringEventOccurred("my groups");
        }
        if (returnToHomePageButton == (JButton) e.getSource()){
            stringListener.stringEventOccurred("Return to home page");
        }
        if (logOutButton == (JButton) e.getSource()){
            stringListener.stringEventOccurred("log out");
        }
        if (exitButton == (JButton) e.getSource()){
            stringListener.stringEventOccurred("exit");
        }
    }
}
