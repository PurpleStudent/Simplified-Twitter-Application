package anotherUserPersonalPage.event;

import models.User;

import java.util.EventObject;

public class CategoryNameEvent extends EventObject {

    String stringButton;
    String categoryName;
    User user;






    public CategoryNameEvent(Object source, String stringButton, String categoryName, User user) {
        super(source);
        this.stringButton= stringButton;
        this.categoryName= categoryName;
        this.user= user;
    }


    public String getStringButton() {
        return stringButton;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public User getUser() {
        return user;
    }
}
