package anotherUserPersonalPage.event;

import models.User;

import java.util.EventObject;

public class AnotherUserPersonalPageEvent extends EventObject {

    String stringButton;
    User user;


    public AnotherUserPersonalPageEvent(Object source, String stringButton, User user) {
        super(source);
        this.stringButton= stringButton;
        this.user= user;
    }


    public String getStringButton() {
        return stringButton;
    }

    public User getUser() {
        return user;
    }
}
