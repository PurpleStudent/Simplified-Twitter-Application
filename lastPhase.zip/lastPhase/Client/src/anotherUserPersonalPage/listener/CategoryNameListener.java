package anotherUserPersonalPage.listener;

import anotherUserPersonalPage.event.CategoryNameEvent;
import anotherUserPersonalPage.view.AnotherUserPersonalPageView;
import models.User;
import view.MainFrame;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.util.Scanner;

public class CategoryNameListener {

    //AnotherUserPersonalPageController controller= new AnotherUserPersonalPageController();
    AnotherUserPersonalPageView anotherUserPersonalPageView;






















    public void eventOccurred(CategoryNameEvent event){


        if (event.getStringButton().equals("addToCategory")){
            addUserToCategories ( event.getCategoryName() , event.getUser().getId() );
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            anotherUserPersonalPageView= new AnotherUserPersonalPageView(
                    event.getUser(),
                    buttonMode(event.getUser().getId()),
                    showLastSeenDate(event.getUser().getId()),
                    showDateOfBirth(event.getUser().getId()),
                    showEmail(event.getUser().getId()),
                    showPhoneNumber(event.getUser().getId()),
                    getProfileImage(event.getUser().getId())
            );
            anotherUserPersonalPageView.setListener(new AnotherUserPersonalPageListener());
            MainFrame.mainFrame.getContentPane().add(anotherUserPersonalPageView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }
    }






























    private String buttonMode(long userid){
        try {
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{AnotherUserPersonalPageController}"+"{buttonMode}{"+userid+"}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();

            socket.close();
            return response;
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return "";
    }






























    private boolean showLastSeenDate(long userid){
        try {
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{AnotherUserPersonalPageController}"+"{showLastSeenDate}{"+userid+"}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();

            socket.close();
            return Boolean.parseBoolean(response);
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }






























    private boolean showDateOfBirth(long userid){
        try {
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{AnotherUserPersonalPageController}"+"{showDateOfBirth}{"+userid+"}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();

            socket.close();
            return Boolean.parseBoolean(response);
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }






























    private boolean showEmail(long userid){
        try {
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{AnotherUserPersonalPageController}"+"{showEmail}{"+userid+"}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();

            socket.close();
            return Boolean.parseBoolean(response);
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }






























    private boolean showPhoneNumber(long userid){
        try {
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{AnotherUserPersonalPageController}"+"{showPhoneNumber}{"+userid+"}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();

            socket.close();
            return Boolean.parseBoolean(response);
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }






























    private BufferedImage getProfileImage(long userid){
        try {
            // first outputs
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));
            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{AnotherUserPersonalPageController}"+"{getProfileImage}{"+userid+"}";
            output.println(message);
            //------------------------------------------------------------------------------------------------------------------------------------------------------------------
            // first inputs
            BufferedImage image= null;
            InputStream inputStream = socket.getInputStream();
            byte[] sizeAr = new byte[4];
            inputStream.read(sizeAr);
            int size = ByteBuffer.wrap(sizeAr).asIntBuffer().get();
            byte[] imageAr = new byte[size];
            inputStream.read(imageAr);
            image = ImageIO.read(new ByteArrayInputStream(imageAr));
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
            // second outputs
            PrintWriter output2 = new PrintWriter(socket.getOutputStream(), true);
            String message2 = "received.";
            output.println(message);
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------------
            // second inputs
            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();
            socket.close();
            return image;
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }






























    private void addUserToCategories(String categoryName , long userid){
        try {
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{AnotherUserPersonalPageController}"+"{addUserToCategories}{"+categoryName+"}{"+userid+"}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();

            socket.close();
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
}
