package anotherUserPersonalPage.view;

import anotherUserPersonalPage.event.AnotherUserPersonalPageEvent;
import anotherUserPersonalPage.listener.AnotherUserPersonalPageListener;
import models.User;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;

public class AnotherUserPersonalPageView extends JPanel implements ActionListener {

    User user;
    String buttonMode;
    BufferedImage profileImage;

    boolean showLastSeenDate;
    boolean showDateOfBirth;
    boolean showEmail;
    boolean showPhoneNumber;

    JButton sendMessageButton= new JButton("I want to send a message");
    JButton blockThisUserButton= new JButton("I want to block this user");
    JButton unBlockThisUserButton= new JButton("I want to unblock this user");
    JButton reportThisUser= new JButton("I want to report this user");
    JButton unfollow= new JButton("Unfollow");
    JButton follow= new JButton("follow");
    JButton addUserToCategories= new JButton("Add this user to categories");
    JButton deleteThisUserFromCategory= new JButton("Delete this user from a category");
    JButton returnToHomePage= new JButton("Return to home page");

    private AnotherUserPersonalPageListener listener;










    public AnotherUserPersonalPageView(
            User user,
            String buttonMode,
            boolean showLastSeenDate,
            boolean showDateOfBirth,
            boolean showEmail,
            boolean showPhoneNumber,
            BufferedImage profileImage
    )
    {
        this.setBackground(new Color(180, 239, 223));
        this.user= user;
        this.buttonMode= buttonMode;
        this.profileImage= profileImage;

        this.showLastSeenDate= showLastSeenDate;
        this.showDateOfBirth= showDateOfBirth;
        this.showEmail= showEmail;
        this.showPhoneNumber= showPhoneNumber;

        if (buttonMode.equals("buttonMode1")){arrangeButtons1();}
        if (buttonMode.equals("buttonMode2")){arrangeButtons2();}
        if (buttonMode.equals("buttonMode3")){arrangeButtons3();}
        if (buttonMode.equals("buttonMode4")){arrangeButtons4();}
    }















    void arrangeButtons1(){
        //
        sendMessageButton.setBounds(10,600,20,100);
        this.add(sendMessageButton);
        sendMessageButton.addActionListener(this);

        //
        blockThisUserButton.setBounds(50,600,20,100);
        this.add(blockThisUserButton);
        blockThisUserButton.addActionListener(this);

        //
        reportThisUser.setBounds(90,600,20,100);
        this.add(reportThisUser);
        reportThisUser.addActionListener(this);

        //
        unfollow.setBounds(130,600,20,100);
        this.add(unfollow);
        unfollow.addActionListener(this);

        //
        addUserToCategories.setBounds(170,600,20,100);
        this.add(addUserToCategories);
        addUserToCategories.addActionListener(this);

        //
        deleteThisUserFromCategory.setBounds(210,600,20,100);
        this.add(deleteThisUserFromCategory);
        deleteThisUserFromCategory.addActionListener(this);

        //
        returnToHomePage.setBounds(250,600,20,100);
        this.add(returnToHomePage);
        returnToHomePage.addActionListener(this);
    }



    void arrangeButtons2(){
        //
        follow.setBounds(130,600,20,100);
        this.add(follow);
        follow.addActionListener(this);

        //
        sendMessageButton.setBounds(10,600,20,100);
        this.add(sendMessageButton);
        sendMessageButton.addActionListener(this);

        //
        blockThisUserButton.setBounds(50,600,20,100);
        this.add(blockThisUserButton);
        blockThisUserButton.addActionListener(this);

        //
        reportThisUser.setBounds(90,600,20,100);
        this.add(reportThisUser);
        reportThisUser.addActionListener(this);

        //
        returnToHomePage.setBounds(250,600,20,100);
        this.add(returnToHomePage);
        returnToHomePage.addActionListener(this);
    }



    void arrangeButtons3(){
        //
        follow.setBounds(130,600,20,100);
        this.add(follow);
        follow.addActionListener(this);

        //
        blockThisUserButton.setBounds(50,600,20,100);
        this.add(blockThisUserButton);
        blockThisUserButton.addActionListener(this);

        //
        reportThisUser.setBounds(90,600,20,100);
        this.add(reportThisUser);
        reportThisUser.addActionListener(this);

        //
        returnToHomePage.setBounds(250,600,20,100);
        this.add(returnToHomePage);
        returnToHomePage.addActionListener(this);
    }



    void arrangeButtons4(){
        //
        unBlockThisUserButton.setBounds(50,600,20,100);
        this.add(unBlockThisUserButton);
        unBlockThisUserButton.addActionListener(this);

        //
        reportThisUser.setBounds(90,600,20,100);
        this.add(reportThisUser);
        reportThisUser.addActionListener(this);

        //
        returnToHomePage.setBounds(250,600,20,100);
        this.add(returnToHomePage);
        returnToHomePage.addActionListener(this);
    }


    public void setListener(AnotherUserPersonalPageListener listener) {
        this.listener = listener;
    }





    @Override
    public void paint(Graphics g) {
        super.paint(g);
        Font myFont = new Font ("Bold Italic", Font.BOLD, 30);
        g.setFont (myFont);

        g.setColor(new Color(9, 112, 239, 255));
        g.drawString("🙂 "+user.getProfile().getFirstName()+" "+user.getProfile().getLastName(), 100, 200);

        g.setColor(new Color(126, 63, 213));
        g.drawString("😉 "+user.getUsername(), 100, 250);

        g.setColor(new Color(105, 45, 198));
        g.drawString("📚 "+"bio : "+user.getProfile().getBiography(), 100, 300);

        if (showLastSeenDate) {
            g.setColor(new Color(164, 15, 198));
            g.drawString("🕒 "+user.getProfile().getLastSeenDate().toString(), 100, 500);
        }
        else {
            g.setColor(new Color(80, 10, 193));
            g.drawString("🕒 "+"last seen recently", 100, 500);
        }
        if (showDateOfBirth) {
            if (user.getProfile().getDateOfBirth()!=null) {
                g.setColor(new Color(119, 66, 199));
                g.drawString("🎂 "+"birthday : "+user.getProfile().getDateOfBirth().toString(), 100, 550);
            }
        }
        if (showEmail) {
            g.setColor(new Color(130, 47, 139));
            g.drawString("📧 "+"email : "+user.getProfile().getEmail(), 100, 600);
        }
        if (showPhoneNumber) {
            g.setColor(new Color(119, 71, 193));
            g.drawString("📞 "+"phone number : "+String.valueOf(user.getProfile().getPhoneNumber()), 100, 650);
        }





        g.setColor(new Color(144, 65, 219));

        g.fillRect(10, 70, 5, 670);
        g.fillRect(10,70,950,5);
        g.fillRect(960, 70, 5, 675);
        g.fillRect(10, 740, 950, 5);



        if (profileImage!=null) {
            g.drawImage(profileImage, 650, 80, 300, 300, null);
        }

    }






























    @Override
    public void actionPerformed(ActionEvent e) {
        if (sendMessageButton == (JButton) e.getSource()){
            AnotherUserPersonalPageEvent event= new AnotherUserPersonalPageEvent(this,"send Message",user);
            listener.eventOccurred(event);
        }
        if (blockThisUserButton == (JButton) e.getSource()){
            AnotherUserPersonalPageEvent event= new AnotherUserPersonalPageEvent(this,"block This User",user);
            listener.eventOccurred(event);
        }
        if (unBlockThisUserButton == (JButton) e.getSource()){
            AnotherUserPersonalPageEvent event= new AnotherUserPersonalPageEvent(this,"unBlock This User",user);
            listener.eventOccurred(event);
        }
        if (reportThisUser == (JButton) e.getSource()){
            AnotherUserPersonalPageEvent event= new AnotherUserPersonalPageEvent(this,"report This User",user);
            listener.eventOccurred(event);
        }
        if (follow == (JButton) e.getSource()){
            AnotherUserPersonalPageEvent event= new AnotherUserPersonalPageEvent(this,"follow",user);
            listener.eventOccurred(event);
        }
        if (unfollow == (JButton) e.getSource()){
            AnotherUserPersonalPageEvent event= new AnotherUserPersonalPageEvent(this,"unfollow",user);
            listener.eventOccurred(event);
        }
        if (addUserToCategories == (JButton) e.getSource()){
            AnotherUserPersonalPageEvent event= new AnotherUserPersonalPageEvent(this,"add User To Categories",user);
            listener.eventOccurred(event);
        }
        if (deleteThisUserFromCategory == (JButton) e.getSource()){
            AnotherUserPersonalPageEvent event= new AnotherUserPersonalPageEvent(this,"delete This User From Category",user);
            listener.eventOccurred(event);
        }
        if (returnToHomePage == (JButton) e.getSource()){
            AnotherUserPersonalPageEvent event= new AnotherUserPersonalPageEvent(this,"return To Home Page",user);
            listener.eventOccurred(event);
        }
    }
}
