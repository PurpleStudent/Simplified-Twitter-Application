package anotherUserPersonalPage.view;

import anotherUserPersonalPage.event.CategoryNameEvent;
import anotherUserPersonalPage.listener.CategoryNameListener;
import models.User;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CategoryNameView extends JPanel implements ActionListener {

    private final JTextField jTextField= new JTextField(70);
    private final JButton addToCategory= new JButton("add User to category");


    CategoryNameListener listener;
    private User user;











    public CategoryNameView(User user){
        this.user= user;
        this.setBackground(new Color(250, 47, 240));
        Border innerBorder= BorderFactory.createTitledBorder("Enter category name: ");
        Border outerBorder= BorderFactory.createEmptyBorder(20,20,300,20);
        this.setBorder(BorderFactory.createCompoundBorder(outerBorder,innerBorder));
        this.setLayout(new GridBagLayout());
        GridBagConstraints gridBagConstraints= new GridBagConstraints();
        gridBagConstraints.weightx= 1;
        gridBagConstraints.weighty= 1;
        //jTextField
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.insets = new Insets(0, 0, 0, 5);
        gridBagConstraints.anchor = GridBagConstraints.LINE_END;
        this.add(new JLabel("category name: "), gridBagConstraints);
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.insets = new Insets(0, 0, 0, 0);
        gridBagConstraints.anchor = GridBagConstraints.LINE_START;
        this.add(jTextField, gridBagConstraints);
        //createNewTweetButton
        gridBagConstraints.weightx = 1;
        gridBagConstraints.weighty = 2;
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 8;
        gridBagConstraints.insets = new Insets(0, 0, 0, 0);
        gridBagConstraints.anchor = GridBagConstraints.FIRST_LINE_START;
        this.add(addToCategory, gridBagConstraints);
        addToCategory.addActionListener(this);
    }


    public void setListener(CategoryNameListener listener) {
        this.listener = listener;
    }


    public String getTextField() {
        return jTextField.getText();
    }










    @Override
    public void actionPerformed(ActionEvent e) {
        if (addToCategory == (JButton) e.getSource()){
            CategoryNameEvent event= new CategoryNameEvent(this, "addToCategory", getTextField(),user);
            listener.eventOccurred(event);
        }
    }
}
