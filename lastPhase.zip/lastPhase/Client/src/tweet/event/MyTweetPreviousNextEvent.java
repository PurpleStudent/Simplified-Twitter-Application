package tweet.event;

import java.util.EventObject;

public class MyTweetPreviousNextEvent extends EventObject {

    long currentTweetId;
    String string;

    public MyTweetPreviousNextEvent(Object source, long currentTweetId, String string) {
        super(source);
        this.currentTweetId= currentTweetId;
        this.string= string;
    }


    public long getCurrentTweetId() {
        return currentTweetId;
    }

    public String getString() {
        return string;
    }
}
