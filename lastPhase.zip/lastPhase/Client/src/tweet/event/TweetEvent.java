package tweet.event;

import models.Tweet;

import java.util.EventObject;

public class TweetEvent extends EventObject {

    String button;
    Tweet currentTweet;
    boolean fromExplorer;



    public TweetEvent(Object source, String button, Tweet currentTweet, boolean fromExplorer) {
        super(source);
        this.button= button;
        this.currentTweet= currentTweet;
        this.fromExplorer= fromExplorer;
    }


    public String getButton() {
        return button;
    }

    public Tweet getCurrentTweet() {
        return currentTweet;
    }

    public boolean isFromExplorer() {
        return fromExplorer;
    }
}
