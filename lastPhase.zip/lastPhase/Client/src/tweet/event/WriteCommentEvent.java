package tweet.event;

import java.util.EventObject;

public class WriteCommentEvent extends EventObject {

    String button;
    String commentText;
    long ownerTweetId;
    boolean fromExplorer;



    public WriteCommentEvent(Object source, String button, String commentText, long ownerTweetId, boolean fromExplorer) {
        super(source);
        this.button= button;
        this.commentText= commentText;
        this.ownerTweetId= ownerTweetId;
        this.fromExplorer= fromExplorer;
    }


    public String getButton() {
        return button;
    }

    public String getCommentText() {
        return commentText;
    }

    public long getOwnerTweetId() {
        return ownerTweetId;
    }

    public boolean isFromExplorer() {
        return fromExplorer;
    }
}
