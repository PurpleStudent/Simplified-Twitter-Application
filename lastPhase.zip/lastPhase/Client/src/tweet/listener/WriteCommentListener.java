package tweet.listener;

import models.Comment;
import models.DateTime;
import models.Tweet;
import models.User;
import tweet.event.WriteCommentEvent;
import tweet.view.TweetView;
import view.MainFrame;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.util.LinkedList;
import java.util.Scanner;

public class WriteCommentListener {


    //TweetController controller= new TweetController();
    TweetView tweetView;






















    public void eventOccurred(WriteCommentEvent event){

        if (event.getButton().equals("write new comment")){
            createNewComment(event.getCommentText(),event.getOwnerTweetId());
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            tweetView= new TweetView(
                    getTweet (event.getOwnerTweetId()),
                    getTweetImage ( getTweet(event.getOwnerTweetId()) .getId() ),
                    getProfileImage ( getTweet(event.getOwnerTweetId()).getCreatorUserId()),
                    event.isFromExplorer()
            );
            tweetView.setListener(new TweetListener());
            MainFrame.mainFrame.getContentPane().add(tweetView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }
    }






























    private void createNewComment( String text , long ownerTweetId ) {
        try {
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{TweetController}"+"{createNewComment}{"+text+"}{"+ownerTweetId+"}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();

            socket.close();
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }





























    private BufferedImage getProfileImage(long userid){
        try {
            // first outputs
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));
            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{TweetController}"+"{getProfileImage}{"+userid+"}";
            output.println(message);
            //------------------------------------------------------------------------------------------------------------------------------------------------------------------
            // first inputs
            BufferedImage image= null;
            InputStream inputStream = socket.getInputStream();
            byte[] sizeAr = new byte[4];
            inputStream.read(sizeAr);
            int size = ByteBuffer.wrap(sizeAr).asIntBuffer().get();
            byte[] imageAr = new byte[size];
            inputStream.read(imageAr);
            image = ImageIO.read(new ByteArrayInputStream(imageAr));
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
            // second outputs
            PrintWriter output2 = new PrintWriter(socket.getOutputStream(), true);
            String message2 = "received.";
            output.println(message);
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------------
            // second inputs
            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();
            socket.close();
            return image;
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }





























    private BufferedImage getTweetImage(long tweetId){
        try {
            // first outputs
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));
            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{TweetController}"+"{getTweetImage}{"+tweetId+"}";
            output.println(message);
            //------------------------------------------------------------------------------------------------------------------------------------------------------------------
            // first inputs
            BufferedImage image= null;
            InputStream inputStream = socket.getInputStream();
            byte[] sizeAr = new byte[4];
            inputStream.read(sizeAr);
            int size = ByteBuffer.wrap(sizeAr).asIntBuffer().get();
            byte[] imageAr = new byte[size];
            inputStream.read(imageAr);
            image = ImageIO.read(new ByteArrayInputStream(imageAr));
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
            // second outputs
            PrintWriter output2 = new PrintWriter(socket.getOutputStream(), true);
            String message2 = "received.";
            output.println(message);
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------------
            // second inputs
            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();
            socket.close();
            return image;
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }





























    private Tweet getTweet(long tweetId){
        try {
            Tweet tweet= null;
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{TweetController}"+"{getTweet}{"+tweetId+"}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();

            if (!response.equals("null")) {
                String remaining = response;
                LinkedList<String> informationList = new LinkedList<>();

                while (!remaining.equals("")) {
                    String info = remaining.substring(remaining.indexOf('{') + 1, remaining.indexOf('}'));
                    informationList.add(info);

                    if (remaining.indexOf('}') + 1 == remaining.length()) {
                        remaining = "";
                    } else {
                        remaining = remaining.substring(remaining.indexOf('}') + 1);
                    }
                }

                long id = Long.parseLong(informationList.get(0));
                long ownerTweetId = Long.parseLong(informationList.get(1));
                String text = informationList.get(2);
                long creatorUserId= Long.parseLong(informationList.get(3));
                String creatorUsername = informationList.get(4);
                long reportNumber= Long.parseLong(informationList.get(5));
                DateTime dateTimeOfCreation= DateTime.convertStringToDateTime(informationList.get(6));

                if (ownerTweetId==-1){
                    tweet = new Tweet(creatorUserId, text);
                    tweet.setId(id);
                    tweet.setReportNumber(reportNumber);
                    tweet.setDateTimeOfCreation(dateTimeOfCreation);
                    tweet.setCreatorUsername(creatorUsername);
                }
                else {
                    tweet = new Comment(creatorUserId, text, ownerTweetId);
                    tweet.setId(id);
                    tweet.setReportNumber(reportNumber);
                    tweet.setDateTimeOfCreation(dateTimeOfCreation);
                    tweet.setCreatorUsername(creatorUsername);
                }
            }
            socket.close();
            return tweet;
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}
