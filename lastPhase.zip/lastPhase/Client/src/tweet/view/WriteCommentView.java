package tweet.view;

import tweet.event.WriteCommentEvent;
import tweet.listener.WriteCommentListener;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class WriteCommentView extends JPanel implements ActionListener {


    private final JTextField jTextField= new JTextField(70);
    private final JButton writeNewComment= new JButton(" Write Comment ");

    WriteCommentListener listener;

    private long ownerTweetId;
    boolean fromExplorer;


























    public WriteCommentView(long ownerTweetId , boolean fromExplorer){
        this.ownerTweetId= ownerTweetId;
        this.fromExplorer= fromExplorer;
        this.setBackground(new Color(7, 218, 246));
        Border innerBorder= BorderFactory.createTitledBorder("Enter the text of the new comment: ");
        Border outerBorder= BorderFactory.createEmptyBorder(20,20,300,20);
        this.setBorder(BorderFactory.createCompoundBorder(outerBorder,innerBorder));
        this.setLayout(new GridBagLayout());
        GridBagConstraints gridBagConstraints= new GridBagConstraints();
        gridBagConstraints.weightx= 1;
        gridBagConstraints.weighty= 1;
        //jTextField
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.insets = new Insets(0, 0, 0, 5);
        gridBagConstraints.anchor = GridBagConstraints.LINE_END;
        this.add(new JLabel("text : "), gridBagConstraints);
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.insets = new Insets(0, 0, 0, 0);
        gridBagConstraints.anchor = GridBagConstraints.LINE_START;
        this.add(jTextField, gridBagConstraints);
        //createNewTweetButton
        gridBagConstraints.weightx = 1;
        gridBagConstraints.weighty = 2;
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 8;
        gridBagConstraints.insets = new Insets(0, 0, 0, 0);
        gridBagConstraints.anchor = GridBagConstraints.FIRST_LINE_START;
        this.add(writeNewComment, gridBagConstraints);
        writeNewComment.addActionListener(this);
    }










    @Override
    public void paint(Graphics g) {
        super.paint(g);
        Font myFont = new Font ("Bold Italic", Font.BOLD, 50);
        g.setFont (myFont);


        g.setColor(new Color(241, 8, 156));
        g.drawString("☘"+"☘"+"☘"+"☘"+"☘"+"☘"+"☘"+"☘"+"☘"+"☘"+"☘"+"☘"+"☘"+"☘"+"☘"+"☘"+"☘" , 100, 600);

    }































    public void setListener(WriteCommentListener listener) {
        this.listener = listener;
    }


    public String getTextField() {
        return jTextField.getText();
    }














    @Override
    public void actionPerformed(ActionEvent e) {
        if (writeNewComment == (JButton) e.getSource()){
            WriteCommentEvent event= new WriteCommentEvent(this,"write new comment",getTextField(),ownerTweetId, fromExplorer);
            listener.eventOccurred(event);
        }
    }
}
