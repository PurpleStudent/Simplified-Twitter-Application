package tweet.view;

import models.Tweet;
import tweet.event.MyTweetPreviousNextEvent;
import tweet.listener.MyTweetPreviousNextListener;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;

public class MyTweetView extends JPanel implements ActionListener {


    Tweet tweet;
    BufferedImage image;
    BufferedImage profileImage;

    JButton nextButton= new JButton("next");
    JButton previousButton= new JButton("previous");
    JButton returnToPersonalPage= new JButton("return to personal page");








    private MyTweetPreviousNextListener myTweetPreviousNextListener;







    public MyTweetView(Tweet tweet, BufferedImage image, BufferedImage profileImage){
        this.setBackground(new Color(180, 239, 223));

        //previousButton
        previousButton.setBounds(10,600,20,100);
        this.add(previousButton);
        previousButton.addActionListener(this);

        //nextButton
        nextButton.setBounds(50,600,20,100);
        this.add(nextButton);
        nextButton.addActionListener(this);

        //returnToPersonalPage
        returnToPersonalPage.setBounds(90,600,20,100);
        this.add(returnToPersonalPage);
        returnToPersonalPage.addActionListener(this);

        this.tweet= tweet;
        this.image= image;
        this.profileImage= profileImage;
    }






    public void setMyTweetPreviousNextListener(MyTweetPreviousNextListener myTweetPreviousNextListener) {
        this.myTweetPreviousNextListener = myTweetPreviousNextListener;
    }







    @Override
    public void paint(Graphics g) {
        super.paint(g);
        Font myFont = new Font ("Bold Italic", Font.BOLD, 30);
        g.setFont (myFont);

        g.setColor(new Color(170, 24, 130, 255));
        g.drawString( "✨"+" MY TWEET ", 100, 100);


        g.setColor(new Color(9, 112, 239, 255));
        g.drawString("tweet creator:  "+tweet.getCreatorUsername(), 180, 200);

        g.setColor(new Color(126, 63, 213));
        g.drawString(tweet.getDateTimeOfCreation().toString(), 180, 250);

        g.setColor(new Color(105, 45, 198));
        g.drawString(tweet.getId()+".  "+tweet.getText(), 100, 350);

        g.setColor(new Color(144, 65, 219));
        g.fillRect(10, 10, 5, 730);
        g.fillRect(10, 10, 310, 5);
        g.fillRect(660, 10, 300, 5);
        g.fillRect(960, 10, 5, 735);
        g.fillRect(10, 740, 950, 5);


        //image
        if (image!=null) {
            g.drawImage(image, 750, 530, 200, 200, null);
        }
        if (profileImage!=null) {
            g.drawImage(profileImage, 20, 150, 150, 150, null);
        }

    }
















    @Override
    public void actionPerformed(ActionEvent e) {
        if (previousButton == (JButton) e.getSource()){
            MyTweetPreviousNextEvent myTweetPreviousNextEvent = new MyTweetPreviousNextEvent(this, tweet.getId(),"previous");
            myTweetPreviousNextListener.eventOccurred(myTweetPreviousNextEvent);
            //ترای کچ بزنیم برای تکراری بودن اطلاعات
        }
        if (nextButton == (JButton) e.getSource()){
            MyTweetPreviousNextEvent myTweetPreviousNextEvent= new MyTweetPreviousNextEvent(this,tweet.getId(),"next");
            myTweetPreviousNextListener.eventOccurred(myTweetPreviousNextEvent);
        }
        if (returnToPersonalPage == (JButton) e.getSource()){
            MyTweetPreviousNextEvent myTweetPreviousNextEvent= new MyTweetPreviousNextEvent(this,tweet.getId(),"return to personal page");
            myTweetPreviousNextListener.eventOccurred(myTweetPreviousNextEvent);
        }
    }
}
