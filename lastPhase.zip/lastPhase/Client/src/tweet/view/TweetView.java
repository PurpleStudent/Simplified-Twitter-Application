package tweet.view;

import models.Tweet;
import tweet.event.TweetEvent;
import tweet.listener.TweetListener;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;

public class TweetView extends JPanel implements ActionListener {

    Tweet tweet;
    BufferedImage tweetImage;
    BufferedImage profileImage;
    boolean fromExplorer;

    JButton nextButton= new JButton("next");
    JButton previousButton= new JButton("previous");
    JButton likeTweet= new JButton("Like");
    JButton addTweetToSavedMessages= new JButton("Add to Saved messages");
    JButton retweet= new JButton("Retweet");
    JButton forwardTweetToOtherUsers= new JButton("Forward to other users");
    JButton blockTheCreator= new JButton("Block the creator");
    JButton muteTheCreator= new JButton("Mute the creator");
    JButton reportSpam= new JButton("Report spam");
    JButton goToCreatorsPersonalPage= new JButton("Go to the creator's personal page");
    JButton writeCommentAboutTweet= new JButton("Write a comment");
    JButton goToListOfComments= new JButton("Go to the list of comments");
    JButton comingBackToHomePage= new JButton("coming back to HomePage");
    JButton logOut= new JButton("log out");
    JButton exit= new JButton("exit");



    private TweetListener listener;









    public TweetView(Tweet tweet, BufferedImage tweetImage, BufferedImage profileImage, boolean fromExplorer){
        this.setBackground(new Color(180, 239, 223));

        if (tweet!=null) {
            //
            previousButton.setBounds(10, 600, 20, 100);
            this.add(previousButton);
            previousButton.addActionListener(this);

            //
            nextButton.setBounds(50, 600, 20, 100);
            this.add(nextButton);
            nextButton.addActionListener(this);

            //
            likeTweet.setBounds(90, 600, 20, 100);
            this.add(likeTweet);
            likeTweet.addActionListener(this);

            //
            addTweetToSavedMessages.setBounds(90, 600, 20, 100);
            this.add(addTweetToSavedMessages);
            addTweetToSavedMessages.addActionListener(this);

            //
            retweet.setBounds(90, 600, 20, 100);
            this.add(retweet);
            retweet.addActionListener(this);

            //
            forwardTweetToOtherUsers.setBounds(90, 600, 20, 100);
            this.add(forwardTweetToOtherUsers);
            forwardTweetToOtherUsers.addActionListener(this);

            //
            blockTheCreator.setBounds(90, 600, 20, 100);
            this.add(blockTheCreator);
            blockTheCreator.addActionListener(this);

            //
            muteTheCreator.setBounds(90, 600, 20, 100);
            this.add(muteTheCreator);
            muteTheCreator.addActionListener(this);

            //
            reportSpam.setBounds(90, 600, 20, 100);
            this.add(reportSpam);
            reportSpam.addActionListener(this);

            //
            goToCreatorsPersonalPage.setBounds(90, 600, 20, 100);
            this.add(goToCreatorsPersonalPage);
            goToCreatorsPersonalPage.addActionListener(this);

            //
            writeCommentAboutTweet.setBounds(90, 600, 20, 100);
            this.add(writeCommentAboutTweet);
            writeCommentAboutTweet.addActionListener(this);

            //
            goToListOfComments.setBounds(90, 600, 20, 100);
            this.add(goToListOfComments);
            goToListOfComments.addActionListener(this);

        }



        //
        comingBackToHomePage.setBounds(90,600,20,100);
        this.add(comingBackToHomePage);
        comingBackToHomePage.addActionListener(this);

        //
        logOut.setBounds(90,600,20,100);
        this.add(logOut);
        logOut.addActionListener(this);

        //
        exit.setBounds(90,600,20,100);
        this.add(exit);
        exit.addActionListener(this);

        this.tweet= tweet;
        this.tweetImage= tweetImage;
        this.profileImage= profileImage;
        this.fromExplorer= fromExplorer;
    }


    public void setListener(TweetListener listener) {
        this.listener = listener;
    }












    @Override
    public void paint(Graphics g) {
        super.paint(g);
        Font myFont = new Font ("Bold Italic", Font.BOLD, 30);
        g.setFont (myFont);

        if (tweet!=null) {
            g.setColor(new Color(194, 23, 192, 255));
            g.drawString("🔮"+" TWEET ", 100, 150);

            g.setColor(new Color(33, 163, 28, 255));
            g.drawString("creator :  " + tweet.getCreatorUsername(), 180, 250);

            g.setColor(new Color(135, 64, 142));
            g.drawString(tweet.getDateTimeOfCreation().toString(), 180, 300);

            g.setColor(new Color(105, 45, 198));
            g.drawString(tweet.getId() + ".  " + tweet.getText(), 100, 400);
        }

        else {
            g.setColor(new Color(135, 64, 142));
            g.drawString("There are no tweets to display", 100, 300);
        }

        g.setColor(new Color(99, 200, 203));

        g.fillRect(10, 100, 5, 640);
        g.fillRect(960, 100, 5, 645);
        g.fillRect(10,100,950,5);
        g.fillRect(10, 740, 950, 5);



        //image
        if (tweetImage!=null) {
            g.drawImage(tweetImage, 750, 530, 200, 200, null);
        }
        if (profileImage!=null) {
            g.drawImage(profileImage, 20, 200, 150, 150, null);
        }
    }



























    @Override
    public void actionPerformed(ActionEvent e) {
        if (previousButton == (JButton) e.getSource()){
            TweetEvent event = new TweetEvent(this,"previous",tweet, fromExplorer);
            listener.eventOccurred(event);
            //ترای کچ بزنیم برای تکراری بودن اطلاعات
        }
        if (nextButton == (JButton) e.getSource()){
            TweetEvent event= new TweetEvent(this,"next",tweet, fromExplorer);
            listener.eventOccurred(event);
        }
        if (likeTweet == (JButton) e.getSource()){
            TweetEvent event= new TweetEvent(this,"like tweet",tweet, fromExplorer);
            listener.eventOccurred(event);
        }
        if (addTweetToSavedMessages == (JButton) e.getSource()){
            TweetEvent event= new TweetEvent(this,"add tweet to saved messages",tweet, fromExplorer);
            listener.eventOccurred(event);
        }
        if (retweet == (JButton) e.getSource()){
            TweetEvent event= new TweetEvent(this,"retweet",tweet, fromExplorer);
            listener.eventOccurred(event);
        }
        if (forwardTweetToOtherUsers == (JButton) e.getSource()){
            TweetEvent event= new TweetEvent(this,"forward tweet to other users",tweet, fromExplorer);
            listener.eventOccurred(event);
        }
        if (blockTheCreator == (JButton) e.getSource()){
            TweetEvent event= new TweetEvent(this,"block the creator",tweet, fromExplorer);
            listener.eventOccurred(event);
        }
        if (muteTheCreator == (JButton) e.getSource()){
            TweetEvent event= new TweetEvent(this,"mute the creator",tweet, fromExplorer);
            listener.eventOccurred(event);
        }
        if (reportSpam == (JButton) e.getSource()){
            TweetEvent event= new TweetEvent(this,"report spam",tweet, fromExplorer);
            listener.eventOccurred(event);
        }
        if (goToCreatorsPersonalPage == (JButton) e.getSource()){
            TweetEvent event= new TweetEvent(this,"go to creators personal page",tweet, fromExplorer);
            listener.eventOccurred(event);
        }
        if (writeCommentAboutTweet == (JButton) e.getSource()){
            TweetEvent event= new TweetEvent(this,"write comment about tweet",tweet, fromExplorer);
            listener.eventOccurred(event);
        }
        if (goToListOfComments == (JButton) e.getSource()){
            TweetEvent event= new TweetEvent(this,"go to list of comments",tweet, fromExplorer);
            listener.eventOccurred(event);
        }
        if (comingBackToHomePage == (JButton) e.getSource()){
            TweetEvent event= new TweetEvent(this,"coming back to home page",tweet, fromExplorer);
            listener.eventOccurred(event);
        }
        if (logOut == (JButton) e.getSource()){
            TweetEvent event= new TweetEvent(this,"log out",tweet, fromExplorer);
            listener.eventOccurred(event);
        }
        if (exit == (JButton) e.getSource()){
            TweetEvent event= new TweetEvent(this,"exit",tweet, fromExplorer);
            listener.eventOccurred(event);
        }
    }
}
