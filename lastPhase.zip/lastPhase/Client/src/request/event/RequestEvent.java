package request.event;

import models.Request;

import java.util.EventObject;

public class RequestEvent extends EventObject {


    String button;
    Request request;



    public RequestEvent(Object source, String button, Request request) {
        super(source);
        this.button= button;
        this.request= request;
    }


    public String getButton() {
        return button;
    }

    public Request getRequest() {
        return request;
    }
}
