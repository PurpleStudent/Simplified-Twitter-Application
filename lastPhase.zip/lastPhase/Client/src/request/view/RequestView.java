package request.view;

import models.Request;
import request.event.RequestEvent;
import request.listener.RequestListener;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class RequestView extends JPanel implements ActionListener {


    Request request;

    JButton accept= new JButton("Accept");
    JButton rejectAndLetHerHimKnow= new JButton("Reject and let her/him know");
    JButton rejectWithoutNotifying= new JButton("Reject, without notifying");
    JButton returnToRequestSection= new JButton("return to request section");



    private RequestListener listener;
















    public RequestView(Request request){
        this.setBackground(new Color(180, 239, 223));

        if (request!=null) {
            //
            accept.setBounds(10, 600, 20, 100);
            this.add(accept);
            accept.addActionListener(this);

            //
            rejectAndLetHerHimKnow.setBounds(50, 600, 20, 100);
            this.add(rejectAndLetHerHimKnow);
            rejectAndLetHerHimKnow.addActionListener(this);

            //
            rejectWithoutNotifying.setBounds(90, 600, 20, 100);
            this.add(rejectWithoutNotifying);
            rejectWithoutNotifying.addActionListener(this);
        }
        else {
            //
            returnToRequestSection.setBounds(90, 600, 20, 100);
            this.add(returnToRequestSection);
            returnToRequestSection.addActionListener(this);
        }

        this.request= request;
    }


    public void setListener(RequestListener listener) {
        this.listener = listener;
    }












    @Override
    public void paint(Graphics g) {
        super.paint(g);
        Font myFont = new Font ("Bold Italic", Font.BOLD, 30);
        g.setFont (myFont);

        if (request!=null) {
            g.setColor(new Color(194, 23, 192, 255));
            g.drawString("📩"+" REQUEST ", 100, 150);

            g.setColor(new Color(33, 163, 28, 255));
            g.drawString("requester :  " + request.getRequester().getUsername(), 180, 250);

            g.setColor(new Color(105, 45, 198));
            g.drawString(request.getId() + ".  " + request.getText(), 100, 400);
        }

        else {
            g.setColor(new Color(135, 64, 142));
            g.drawString("There are no requests to display", 250, 300);
        }

        g.setColor(new Color(99, 200, 203));

        g.fillRect(10, 100, 5, 640);
        g.fillRect(960, 100, 5, 645);
        g.fillRect(10,100,950,5);
        g.fillRect(10, 740, 950, 5);
    }



























    @Override
    public void actionPerformed(ActionEvent e) {
        if (accept == (JButton) e.getSource()){
            RequestEvent event = new RequestEvent(this,"accept",request);
            listener.eventOccurred(event);
            //ترای کچ بزنیم برای تکراری بودن اطلاعات
        }
        if (rejectAndLetHerHimKnow == (JButton) e.getSource()){
            RequestEvent event= new RequestEvent(this,"reject And Let HerHim Know",request);
            listener.eventOccurred(event);
        }
        if (rejectWithoutNotifying == (JButton) e.getSource()){
            RequestEvent event= new RequestEvent(this,"reject Without Notifying",request);
            listener.eventOccurred(event);
        }
        if (returnToRequestSection == (JButton) e.getSource()){
            RequestEvent event= new RequestEvent(this,"return To Request Section",request);
            listener.eventOccurred(event);
        }
    }
}
