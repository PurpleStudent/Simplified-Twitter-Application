package request.listener;

import announcements.listener.RequestsSectionListener;
import announcements.view.RequestsSectionView;
import models.Chat;
import models.DateTime;
import models.Request;
import models.User;
import request.event.RequestEvent;
import request.view.RequestView;
import view.MainFrame;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.LinkedList;
import java.util.Scanner;

public class RequestListener {

    //RequestController controller= new RequestController();
    RequestView requestView;
    RequestsSectionView requestsSectionView= new RequestsSectionView();













    public void eventOccurred(RequestEvent event){

        if (event.getButton().equals("accept")){
            accept (event.getRequest().getId());
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            requestView= new RequestView (getNextRequest());
            requestView.setListener(new RequestListener());
            MainFrame.mainFrame.getContentPane().add(requestView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }




        if (event.getButton().equals("reject And Let HerHim Know")){
            rejectAndLetHerHimKnow( event.getRequest().getId() );
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            requestView= new RequestView(getNextRequest());
            requestView.setListener(new RequestListener());
            MainFrame.mainFrame.getContentPane().add(requestView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }




        if (event.getButton().equals("reject Without Notifying")){
            rejectWithoutNotifying( event.getRequest().getId());
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            requestView= new RequestView(getNextRequest());
            requestView.setListener(new RequestListener());
            MainFrame.mainFrame.getContentPane().add(requestView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }



        if (event.getButton().equals("return To Request Section")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            requestsSectionView.setStringListener(new RequestsSectionListener());
            MainFrame.mainFrame.getContentPane().add(requestsSectionView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }
    }































    private void accept(long requestId){
        try {
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{RequestController}"+"{accept}{"+requestId+"}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();

            socket.close();
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }































    private Request getNextRequest(){
        try {
            Request request= null;
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{RequestController}"+"{getNextRequest}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();

            if (!response.equals("null")) {
                String remaining = response;
                LinkedList<String> informationList = new LinkedList<>();

                while (!remaining.equals("")) {
                    String info = remaining.substring(remaining.indexOf('{') + 1, remaining.indexOf('}'));
                    informationList.add(info);

                    if (remaining.indexOf('}') + 1 == remaining.length()) {
                        remaining = "";
                    } else {
                        remaining = remaining.substring(remaining.indexOf('}') + 1);
                    }
                }

                long requesterId = Long.parseLong(informationList.get(0));
                long requestedId = Long.parseLong(informationList.get(1));
                long id= Long.parseLong(informationList.get(2));
                String text= informationList.get(3);

                request = new Request(requesterId , requestedId);
                request.setId(id);
                request.setText(text);
            }

            socket.close();
            return request;
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }































    private void rejectAndLetHerHimKnow(long requestId){
        try {
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{RequestController}"+"{rejectAndLetHerHimKnow}{"+requestId+"}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();

            socket.close();
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }































    private void rejectWithoutNotifying( long requestId){
        try {
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{RequestController}"+"{rejectWithoutNotifying}{"+requestId+"}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();

            socket.close();
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
}
