package privacySettingsPage.view;

import listener.StringListener;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PublicPrivateView extends JPanel implements ActionListener {


    private final JButton publicButton= new JButton("Public");
    private final JButton privateButton= new JButton("Private");

    private StringListener stringListener;

























    public PublicPrivateView(){
        this.setBackground(Color.yellow);
        this.setLayout(new GridLayout(2,1));

        this.add(publicButton);
        this.add(privateButton);

        publicButton.addActionListener(this);
        privateButton.addActionListener(this);
    }
























    public void setStringListener(StringListener stringListener) {
        this.stringListener = stringListener;
    }
















    @Override
    public void actionPerformed(ActionEvent e) {
        if (publicButton == (JButton) e.getSource()){
            stringListener.stringEventOccurred("public");
        }
        if (privateButton == (JButton) e.getSource()){
            stringListener.stringEventOccurred("private");
        }
    }
}
