package privacySettingsPage.view;

import listener.StringListener;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LastSeenOnlineView extends JPanel implements ActionListener {


    private final JButton everybody= new JButton("everybody");
    private final JButton nobody= new JButton("nobody");
    private final JButton followings= new JButton("followings");


    private StringListener stringListener;














    public LastSeenOnlineView(){
        this.setBackground(Color.yellow);
        this.setLayout(new GridLayout(3,1));

        this.add(everybody);
        this.add(nobody);
        this.add(followings);

        everybody.addActionListener(this);
        nobody.addActionListener(this);
        followings.addActionListener(this);
    }


    public void setStringListener(StringListener stringListener) {
        this.stringListener = stringListener;
    }






    @Override
    public void actionPerformed(ActionEvent e) {
        if (everybody == (JButton) e.getSource()){
            stringListener.stringEventOccurred("everybody");
        }
        if (nobody == (JButton) e.getSource()){
            stringListener.stringEventOccurred("nobody");
        }
        if (followings == (JButton) e.getSource()){
            stringListener.stringEventOccurred("followings");
        }
    }
}
