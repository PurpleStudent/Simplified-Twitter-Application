package privacySettingsPage.view;

import listener.StringListener;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PrivacySettingsPageView extends JPanel implements ActionListener {


    private final JButton publicPrivateSettings= new JButton("public & private settings");
    private final JButton lastSeenOnlineSettings= new JButton("last seen & online settings");
    private final JButton activeInactiveAccount= new JButton("active or inactive account");
    private final JButton changePassword= new JButton("change password");
    private final JButton showDateOfBirthSettings= new JButton("Show Date Of Birth settings");
    private final JButton showEmailSettings= new JButton("Show Email settings");
    private final JButton showPhoneNumberSettings= new JButton("Show Phone Number settings");
    private final JButton returnToSettingsPage= new JButton("Return to settings page");
    private final JButton logOut= new JButton("log out");
    private final JButton exit= new JButton("exit");


    private StringListener stringListener;


















    public PrivacySettingsPageView(){
        this.setBackground(Color.yellow);
        this.setLayout(new GridLayout(10,1));

        this.add(publicPrivateSettings);
        this.add(lastSeenOnlineSettings);
        this.add(activeInactiveAccount);
        this.add(changePassword);
        this.add(showDateOfBirthSettings);
        this.add(showEmailSettings);
        this.add(showPhoneNumberSettings);
        this.add(returnToSettingsPage);
        this.add(logOut);
        this.add(exit);

        publicPrivateSettings.addActionListener(this);
        lastSeenOnlineSettings.addActionListener(this);
        activeInactiveAccount.addActionListener(this);
        changePassword.addActionListener(this);
        showDateOfBirthSettings.addActionListener(this);
        showEmailSettings.addActionListener(this);
        showPhoneNumberSettings.addActionListener(this);
        returnToSettingsPage.addActionListener(this);
        logOut.addActionListener(this);
        exit.addActionListener(this);
    }




    public void setStringListener(StringListener stringListener) {
        this.stringListener = stringListener;
    }











    @Override
    public void actionPerformed(ActionEvent e) {
        if (publicPrivateSettings == (JButton) e.getSource()){
            stringListener.stringEventOccurred("public Private Settings");
        }
        if (lastSeenOnlineSettings == (JButton) e.getSource()){
            stringListener.stringEventOccurred("last Seen Online Settings");
        }
        if (activeInactiveAccount == (JButton) e.getSource()){
            stringListener.stringEventOccurred("active Inactive Account");
        }
        if (changePassword == (JButton) e.getSource()){
            stringListener.stringEventOccurred("change Password");
        }
        if (showDateOfBirthSettings == (JButton) e.getSource()){
            stringListener.stringEventOccurred("show Date Of Birth Settings");
        }
        if (showEmailSettings == (JButton) e.getSource()){
            stringListener.stringEventOccurred("show Email Settings");
        }
        if (showPhoneNumberSettings == (JButton) e.getSource()){
            stringListener.stringEventOccurred("show Phone Number Settings");
        }
        if (returnToSettingsPage == (JButton) e.getSource()){
            stringListener.stringEventOccurred("return To Settings Page");
        }
        if (logOut == (JButton) e.getSource()){
            stringListener.stringEventOccurred("Log Out");
        }
        if (exit == (JButton) e.getSource()){
            stringListener.stringEventOccurred("Exit");
        }
    }
}
