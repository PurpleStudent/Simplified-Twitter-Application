package privacySettingsPage.view;

import editProfilePage.event.ChangeEvent;
import editProfilePage.listener.ChangeListener;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ChangePasswordView extends JPanel implements ActionListener {


    private final JTextField jTextField= new JTextField(70);
    private final JButton changePassword= new JButton("change Password");

    ChangeListener changeListener;










    public ChangePasswordView(){
        this.setBackground(new Color(164, 142, 243));
        Border innerBorder= BorderFactory.createTitledBorder("Enter new Password: ");
        Border outerBorder= BorderFactory.createEmptyBorder(20,20,300,20);
        this.setBorder(BorderFactory.createCompoundBorder(outerBorder,innerBorder));
        this.setLayout(new GridBagLayout());
        GridBagConstraints gridBagConstraints= new GridBagConstraints();
        gridBagConstraints.weightx= 1;
        gridBagConstraints.weighty= 1;
        //jTextField
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.insets = new Insets(0, 0, 0, 5);
        gridBagConstraints.anchor = GridBagConstraints.LINE_END;
        this.add(new JLabel("new Password: "), gridBagConstraints);
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.insets = new Insets(0, 0, 0, 0);
        gridBagConstraints.anchor = GridBagConstraints.LINE_START;
        this.add(jTextField, gridBagConstraints);
        //createNewTweetButton
        gridBagConstraints.weightx = 1;
        gridBagConstraints.weighty = 2;
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 8;
        gridBagConstraints.insets = new Insets(0, 0, 0, 0);
        gridBagConstraints.anchor = GridBagConstraints.FIRST_LINE_START;
        this.add(changePassword, gridBagConstraints);
        changePassword.addActionListener(this);
    }


    public void setChangeListener(ChangeListener changeListener) {
        this.changeListener = changeListener;
    }

    public String  getTextField() {
        return jTextField.getText();
    }














    @Override
    public void actionPerformed(ActionEvent e) {
        if (changePassword == (JButton) e.getSource()){
            ChangeEvent changeEvent= new ChangeEvent(this, "password", getTextField(),null);
            changeListener.changeOccurred(changeEvent);
        }
    }
}
