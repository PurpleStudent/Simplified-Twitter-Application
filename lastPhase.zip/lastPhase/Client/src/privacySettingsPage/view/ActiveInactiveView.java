package privacySettingsPage.view;

import listener.StringListener;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ActiveInactiveView extends JPanel implements ActionListener {

    private final JButton active= new JButton("Active");
    private final JButton inactive= new JButton("Inactive");

    private StringListener stringListener;


























    public ActiveInactiveView(){
        this.setBackground(Color.yellow);
        this.setLayout(new GridLayout(2,1));

        this.add(active);
        this.add(inactive);

        active.addActionListener(this);
        inactive.addActionListener(this);
    }



















    public void setStringListener(StringListener stringListener) {
        this.stringListener = stringListener;
    }
























    @Override
    public void actionPerformed(ActionEvent e) {
        if (active == (JButton) e.getSource()){
            stringListener.stringEventOccurred("active");
        }
        if (inactive == (JButton) e.getSource()){
            stringListener.stringEventOccurred("inactive");
        }
    }
}
