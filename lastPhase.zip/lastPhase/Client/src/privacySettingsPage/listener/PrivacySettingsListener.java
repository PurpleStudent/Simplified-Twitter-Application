package privacySettingsPage.listener;

import editProfilePage.listener.ChangeListener;
import listener.StringListener;
import privacySettingsPage.view.*;
import settingsPage.listener.SettingPageListener;
import settingsPage.view.SettingsPageView;
import view.MainFrame;
import view.MainPanel;

public class PrivacySettingsListener implements StringListener {


    //PrivacySettingsController controller= new PrivacySettingsController();
    SettingsPageView settingsPageView= new SettingsPageView();
    LastSeenOnlineView lastSeenOnlineView= new LastSeenOnlineView();
    PublicPrivateView publicPrivateView= new PublicPrivateView();
    ActiveInactiveView activeInactiveView;
    ChangePasswordView changePasswordView= new ChangePasswordView();
    ShowDateOfBirthView showDateOfBirthView= new ShowDateOfBirthView();
    ShowEmailView showEmailView= new ShowEmailView();
    ShowPhoneNumberView showPhoneNumberView= new ShowPhoneNumberView();
    MainPanel mainPanel= new MainPanel();














    @Override
    public void stringEventOccurred(String string) {

        if (string.equals("public Private Settings")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            publicPrivateView.setStringListener(new PublicPrivateListener());
            MainFrame.mainFrame.getContentPane().add(publicPrivateView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }

        if (string.equals("last Seen Online Settings")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            lastSeenOnlineView.setStringListener(new LastSeenOnlineListener());
            MainFrame.mainFrame.getContentPane().add(lastSeenOnlineView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }

        if (string.equals("active Inactive Account")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            activeInactiveView= new ActiveInactiveView();
            activeInactiveView.setStringListener(new ActiveInactiveListener());
            MainFrame.mainFrame.getContentPane().add(activeInactiveView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }

        if (string.equals("change Password")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            changePasswordView.setChangeListener(new ChangeListener());
            MainFrame.mainFrame.getContentPane().add(changePasswordView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }

        if (string.equals("show Date Of Birth Settings")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            showDateOfBirthView.setStringListener(new ShowDateOfBirthListener());
            MainFrame.mainFrame.getContentPane().add(showDateOfBirthView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }

        if (string.equals("show Email Settings")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            showEmailView.setStringListener(new ShowEmailListener());
            MainFrame.mainFrame.getContentPane().add(showEmailView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }

        if (string.equals("show Phone Number Settings")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            showPhoneNumberView.setStringListener(new ShowPhoneNumberListener());
            MainFrame.mainFrame.getContentPane().add(showPhoneNumberView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }

        if (string.equals("return To Settings Page")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            settingsPageView.setStringListener(new SettingPageListener());
            MainFrame.mainFrame.getContentPane().add(settingsPageView);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }

        if (string.equals("Log Out")){
            MainFrame.mainFrame.getContentPane().removeAll();
            MainFrame.mainFrame.getContentPane().invalidate();
            MainFrame.mainFrame.getContentPane().add(mainPanel);
            MainFrame.mainFrame.getContentPane().revalidate();
            MainFrame.mainFrame.repaint();
        }

        if (string.equals("Exit")){
            System.exit(0);
        }
    }
}
