package privacySettingsPage.listener;

import listener.StringListener;
import models.User;
import privacySettingsPage.view.PrivacySettingsPageView;
import view.MainFrame;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class LastSeenOnlineListener implements StringListener {


    //PrivacySettingsController controller= new PrivacySettingsController();
    PrivacySettingsPageView privacySettingsPageView= new PrivacySettingsPageView();











    @Override
    public void stringEventOccurred(String string) {
        lastSeenOnline(string);
        MainFrame.mainFrame.getContentPane().removeAll();
        MainFrame.mainFrame.getContentPane().invalidate();
        privacySettingsPageView.setStringListener(new PrivacySettingsListener());
        MainFrame.mainFrame.getContentPane().add(privacySettingsPageView);
        MainFrame.mainFrame.getContentPane().revalidate();
        MainFrame.mainFrame.repaint();
    }































    private void lastSeenOnline(String string){
        try {
            Socket socket = new Socket(User.ipAddress , Integer.parseInt(User.port));

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "{"+ User.authToken+"}{"+User.currentUserId+"}"+"{PrivacySettingsController}"+"{lastSeenOnline}{"+string+"}";
            output.println(message);

            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();

            socket.close();
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
}
